const easyQuestions = [
  {
    question: "A queue follows which access policy?",
    options: ["LIFO", "FIFO", "Priority", "Random"],
    answer: 1
  },
  {
    question: "Which operation removes the front element from a queue?",
    options: ["enqueue", "dequeue", "peek", "push"],
    answer: 1
  },
  {
    question: "What operation returns the front element without removing it?",
    options: ["pop", "peek", "enqueue", "delete"],
    answer: 1
  },
  {
    question: "Which operation adds an element to the back?",
    options: ["push", "enqueue", "pop", "peek"],
    answer: 1
  },
  {
    question: "Dequeue on an empty fixed-size queue causes:",
    options: ["overflow", "underflow", "success", "exception‑free behavior"],
    answer: 1
  },
  {
    question: "Enqueue on a full bounded queue results in:",
    options: ["underflow", "overflow", "success", "null"],
    answer: 1
  },
  {
    question: "A circular queue uses a fixed‑size array with two pointers:",
    options: ["head & tail", "top & bottom", "front & max", "insert & delete"],
    answer: 0
  },
  {
    question: "Front pointer in a queue implementation indexes:",
    options: ["where enqueue occurs", "where operations stop", "the next dequeue position", "nothing"],
    answer: 2
  },
  {
    question: "Time complexity for enqueue in a queue implemented via array?",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Dequeue time complexity?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 0
  },
  {
    question: "Peek/front operation complexity?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "Which operation is not part of a standard queue?",
    options: ["enqueue", "dequeue", "push", "peek"],
    answer: 2
  },
  {
    question: "A queue can be used to reverse the order of items.",
    options: ["True", "False"],
    answer: 1
  },
  {
    question: "Level‑order traversal of a tree uses:",
    options: ["stack", "queue", "recursion", "set"],
    answer: 1
  },
  {
    question: "Queue is ideal for breadth‑first search (BFS).",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Matching jobs to worker threads can use a queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Print queue handles jobs FIFO.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "In C++, std::queue by default uses:",
    options: ["deque", "vector", "list", "queue"],
    answer: 0
  },
  {
    question: "In Java, `Queue` interface is implemented by:",
    options: ["HashSet", "LinkedList", "TreeMap", "ArrayList"],
    answer: 1
  },
  {
    question: "Circular buffer implementation prevents:",
    options: ["underflow", "overflow", "wasted space wrap‑around", "sorting"],
    answer: 2
  },
  {
    question: "Peek on an empty queue returns:",
    options: ["null or exception", "garbage", "error code 0", "zero"],
    answer: 0
  },
  {
    question: "Which error occurs on dequeue from empty?",
    options: ["segmentation fault", "underflow", "overflow", "allocation error"],
    answer: 1
  },
  {
    question: "Use queue to implement round‑robin scheduling.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "A priority queue is the same as a basic FIFO queue.",
    options: ["True", "False"],
    answer: 1
  },
  {
    question: "Fixed‑size queue overflow occurs if enqueues exceed:",
    options: ["head pointer", "capacity", "peeked elements", "tail pointer"],
    answer: 1
  },
  {
    question: "Peek returns the:",
    options: ["last element", "first element", "random element", "middle"],
    answer: 1
  },
  {
    question: "Queue can be implemented using two stacks.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Deque stands for double‑ended queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "‘enqueue’ adds at the:",
    options: ["front", "rear/back", "middle", "random"],
    answer: 1
  },
  {
    question: "If a queue holds integers, enqueue expects:",
    options: ["characters", "ints", "floats", "void"],
    answer: 1
  }
];


const mediumQuestions = [
  {
    question: "After enqueuing 1, 2, 3 and dequeuing twice, front is:",
    options: ["1", "2", "3", "undefined"],
    answer: 2
  },
  {
    question: "Sequence: enqueue 5, enqueue 8, peek, dequeue, peek → returns:",
    options: ["5, then 5", "5, then 8", "8, then 5", "8, then 8"],
    answer: 1
  },
  {
    question: "BFS on a graph from node A processes neighbors using:",
    options: ["stack", "queue", "heap", "set"],
    answer: 1
  },
  {
    question: "Reverse a queue using stack: you must:",
    options: ["pop all queue items then push back", "use two queues", "use heap", "not possible"],
    answer: 0
  },
  {
    question: "Check palindrome using queue and stack in O(n).",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Circular queue size is:",
    options: ["front + rear", "(rear - front + capacity)%capacity", "front * rear", "capacity²"],
    answer: 1
  },
  {
    question: "Josephus problem can be solved using queue simulation.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To implement a deque with two queues is:",
    options: ["natural", "inefficient", "impossible", "O(1)"],
    answer: 1
  },
  {
    question: "Minimum operations to reverse first k elements of queue using stack:",
    options: ["O(k)", "O(1)", "O(n)", "O(k²)"],
    answer: 0
  },
  {
    question: "Round-robin scheduling simulation uses a circular queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To merge k sorted queues efficiently use:",
    options: ["one queue", "k queues + min‑heap", "stack", "BFS"],
    answer: 1
  },
  {
    question: "Sliding‑window max needs deque, not queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implement queue with two stacks has amortized cost per op:",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "When merging BFS and DFS hybrids, queue does:",
    options: ["DFS", "BFS", "both", "none"],
    answer: 1
  },
  {
    question: "Printer jobs managed by a queue are processed in:",
    options: ["reverse order", "random", "FIFO", "sorted"],
    answer: 2
  },
  {
    question: "Josephus problem’s complexity using queue is:",
    options: ["O(n²)", "O(n*k)", "O(n)", "O(k log n)"],
    answer: 2
  },
  {
    question: "To generate binary numbers from 1 to n in order using queue:",
    options: ["recursion", "queue method", "heap", "stack"],
    answer: 1
  },
  {
    question: "Level-order traversal of a binary tree prints:",
    options: ["nodes by depth", "in-order", "pre-order", "post-order"],
    answer: 0
  },
  {
    question: "For fixed-size queue, wrap-around index updates use:",
    options: ["subtraction", "(i+1)%capacity", "division", "log"],
    answer: 1
  },
  {
    question: "Queue used to check palindrome: you dequeue and compare with stack pop.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To simulate ticket booking order, you use:",
    options: ["LIFO", "FIFO queue", "two stacks", "graph"],
    answer: 1
  },
  {
    question: "Using two queues to implement stack: push on active queue, move all to aux.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Which is not part of queue‑permutation tests?",
    options: ["stack", "queue", "graph", "array"],
    answer: 1
  },
  {
    question: "Max in sliding window size k needs:",
    options: ["queue", "deque", "stack", "tree"],
    answer: 1
  },
  {
    question: "In a queue simulation for supermarket, arrival and service both use queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Recursively reverse a queue you need only queue, no stack.",
    options: ["True", "False"],
    answer: 1
  },
  {
    question: "In two‑stack queue, front element lies in:",
    options: ["input stack top", "output stack top", "both", "none"],
    answer: 1
  },
  {
    question: "For performance, implementing queue with circular array is better than shifting on dequeue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implementing queue in Python with `collections.deque` gives O(1) enqueue/dequeue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "In concurrency, queue used in producer/consumer problems.",
    options: ["True", "False"],
    answer: 0
  }
];

const hardQuestions = [
  {
    question: "A min‑queue (supporting getMin) can be implemented with:",
    options: ["one queue", "two queues + aux deque", "stack only", "heap"],
    answer: 1
  },
  {
    question: "Sliding‑window median using queues and heaps achieves O(log n) per insertion.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implementing thread‑safe queue needs which mechanism?",
    options: ["recursion", "locks or atomic ops", "stack", "nothing"],
    answer: 1
  },
  {
    question: "For non‑blocking queue you use:",
    options: ["mutex", "CAS atomic operations", "recursion", "stack"],
    answer: 1
  },
  {
    question: "A circular buffer queue can detect full when:",
    options: ["front == rear", "(rear+1)==front", "front > rear", "rear‑front == capacity"],
    answer: 1
  },
  {
    question: "Maximum queue size in two‑stack implementation is:",
    options: ["input size + output size", "just input size", "just output size", "fixed"],
    answer: 0
  },
  {
    question: "Deque supporting getMax in O(1) per op uses:",
    options: ["one deque", "deque + auxiliary deque", "two queues", "stack"],
    answer: 1
  },
  {
    question: "Josephus with dynamic elimination and variable k uses:",
    options: ["queue + modulo", "circular linked list", "stack", "priority queue"],
    answer: 1
  },
  {
    question: "Real‑time task scheduling uses circular queue for periodic tasks.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implement a wait‑free queue in concurrent DSA requires:",
    options: ["stack", "lock‑free atomic ops", "mutex", "barrier"],
    answer: 1
  },
  {
    question: "Use queue to detect cycle in directed graph?",
    options: ["True (Kahn’s algorithm for topo sort uses queue)", "False"],
    answer: 0
  },
  {
    question: "To run multi‑source BFS, maintain multiple queues or one with markers?",
    options: ["multiple queues", "one queue + level markers", "one queue only", "tree"],
    answer: 1
  },
  {
    question: "For counting shortest path in unweighted graph, BFS queue carries:",
    options: ["distances", "parent pointer", "both", "neither"],
    answer: 2
  },
  {
    question: "In two‑stack queue amortized complexity per operation is:",
    options: ["O(n)", "O(1)", "O(log n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "Bounded circular queue achieving wait‑free access in hardware uses:",
    options: ["locks", "ring buffer with atomic tail/head", "recursion", "stack"],
    answer: 1
  },
  {
    question: "To support dequeueMax in constant time use:",
    options: ["two deques", "max‑queue pattern (deque + aux)", "stack", "regular queue"],
    answer: 1
  },
  {
    question: "Recognizing languages of equal numbers of a’s and b’s cannot use a queue alone.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Use of queue in push‑sum protocol for distributed BFS.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "For lock-free bounded queue, ring-buffer head/tail pointers updated by:",
    options: ["locks", "atomic increments", "recursion", "modulo riffling"],
    answer: 1
  },
  {
    question: "Multi‑threaded producer‑consumer queue fairness requires:",
    options: ["simple queue", "priority queuing or fair locks", "stack", "timer"],
    answer: 1
  },
  {
    question: "Use wheel queue in Linux scheduler for round‑robin tasks.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implementing persistent (functional) queues with amortized O(1) requires:",
    options: ["one list", "two lists (front, rear)", "one deque", "stack"],
    answer: 1
  },
  {
    question: "Using two lists for purely functional queue, amortized time per op is:",
    options: ["O(n)", "O(log n)", "O(1)", "O(n²)"],
    answer: 2
  },
  {
    question: "For sliding‑window sum, queue of size k maintains:",
    options: ["sum of k last elements", "max only", "min only", "product"],
    answer: 0
  },
  {
    question: "In resource allocation graph, BFS (queue) helps detect:",
    options: ["deadlock cycles", "reachable states", "only maxima", "stack overflow"],
    answer: 1
  },
  {
    question: "To support undo operations FIFO order across tasks, one uses:",
    options: ["stack", "queue", "tree", "graph"],
    answer: 1
  },
  {
    question: "A lock‑free queue implementation often uses:",
    options: ["mutex", "hazard pointers or RCU", "recursion", "stack"],
    answer: 1
  },
  {
    question: "In advanced messaging, a deque (double‑ended queue) supports:",
    options: ["enqueue front & rear", "only rear", "only front", "neither"],
    answer: 0
  },
  {
    question: "Multi‑producer multi‑consumer queue correctness can be verified using:",
    options: ["deadlock analysis", "linearizability proofs", "recursion", "lifting lemma"],
    answer: 1
  },
  {
    question: "Circular queue with ambiguous full/empty resolved by:",
    options: ["maintaining count explicitly", "ignoring front", "using recursion", "decrementing head"],
    answer: 0
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
