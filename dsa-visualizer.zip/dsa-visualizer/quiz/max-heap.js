const easyQuestions = [
  {
    question: "What is the main property of a Max Heap?",
    options: ["Root is the smallest element", "Root is the largest element", "All leaves are at the same level", "It's a complete graph"],
    answer: 1
  },
  {
    question: "Which data structure is commonly used to implement a Max Heap?",
    options: ["Queue", "Array", "Linked List", "Stack"],
    answer: 1
  },
  {
    question: "In a Max Heap, the value of each parent node is...",
    options: ["Less than its children", "Greater than or equal to its children", "Equal to its children", "Zero"],
    answer: 1
  },
  {
    question: "What is the time complexity to insert an element into a Max Heap?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "What is the index of the left child of node at index `i` in array-based Max Heap?",
    options: ["2 * i", "i + 1", "2 * i + 1", "2 * i - 1"],
    answer: 2
  },
  {
    question: "What is the index of the right child of node at index `i` in array-based Max Heap?",
    options: ["2 * i + 2", "i + 2", "2 * i", "i - 1"],
    answer: 0
  },
  {
    question: "Which operation is used to maintain the Max Heap property after deletion?",
    options: ["Bubble Down (Heapify)", "Push", "Pop", "Merge"],
    answer: 0
  },
  {
    question: "Which node is removed during deletion from a Max Heap?",
    options: ["Leftmost leaf", "Root node", "Rightmost node", "Random node"],
    answer: 1
  },
  {
    question: "How is a Max Heap different from a Binary Search Tree?",
    options: ["Max Heap is sorted", "Max Heap follows heap property, not BST", "Max Heap is unordered", "Max Heap uses linked list"],
    answer: 1
  },
  {
    question: "Which of these is a correct Max Heap?",
    options: ["[90, 85, 80, 70, 60]", "[10, 20, 30, 40, 50]", "[100, 50, 80, 20, 10]", "[5, 10, 15, 20, 25]"],
    answer: 0
  },
  {
    question: "Which of the following is a leaf in a Max Heap with 7 elements?",
    options: ["Node at index 0", "Node at index 1", "Node at index 3", "Node at index 2"],
    answer: 2
  },
  {
    question: "A Max Heap is always a...",
    options: ["Complete Binary Tree", "Binary Search Tree", "Full Binary Tree", "AVL Tree"],
    answer: 0
  },
  {
    question: "Which of the following elements would be at the top of a Max Heap?",
    options: ["Maximum", "Minimum", "Median", "Random"],
    answer: 0
  },
  {
    question: "How many children can a node have in a Binary Max Heap?",
    options: ["1", "3", "2", "Unlimited"],
    answer: 2
  },
  {
    question: "In a Max Heap, which of the following is true for a parent and its left child?",
    options: ["Parent < Left", "Parent > Left", "Parent = Left", "Left = Right"],
    answer: 1
  },
  {
    question: "What is the worst-case time for extracting the max from a Max Heap?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 2
  },
  {
    question: "The root of a Max Heap with 1 million elements will be...",
    options: ["Minimum element", "Median element", "Maximum element", "Random"],
    answer: 2
  },
  {
    question: "What is the height of a Max Heap with `n` nodes?",
    options: ["n", "log₂n", "√n", "n/2"],
    answer: 1
  },
  {
    question: "Which traversal order cannot be used to verify the Max Heap property?",
    options: ["Preorder", "Inorder", "Level-order", "Postorder"],
    answer: 1
  },
  {
    question: "Which algorithm is used to build a Max Heap in-place?",
    options: ["QuickSort", "BuildHeap", "Dijkstra", "Bubble Sort"],
    answer: 1
  },
  {
    question: "Which of the following is not allowed in a binary Max Heap?",
    options: ["Duplicate elements", "Incomplete levels", "Maximum at root", "Random placement of children"],
    answer: 3
  },
  {
    question: "What is the number of leaves in a complete Max Heap with `n` nodes?",
    options: ["⌊n/2⌋", "n", "log n", "1"],
    answer: 0
  },
  {
    question: "What is Heapify?",
    options: ["A way to insert element", "A sorting algorithm", "A process to fix heap property", "A deletion operation"],
    answer: 2
  },
  {
    question: "In array representation, if node at index 0 is 90, then which is correct?",
    options: ["It's the minimum", "It's the middle", "It's the root", "It's a leaf"],
    answer: 2
  },
  {
    question: "Which application uses Max Heap?",
    options: ["Dijkstra’s", "Huffman Coding", "Priority Queue (max)", "Kruskal's"],
    answer: 2
  },
  {
    question: "Which condition violates Max Heap property?",
    options: ["Parent > children", "Children > parent", "All levels filled left to right", "Only root present"],
    answer: 1
  },
  {
    question: "What will be the result of deleting the root from a Max Heap?",
    options: ["Tree becomes incomplete", "Heap breaks", "Last element replaces root and reheapify", "Random node becomes root"],
    answer: 2
  },
  {
    question: "Is it possible to create a Max Heap from an unsorted array?",
    options: ["Yes", "No", "Only if array is sorted", "Only with linked list"],
    answer: 0
  },
  {
    question: "Which of the following is true about Max Heap?",
    options: ["Max Heap is always balanced", "Max Heap is never complete", "Max Heap is binary", "Max Heap allows only unique values"],
    answer: 2
  },
  {
    question: "In Max Heap, if a node has index 3, what is the index of its parent?",
    options: ["6", "1", "2", "0"],
    answer: 1
  }
];
const mediumQuestions = [
  {
    question: "In a max heap, what is the position of the largest element?",
    options: ["Leftmost leaf", "Root node", "Rightmost leaf", "Middle node"],
    answer: 1
  },
  {
    question: "What is the worst-case time complexity to delete the maximum element from a max heap?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "Which operation violates the max heap property the most?",
    options: ["Insertion at root", "Removing the root", "Inserting a duplicate", "Searching a leaf node"],
    answer: 1
  },
  {
    question: "What data structure is typically used to implement a max heap?",
    options: ["Queue", "Tree", "Array", "Linked List"],
    answer: 2
  },
  {
    question: "What is the formula for the parent of a node at index `i` in a max heap?",
    options: ["(i+1)/2", "(i-1)/2", "2*i", "2*i + 1"],
    answer: 1
  },
  {
    question: "The children of the node at index 3 in a max heap are at:",
    options: ["4 and 5", "6 and 7", "8 and 9", "2 and 3"],
    answer: 1
  },
  {
    question: "After inserting a new element in a max heap, what process is performed?",
    options: ["Bubble Down", "Bubble Up", "Shift Right", "Shift Left"],
    answer: 1
  },
  {
    question: "Which of the following is not a property of max heap?",
    options: ["Complete binary tree", "Heap order property", "Balanced tree", "Root has max value"],
    answer: 2
  },
  {
    question: "Which traversal order can be used to store a heap in an array?",
    options: ["Inorder", "Preorder", "Postorder", "Level Order"],
    answer: 3
  },
  {
    question: "In a max heap of size 15, how many leaf nodes will there be?",
    options: ["5", "7", "8", "10"],
    answer: 0
  },
  {
    question: "Max heap construction from an unsorted array of `n` elements has time complexity:",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
    answer: 0
  },
  {
    question: "In a max heap, what is the number of comparisons in the worst case during insertion?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n^2)"],
    answer: 1
  },
  {
    question: "Which algorithm is based on repeatedly using a max heap?",
    options: ["Merge Sort", "Quick Sort", "Heap Sort", "Bubble Sort"],
    answer: 2
  },
  {
    question: "What will be the second-largest element in a max heap?",
    options: ["Root", "Any leaf node", "One of the children of the root", "None"],
    answer: 2
  },
  {
    question: "What happens when you insert a smaller element in a max heap?",
    options: ["Reheapify downward", "Swap with root", "Added as new leaf, reheapify up", "Ignored"],
    answer: 2
  },
  {
    question: "A max heap must always be:",
    options: ["Full Binary Tree", "Balanced Binary Tree", "Complete Binary Tree", "Skewed Tree"],
    answer: 2
  },
  {
    question: "In max heap, how can you find the smallest element?",
    options: ["Search all leaf nodes", "Root", "Middle node", "Not possible"],
    answer: 0
  },
  {
    question: "Which of these is true for deleting the root of a max heap?",
    options: ["Replace with leftmost leaf", "Replace with rightmost leaf", "Replace with last element, then bubble up", "Replace with last element, then bubble down"],
    answer: 3
  },
  {
    question: "What is the height of a max heap with `n` nodes?",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
    answer: 1
  },
  {
    question: "Which of these elements cannot be in the heap `[90, 80, 70, 30, 40, 60]`?",
    options: ["30", "40", "10", "60"],
    answer: 2
  },
  {
    question: "When is heapify function used?",
    options: ["During search", "During insert", "After delete", "During traversal"],
    answer: 2
  },
  {
    question: "What is the result of inserting `85` into max heap `[90, 70, 60, 30, 40]`?",
    options: ["85 stays at end", "85 becomes root", "85 bubbles up below 90", "Heap is unchanged"],
    answer: 2
  },
  {
    question: "A complete binary tree is:",
    options: ["Always a max heap", "Always balanced", "Completely filled except maybe last level", "Always a BST"],
    answer: 2
  },
  {
    question: "The last level of a max heap is filled from:",
    options: ["Left to right", "Right to left", "Any order", "Root to leaves"],
    answer: 0
  },
  {
    question: "Which is true for storing a max heap in 1-indexed array?",
    options: ["Left = 2*i, Right = 2*i+1", "Left = 2*i+1, Right = 2*i+2", "Parent = i/2", "Root = index n"],
    answer: 0
  },
  {
    question: "Which of the following can’t be done in O(log n) time in max heap?",
    options: ["Insertion", "Deletion", "Merging two heaps", "Search for max"],
    answer: 2
  },
  {
    question: "If an element is not in the root but greater than the root, is the structure a valid max heap?",
    options: ["Yes", "No", "Only if it's a leaf", "Only if it’s right child"],
    answer: 1
  },
  {
    question: "Is the structure `[100, 50, 30, 20, 10]` a valid max heap?",
    options: ["Yes", "No", "Only if 30 is left child", "Only if 50 > 20"],
    answer: 0
  },
  {
    question: "To sort an array in descending order using heap sort, which heap is used?",
    options: ["Min Heap", "Max Heap", "Binary Search Tree", "AVL Tree"],
    answer: 1
  },
  {
    question: "What happens if you repeatedly extract max from a max heap?",
    options: ["Heap property is broken", "Elements are returned in decreasing order", "Heap is converted to min heap", "Infinite loop"],
    answer: 1
  }
];
const hardQuestions = [
  {
    question: "What is the time complexity to find the k-th largest element in a Max Heap?",
    options: ["O(k log n)", "O(k log k)", "O(n)", "O(log k)"],
    answer: 1
  },
  {
    question: "Which of the following arrays cannot represent a Max Heap?",
    options: [
      "[90, 15, 10, 7, 12, 2]",
      "[100, 19, 36, 17, 3, 25, 1, 2, 7]",
      "[10, 9, 8, 7, 6, 5, 4]",
      "[100, 19, 36, 17, 3, 25, 1, 2, 37]"
    ],
    answer: 3
  },
  {
    question: "What is the maximum number of nodes at height `h` in a Max Heap with `n` nodes?",
    options: ["2^h", "⌈n / 2^(h+1)⌉", "n / h", "h^2"],
    answer: 1
  },
  {
    question: "What is the space complexity of building a Max Heap from an unordered array of n elements?",
    options: ["O(n log n)", "O(n)", "O(log n)", "O(n^2)"],
    answer: 1
  },
  {
    question: "After inserting an element into a Max Heap, what operation is used to restore the heap property?",
    options: ["Sift-down", "Bubble-up", "Swap", "Reheap-down"],
    answer: 1
  },
  {
    question: "In a Max Heap represented as an array, what is the parent of the node at index `i`?",
    options: ["i / 2", "(i - 1) / 2", "i - 1", "i / 3"],
    answer: 1
  },
  {
    question: "Consider a Max Heap with all elements distinct. What is the minimum number of comparisons required to delete the max element?",
    options: ["log₂n", "n", "√n", "log₂(n!)"],
    answer: 0
  },
  {
    question: "If a Max Heap is built from an array of `n` elements, how many leaf nodes are there?",
    options: ["⌊n / 2⌋", "n", "⌈n / 2⌉", "log₂n"],
    answer: 0
  },
  {
    question: "What is the amortized time to insert `n` elements one-by-one into a Max Heap?",
    options: ["O(n log n)", "O(n)", "O(log n)", "O(n^2)"],
    answer: 0
  },
  {
    question: "Which operation is not suitable for a Max Heap?",
    options: ["Delete root", "Find minimum in O(1)", "Insert", "Heapify"],
    answer: 1
  },
  {
    question: "Which of the following can degrade the performance of Max Heap insertion?",
    options: [
      "Fully sorted input in ascending order",
      "Input with all equal elements",
      "Random input",
      "Descending input"
    ],
    answer: 0
  },
  {
    question: "What is the maximum number of swaps required when inserting an element into a Max Heap of `n` nodes?",
    options: ["log₂n", "n", "√n", "n/2"],
    answer: 0
  },
  {
    question: "Which property is always true for a Max Heap?",
    options: [
      "Root ≤ Left child",
      "Root ≥ All children",
      "Leaf nodes are greater than internal nodes",
      "Elements are sorted"
    ],
    answer: 1
  },
  {
    question: "What is the minimum height of a Max Heap with 1000 nodes?",
    options: ["9", "10", "11", "12"],
    answer: 2
  },
  {
    question: "What is the worst-case time complexity of extracting the maximum value from a Max Heap?",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 1
  },
  {
    question: "Which of the following is not true for Max Heap?",
    options: [
      "It is a complete binary tree",
      "It allows efficient insertion",
      "It allows efficient retrieval of the minimum",
      "It can be built in O(n)"
    ],
    answer: 2
  },
  {
    question: "How many comparisons are made in the worst case during the `heapify()` process?",
    options: ["O(log n)", "O(n)", "O(1)", "O(n log n)"],
    answer: 0
  },
  {
    question: "Which traversal method is most suitable for validating the Max Heap property?",
    options: ["Inorder", "Preorder", "Postorder", "Level-order"],
    answer: 3
  },
  {
    question: "To convert an array into a Max Heap, where should you start the heapify process?",
    options: ["From index 0", "From last element", "From last non-leaf node", "From root"],
    answer: 2
  },
  {
    question: "What is the last index from which you call `heapify()` in Max Heap construction?",
    options: ["n / 2", "(n / 2) - 1", "n", "n - 1"],
    answer: 1
  },
  {
    question: "Which heap operation involves more swaps?",
    options: ["Insertion", "Deletion", "Search", "Heapify"],
    answer: 1
  },
  {
    question: "The maximum number of levels in a Max Heap with `n` nodes is:",
    options: ["⌊log₂n⌋ + 1", "n", "√n", "log₁₀n"],
    answer: 0
  },
  {
    question: "Which is true for Max Heap deletion?",
    options: [
      "Replace root with left child",
      "Replace root with right child",
      "Replace root with last element",
      "Remove the leftmost node"
    ],
    answer: 2
  },
  {
    question: "Which of the following data structures uses Max Heap internally?",
    options: ["Priority Queue", "Hash Table", "Stack", "Queue"],
    answer: 0
  },
  {
    question: "The array representation of Max Heap is efficient because:",
    options: [
      "It uses pointers",
      "It doesn’t need dynamic memory",
      "Parent-child relationship can be derived using indices",
      "It stores values in order"
    ],
    answer: 2
  },
  {
    question: "After deleting the root from a Max Heap, which element is moved to the root?",
    options: ["Left child", "Right child", "Last element", "None"],
    answer: 2
  },
  {
    question: "To merge two Max Heaps of size `n`, the worst-case time complexity is:",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(n²)"],
    answer: 2
  },
  {
    question: "In a Max Heap, which of the following operations cannot be done in O(log n)?",
    options: ["Insertion", "Deletion", "Find Max", "Increase Key"],
    answer: 2
  },
  {
    question: "Which sequence cannot be the preorder traversal of a Max Heap?",
    options: [
      "[100, 19, 17, 3, 36, 25]",
      "[90, 80, 70, 60]",
      "[50, 30, 40, 20, 10]",
      "[20, 10, 15, 5, 30]"
    ],
    answer: 3
  },
  {
    question: "What is the best way to implement a Max Heap if random access is needed?",
    options: ["Binary Tree", "Linked List", "Array", "Stack"],
    answer: 2
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
