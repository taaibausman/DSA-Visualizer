const easyQuestions = [
  {
    question: "What does AVL in AVL Tree stand for?",
    options: ["Adelson-Velsky and Landis", "Advanced Vertical List", "Automatic Variable Level", "Average Value List"],
    answer: 0
  },
  {
    question: "What is the maximum difference in height between the left and right subtrees of any node in an AVL tree?",
    options: ["2", "1", "0", "Unlimited"],
    answer: 1
  },
  {
    question: "Which data structure is an AVL tree based on?",
    options: ["Array", "Linked List", "Binary Search Tree", "Stack"],
    answer: 2
  },
  {
    question: "AVL tree is also known as:",
    options: ["Binary tree", "Balanced binary search tree", "Heap", "Trie"],
    answer: 1
  },
  {
    question: "Which of the following is not a rotation type in AVL trees?",
    options: ["Left-Left", "Right-Right", "Right-Left", "Left-Right-Left"],
    answer: 3
  },
  {
    question: "When inserting into an AVL Tree, imbalance is corrected using:",
    options: ["Rotation", "Swapping", "Deletion", "Inversion"],
    answer: 0
  },
  {
    question: "How many types of rotations are there in AVL Trees?",
    options: ["2", "3", "4", "5"],
    answer: 2
  },
  {
    question: "Which condition leads to a single right rotation in an AVL tree?",
    options: ["Left-Left", "Right-Right", "Left-Right", "Right-Left"],
    answer: 0
  },
  {
    question: "What is the time complexity of insertion in an AVL tree?",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
    answer: 1
  },
  {
    question: "What is the balance factor of a perfectly balanced AVL node?",
    options: ["2", "-2", "1 or -1", "0"],
    answer: 3
  },
  {
    question: "In an AVL tree, a node is considered unbalanced if its balance factor is:",
    options: ["Greater than 1 or less than -1", "0", "1", "-1"],
    answer: 0
  },
  {
    question: "Which rotation is applied when balance factor is -2 and right child's balance factor is -1?",
    options: ["Left Rotation", "Right Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 0
  },
  {
    question: "AVL trees improve performance by maintaining:",
    options: ["No duplicates", "Sorted order", "Balance", "Full binary tree"],
    answer: 2
  },
  {
    question: "What is the time complexity of searching in an AVL tree?",
    options: ["O(n)", "O(n²)", "O(log n)", "O(1)"],
    answer: 2
  },
  {
    question: "What kind of tree is an AVL tree?",
    options: ["Unbalanced tree", "Balanced binary search tree", "Max Heap", "Trie"],
    answer: 1
  },
  {
    question: "Which of the following guarantees logarithmic time complexity for insertions and deletions?",
    options: ["AVL Tree", "Stack", "Linked List", "Queue"],
    answer: 0
  },
  {
    question: "Which of the following traversals gives sorted order of elements in an AVL tree?",
    options: ["Pre-order", "In-order", "Post-order", "Level-order"],
    answer: 1
  },
  {
    question: "Which AVL rotation fixes a Left-Right imbalance?",
    options: ["Single Left Rotation", "Single Right Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 2
  },
  {
    question: "What is the balance factor of a node with left subtree height 3 and right subtree height 2?",
    options: ["1", "-1", "0", "5"],
    answer: 0
  },
  {
    question: "Which case requires double rotation in AVL trees?",
    options: ["Left-Left", "Right-Right", "Left-Right", "Balanced"],
    answer: 2
  },
  {
    question: "If the root has a balance factor of -2, the tree is skewed towards the:",
    options: ["Left", "Right", "Balanced", "Root"],
    answer: 1
  },
  {
    question: "AVL trees avoid the worst-case scenario of:",
    options: ["Balanced BST", "Skewed binary search tree", "Duplicate insertions", "Sorted input"],
    answer: 1
  },
  {
    question: "Which operation can cause imbalance in AVL tree?",
    options: ["Insertion", "Deletion", "Both a and b", "Traversal"],
    answer: 2
  },
  {
    question: "In AVL tree, which node may need rebalancing after insertion?",
    options: ["Leaf node", "Parent of inserted node", "Closest unbalanced ancestor", "Sibling node"],
    answer: 2
  },
  {
    question: "What is the space complexity of an AVL tree?",
    options: ["O(n²)", "O(n)", "O(1)", "O(log n)"],
    answer: 1
  },
  {
    question: "Which of the following trees is always height-balanced?",
    options: ["BST", "AVL Tree", "N-ary Tree", "B-tree"],
    answer: 1
  },
  {
    question: "After insertion in AVL, when do you perform a rotation?",
    options: ["Always", "Only if imbalance occurs", "Only at root", "Never"],
    answer: 1
  },
  {
    question: "Which of the following is not a valid AVL rotation case?",
    options: ["Left-Left", "Left-Right", "Right-Left", "Right-Root"],
    answer: 3
  },
  {
    question: "Height of an AVL tree with n nodes is:",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
    answer: 1
  },
  {
    question: "Which is true for AVL trees?",
    options: ["They are not binary trees", "They cannot store strings", "They are self-balancing", "They always have even number of nodes"],
    answer: 2
  }
];
const mediumQuestions = [
  {
    question: "Which of the following traversals of an AVL tree can result in sorted order?",
    options: ["Preorder", "Inorder", "Postorder", "Level-order"],
    answer: 1
  },
  {
    question: "Which operation in AVL trees may require more than one rotation to rebalance the tree?",
    options: ["Search", "Insertion", "Deletion", "Both B and C"],
    answer: 3
  },
  {
    question: "The balance factor of a node in an AVL tree is calculated as:",
    options: ["Height(left) × Height(right)", "Height(right) - Height(left)", "Height(left) - Height(right)", "None of the above"],
    answer: 2
  },
  {
    question: "Which of the following AVL rotations is needed when a node is inserted into the right subtree of the left child?",
    options: ["Right Rotation", "Left Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 2
  },
  {
    question: "An AVL tree is always a:",
    options: ["Complete Binary Tree", "Perfect Binary Tree", "Balanced Binary Search Tree", "Heap"],
    answer: 2
  },
  {
    question: "In AVL tree, what is the maximum balance factor a node can have and still be considered balanced?",
    options: ["2", "0", "±1", "±2"],
    answer: 2
  },
  {
    question: "What is the time complexity of insertion in an AVL tree?",
    options: ["O(log n)", "O(n)", "O(n log n)", "O(1)"],
    answer: 0
  },
  {
    question: "After inserting a node in an AVL tree, the minimum number of rotations required to balance it is:",
    options: ["0", "1", "2", "3"],
    answer: 1
  },
  {
    question: "Which rotation is performed when a node is inserted into the left subtree of the left child (LL imbalance)?",
    options: ["Left Rotation", "Right Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 1
  },
  {
    question: "What kind of rotation is performed in case of RL (Right-Left) imbalance?",
    options: ["Single Left", "Single Right", "Right then Left", "Left then Right"],
    answer: 2
  },
  {
    question: "Which of the following is NOT true for AVL Trees?",
    options: ["They are balanced BSTs", "Their height is always log(n)", "Balance factor is either -1, 0, or +1", "Their worst-case height is O(n)"],
    answer: 3
  },
  {
    question: "If a node becomes unbalanced due to insertion in the left-right position, which rotation is performed?",
    options: ["Left Rotation", "Right Rotation", "Right-Left Rotation", "Left-Right Rotation"],
    answer: 3
  },
  {
    question: "In AVL Tree, how many types of imbalance cases are there?",
    options: ["2", "3", "4", "5"],
    answer: 2
  },
  {
    question: "What is the height of an AVL tree with 7 nodes in the best case?",
    options: ["3", "2", "4", "5"],
    answer: 1
  },
  {
    question: "Deletion from an AVL tree requires rebalancing by:",
    options: ["Single Rotation", "Multiple Rotations", "Restructuring the entire tree", "None of the above"],
    answer: 1
  },
  {
    question: "Which of the following is the correct sequence of steps for deletion in an AVL Tree?",
    options: ["Delete → Rebalance", "Rebalance → Delete", "Rotate → Delete", "Delete → Rotate → Insert"],
    answer: 0
  },
  {
    question: "What is the maximum height of an AVL tree with 15 nodes?",
    options: ["4", "5", "6", "7"],
    answer: 1
  },
  {
    question: "The maximum number of rotations required during insertion in AVL tree is:",
    options: ["1", "2", "3", "log n"],
    answer: 1
  },
  {
    question: "If the height of an AVL Tree is h, what is the minimum number of nodes it must contain?",
    options: ["h", "h+1", "h²", "F(h+2) - 1 (Fibonacci)"],
    answer: 3
  },
  {
    question: "After deletion, which traversal is commonly used to ensure all nodes are balanced?",
    options: ["Inorder", "Preorder", "Postorder", "Level-order"],
    answer: 2
  },
  {
    question: "How many distinct AVL Trees can be formed using 3 nodes?",
    options: ["1", "2", "3", "5"],
    answer: 2
  },
  {
    question: "Which rotation balances an AVL tree when a node is inserted in the right subtree of the right child (RR case)?",
    options: ["Right", "Left", "Right-Left", "Left-Right"],
    answer: 1
  },
  {
    question: "In an AVL tree, what is the result of multiple insertions without rebalancing?",
    options: ["Tree remains balanced", "Tree turns into BST", "Tree becomes skewed", "Segmentation fault"],
    answer: 2
  },
  {
    question: "Which of these is NOT a valid AVL rotation type?",
    options: ["LL", "LR", "RL", "None"],
    answer: 3
  },
  {
    question: "What is the minimum number of nodes in an AVL Tree of height 4?",
    options: ["5", "8", "9", "10"],
    answer: 2
  },
  {
    question: "Which scenario causes a double rotation in AVL tree rebalancing?",
    options: ["RR", "LL", "LR or RL", "Height becomes zero"],
    answer: 2
  },
  {
    question: "Is it possible to have the same AVL Tree structure from different insertion orders?",
    options: ["No", "Yes", "Only in balanced cases", "Only for complete trees"],
    answer: 1
  },
  {
    question: "What is the key difference between an AVL tree and a Red-Black tree?",
    options: ["AVL supports only insertion", "Red-Black has stricter balancing", "AVL is more strictly balanced", "AVL is not a BST"],
    answer: 2
  },
  {
    question: "Which of these AVL operations can affect the tree height?",
    options: ["Insert", "Delete", "Rotate", "Both A and B"],
    answer: 3
  },
  {
    question: "What will be the new root after inserting 10, 20, 30 in an empty AVL tree (in order)?",
    options: ["10", "20", "30", "15"],
    answer: 1
  }
];
const hardQuestions = [
  {
    question: "What is the maximum number of rotations required to balance an AVL tree after insertion?",
    options: ["1", "2", "3", "4"],
    answer: 1
  },
  {
    question: "What is the balance factor of a node in an AVL tree?",
    options: ["Height of right subtree", "Height of left subtree", "Height(left) - Height(right)", "Height(right) - Height(left)"],
    answer: 2
  },
  {
    question: "Which AVL rotation is used when inserting into the left subtree of the left child?",
    options: ["Right Rotation", "Left Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 0
  },
  {
    question: "Which case requires a double rotation in AVL Trees?",
    options: ["LL", "RR", "LR", "RL"],
    answer: 2
  },
  {
    question: "After a deletion, how many nodes may need rebalancing in AVL tree?",
    options: ["One", "All nodes along the path from deleted node to root", "All leaf nodes", "All internal nodes"],
    answer: 1
  },
  {
    question: "Which traversal is most suitable to check AVL balance factors at each node?",
    options: ["In-order", "Pre-order", "Post-order", "Level-order"],
    answer: 2
  },
  {
    question: "An AVL tree with n nodes has a height of at most:",
    options: ["log₂(n)", "2log₂(n)", "log₂(n+1)", "1.44log₂(n)"],
    answer: 3
  },
  {
    question: "Insertions in AVL tree are more expensive than in BST due to:",
    options: ["Sorting", "Rotations", "Comparisons", "Traversals"],
    answer: 1
  },
  {
    question: "Which AVL rotation sequence handles RL imbalance?",
    options: ["Left", "Right", "Right-Left", "Left-Right"],
    answer: 2
  },
  {
    question: "Time complexity of AVL Tree insertion operation is:",
    options: ["O(log n)", "O(n)", "O(n log n)", "O(1)"],
    answer: 0
  },
  {
    question: "Which condition violates AVL property?",
    options: ["Balance Factor = 0", "Balance Factor = -1", "Balance Factor = +2", "Balance Factor = +1"],
    answer: 2
  },
  {
    question: "Which of the following is NOT true about AVL Trees?",
    options: ["They are self-balancing", "They can have duplicate keys", "They always have height log(n)", "They can degenerate into a linked list"],
    answer: 3
  },
  {
    question: "How many types of rotations exist in AVL Trees?",
    options: ["2", "3", "4", "5"],
    answer: 2
  },
  {
    question: "Which node becomes new root after RR rotation?",
    options: ["Original root", "Right child", "Left child", "Grandchild"],
    answer: 1
  },
  {
    question: "Which AVL case occurs when a node is inserted in the right of the left child?",
    options: ["LL", "LR", "RL", "RR"],
    answer: 1
  },
  {
    question: "What is the worst-case space complexity of an AVL Tree?",
    options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
    answer: 0
  },
  {
    question: "Which of these operations may cause AVL rotations?",
    options: ["Search", "Insertion", "Deletion", "Both B and C"],
    answer: 3
  },
  {
    question: "Which AVL case can occur after deleting a node from right subtree of right child?",
    options: ["LL", "RR", "RL", "LR"],
    answer: 0
  },
  {
    question: "What is the time complexity to find the k-th smallest element in AVL tree (with size metadata)?",
    options: ["O(n)", "O(log n)", "O(k)", "O(1)"],
    answer: 1
  },
  {
    question: "In AVL Trees, balance factor is updated:",
    options: ["During traversal", "After each rotation", "Only after deletion", "Only on insertions"],
    answer: 1
  },
  {
    question: "What is the minimum number of nodes in an AVL tree of height 4?",
    options: ["10", "11", "12", "13"],
    answer: 1
  },
  {
    question: "Which AVL case occurs when insertion is in left subtree of right child?",
    options: ["RR", "RL", "LL", "LR"],
    answer: 1
  },
  {
    question: "When does the height of an AVL tree increase after insertion?",
    options: ["Always", "Never", "Only if no rotation happens", "Only if no duplicate"],
    answer: 2
  },
  {
    question: "Which is the most expensive AVL operation (in terms of rotations)?",
    options: ["Insertion", "Deletion", "Search", "Traversal"],
    answer: 1
  },
  {
    question: "Which rotation is applied for Left-Left imbalance?",
    options: ["Left Rotation", "Right Rotation", "Left-Right Rotation", "Right-Left Rotation"],
    answer: 1
  },
  {
    question: "What makes AVL tree stricter than Red-Black Trees?",
    options: ["Color constraints", "Balance factor limits", "Parent pointer requirement", "Rotational complexity"],
    answer: 1
  },
  {
    question: "Is it possible to create an AVL tree with height 2 using only 2 nodes?",
    options: ["Yes", "No", "Only if balanced", "Depends on order"],
    answer: 1
  },
  {
    question: "After a rotation, what must be updated in AVL nodes?",
    options: ["Only data", "Pointers", "Height and balance factor", "Keys only"],
    answer: 2
  },
  {
    question: "What is the effect of deleting a leaf node from AVL tree?",
    options: ["May unbalance", "No effect", "Always requires rotation", "Converts to skew tree"],
    answer: 0
  },
  {
    question: "Which property of AVL Tree ensures logarithmic height?",
    options: ["Binary Search Rule", "Balance Factor Constraint", "In-order Traversal", "Complete Tree Structure"],
    answer: 1
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
