const easyQuestions = [
  {
    question: "What is the primary purpose of a hash table?",
    options: ["Sorting data", "Storing data sequentially", "Fast data retrieval", "Compressing data"],
    answer: 2
  },
  {
    question: "Which data structure is typically used to implement a hash table?",
    options: ["Stack", "Queue", "Array", "Tree"],
    answer: 2
  },
  {
    question: "A good hash function should:",
    options: ["Generate only even numbers", "Cause many collisions", "Be fast and minimize collisions", "Always return the same value"],
    answer: 2
  },
  {
    question: "In a hash table, a collision occurs when:",
    options: ["A value is deleted", "A key is missing", "Two keys map to the same index", "A key is too long"],
    answer: 2
  },
  {
    question: "What is the typical time complexity for searching in a hash table?",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which of the following is not a collision resolution strategy?",
    options: ["Chaining", "Linear probing", "Hash multiplication", "Quadratic probing"],
    answer: 2
  },
  {
    question: "Which method uses linked lists to handle collisions in a hash table?",
    options: ["Linear probing", "Chaining", "Double hashing", "Quadratic probing"],
    answer: 1
  },
  {
    question: "In linear probing, the next index is checked by:",
    options: ["Skipping two positions", "Adding a constant step size", "Doubling the index", "Random jumps"],
    answer: 1
  },
  {
    question: "Which of these is most likely to cause clustering in hash tables?",
    options: ["Chaining", "Linear probing", "Separate chaining", "Open addressing"],
    answer: 1
  },
  {
    question: "The load factor in a hash table is defined as:",
    options: ["Size of array", "Number of collisions", "Number of elements / size of table", "Hash key length"],
    answer: 2
  },
  {
    question: "Which of these is a disadvantage of a hash table?",
    options: ["Fast retrieval", "Memory efficiency", "Inefficient for range queries", "Easy implementation"],
    answer: 2
  },
  {
    question: "If load factor exceeds a threshold, we usually:",
    options: ["Shrink the table", "Rehash", "Remove elements", "Change hashing method"],
    answer: 1
  },
  {
    question: "Which of the following is used for double hashing?",
    options: ["One hash function", "Two hash functions", "Linear increment", "Binary trees"],
    answer: 1
  },
  {
    question: "Which is the best load factor to maintain performance in a hash table?",
    options: ["0.1", "0.5", "0.7", "1.5"],
    answer: 2
  },
  {
    question: "What does \"rehashing\" mean?",
    options: ["Reversing all values", "Changing the hashing technique", "Increasing table size and re-inserting all entries", "Deleting old keys"],
    answer: 2
  },
  {
    question: "In open addressing, deleted keys must be:",
    options: ["Ignored", "Rehashed", "Marked as deleted", "Added to a stack"],
    answer: 2
  },
  {
    question: "Which probing technique increases the index by a squared offset?",
    options: ["Linear probing", "Chaining", "Quadratic probing", "Rehashing"],
    answer: 2
  },
  {
    question: "Which situation is ideal for using a hash table?",
    options: ["When data is accessed in sorted order", "When frequent insertions and deletions occur", "When searching for keys is frequent", "When recursion is needed"],
    answer: 2
  },
  {
    question: "Hash tables are not good for:",
    options: ["Searching by key", "Finding minimum or maximum", "Inserting data", "Deleting a value"],
    answer: 1
  },
  {
    question: "Which of the following is true about keys in a hash table?",
    options: ["Keys must be integers", "Keys must be strings", "Keys must be unique", "Keys must be sorted"],
    answer: 2
  },
  {
    question: "Which data structure is best for implementing associative arrays?",
    options: ["Heap", "Tree", "Hash Table", "Queue"],
    answer: 2
  },
  {
    question: "What is the result of a good hashing technique?",
    options: ["More collisions", "Even key distribution", "Sorted values", "Constant memory usage"],
    answer: 1
  },
  {
    question: "Which of these is not required in open addressing?",
    options: ["A hash function", "An array", "Linked list", "Probe sequence"],
    answer: 2
  },
  {
    question: "If two keys hash to the same index and chaining is used, they are stored in:",
    options: ["Array", "Linked list at that index", "Stack", "Queue"],
    answer: 1
  },
  {
    question: "In double hashing, the second hash function should never return:",
    options: ["A zero", "An odd number", "A key", "A duplicate"],
    answer: 0
  },
  {
    question: "The hash function h(k) = k % m is called:",
    options: ["Division method", "Multiplication method", "Modulo shift", "Linear hash"],
    answer: 0
  },
  {
    question: "The worst-case time complexity of search in a hash table is:",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "Which data structure performs better than hash table for sorted data access?",
    options: ["Linked list", "Binary Search Tree", "Stack", "Queue"],
    answer: 1
  },
  {
    question: "What must you ensure before applying the modulo operation in hashing?",
    options: ["Value is odd", "Value is negative", "Value is an integer", "Value is not null"],
    answer: 2
  },
  {
    question: "The primary reason for choosing a prime number as table size in hashing is:",
    options: ["Easy to divide", "Prevent clustering", "Reduce memory", "Fast calculation"],
    answer: 1
  }
];
const mediumQuestions = [
  {
    question: "Which of the following is NOT a valid collision resolution technique in hash tables?",
    options: ["Linear probing", "Binary Search", "Quadratic probing", "Double hashing"],
    answer: 1
  },
  {
    question: "Which condition causes primary clustering in open addressing?",
    options: ["Separate chaining", "Quadratic probing", "Linear probing", "Hash function"],
    answer: 2
  },
  {
    question: "What is the worst-case time complexity for search in a hash table using chaining?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Double hashing is a method of:",
    options: ["Rehashing", "Separate chaining", "Open addressing", "Key transformation"],
    answer: 2
  },
  {
    question: "Which of these is used as the second hash function in double hashing?",
    options: ["Prime number modulus", "Random value", "Constant", "Next odd number"],
    answer: 0
  },
  {
    question: "In quadratic probing, the interval between probes increases:",
    options: ["Exponentially", "Linearly", "Quadratically", "Logarithmically"],
    answer: 2
  },
  {
    question: "What is a disadvantage of open addressing over chaining?",
    options: ["Wastes memory", "Needs linked lists", "Cannot handle load factor > 1", "Complex deletion logic"],
    answer: 2
  },
  {
    question: "Which of the following does NOT affect the performance of a hash table?",
    options: ["Hash function", "Load factor", "Table size", "Queue implementation"],
    answer: 3
  },
  {
    question: "In separate chaining, what data structure is typically used for storing collided elements?",
    options: ["Stack", "Queue", "Linked list", "Array"],
    answer: 2
  },
  {
    question: "Which of the following can reduce collisions in a hash table?",
    options: ["Small table size", "Hash function with high clustering", "Large load factor", "Good hash function"],
    answer: 3
  },
  {
    question: "Which of the following hash functions is better for uniformly distributing keys?",
    options: ["h(k) = k", "h(k) = k mod 10", "h(k) = k mod m (m is prime)", "h(k) = 1"],
    answer: 2
  },
  {
    question: "Which of these can be a valid load factor value?",
    options: ["-1", "2.5", "0.8", "100"],
    answer: 2
  },
  {
    question: "Which of the following is NOT true about rehashing?",
    options: ["It increases table size", "It keeps old hash codes", "It reduces load factor", "It reinserts all elements"],
    answer: 1
  },
  {
    question: "Which statement is true about dynamic resizing in hash tables?",
    options: ["It decreases time complexity", "It maintains constant load factor", "It reduces key size", "It replaces hash function"],
    answer: 1
  },
  {
    question: "When a hash table has too many collisions, it results in:",
    options: ["Load factor = 0", "Wasted memory", "Poor performance", "Improved access time"],
    answer: 2
  },
  {
    question: "What is the main advantage of using a prime number as hash table size?",
    options: ["More compact memory", "Fewer collisions", "Faster search", "Simplified coding"],
    answer: 1
  },
  {
    question: "The best-case time complexity for search in a hash table is:",
    options: ["O(log n)", "O(n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which technique is most suitable when memory is not a constraint?",
    options: ["Open addressing", "Linear probing", "Chaining with linked lists", "Quadratic probing"],
    answer: 2
  },
  {
    question: "The term “secondary clustering” is associated with which method?",
    options: ["Chaining", "Linear probing", "Quadratic probing", "Double hashing"],
    answer: 2
  },
  {
    question: "Which operation is the most challenging in open addressing hash tables?",
    options: ["Insertion", "Deletion", "Searching", "Display"],
    answer: 1
  },
  {
    question: "Which of these hashing methods avoids both primary and secondary clustering?",
    options: ["Linear probing", "Quadratic probing", "Double hashing", "Chaining"],
    answer: 2
  },
  {
    question: "A poor hash function can lead to:",
    options: ["Faster lookups", "Uniform distribution", "More collisions", "Reduced table size"],
    answer: 2
  },
  {
    question: "Which of the following statements about collision is TRUE?",
    options: ["It happens only in double hashing", "It can be prevented fully", "It is common in hash tables", "It’s not a concern for small datasets"],
    answer: 2
  },
  {
    question: "The expected time to search for an element in a hash table with chaining is:",
    options: ["Θ(1 + α)", "O(n log n)", "Θ(log n)", "O(n^2)"],
    answer: 0
  },
  {
    question: "Which of the following statements is FALSE about hash tables?",
    options: ["Keys must be unique", "Load factor must always be ≤ 1", "Performance degrades with high load factor", "Rehashing improves efficiency"],
    answer: 1
  },
  {
    question: "Which of the following operations is easiest in separate chaining but tricky in open addressing?",
    options: ["Insert", "Update", "Delete", "Hash"],
    answer: 2
  },
  {
    question: "Which of the following is used to handle overflow in a hash table?",
    options: ["Hash splitting", "Clustering", "Collision resolution", "Key compression"],
    answer: 2
  },
  {
    question: "The main reason for choosing a good hash function is:",
    options: ["Save memory", "Reduce time complexity", "Minimize collisions", "Increase load factor"],
    answer: 2
  },
  {
    question: "Which one is a disadvantage of using chaining in hash tables?",
    options: ["Load factor is always 1", "Extra memory for pointers", "Cannot store duplicate values", "Requires prime table size"],
    answer: 1
  },
  {
    question: "What will be the result of inserting duplicate keys into a hash table?",
    options: ["Error", "Overwrites value (if allowed)", "Infinite loop", "Causes clustering"],
    answer: 1
  }
];
const hardQuestions = [
  {
    question: "Which of the following scenarios causes the highest probability of collision in a hash table?",
    options: [
      "Prime-sized table with modulo hashing",
      "Power-of-two sized table with poor hash function",
      "Double hashing with good distribution",
      "Linear probing with prime-sized table"
    ],
    answer: 1
  },
  {
    question: "If a hash table uses chaining and all keys hash to the same bucket, what is the worst-case time complexity for search?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which of the following is a disadvantage of using open addressing over chaining?",
    options: ["Extra memory needed for pointers", "Clustering", "Poor memory utilization", "Requires dynamic memory allocation"],
    answer: 1
  },
  {
    question: "Double hashing uses which of the following formulae?",
    options: [
      "h(k, i) = (h1(k) + i) % m",
      "h(k, i) = (h1(k) + i × h2(k)) % m",
      "h(k, i) = (h1(k) - i × h2(k)) % m",
      "h(k, i) = (h2(k) + i × h1(k)) % m"
    ],
    answer: 1
  },
  {
    question: "Cuckoo hashing resolves collisions by:",
    options: ["Linear probing", "Quadratic probing", "Using two hash functions and relocation", "Using hash chaining"],
    answer: 2
  },
  {
    question: "Which probing technique is most prone to primary clustering?",
    options: ["Quadratic", "Linear", "Double hashing", "Rehashing"],
    answer: 1
  },
  {
    question: "In Robin Hood hashing, which item is replaced during a collision?",
    options: ["Newer item", "Older item", "Item farthest from its home", "Item nearest to its home"],
    answer: 2
  },
  {
    question: "If the load factor exceeds 1 in chaining, the average search time becomes:",
    options: ["Constant", "Logarithmic", "Linear", "Quadratic"],
    answer: 2
  },
  {
    question: "In a hash table with load factor α, expected search time for unsuccessful search using open addressing is:",
    options: ["1 / (1 - α)", "1 + α", "log(1 / (1 - α))", "α²"],
    answer: 0
  },
  {
    question: "What is the major issue in hash tables when storing floating-point keys directly?",
    options: ["Precision loss", "Key duplication", "Division by zero", "High memory usage"],
    answer: 0
  },
  {
    question: "In universal hashing, the family of hash functions is chosen:",
    options: ["At compile time", "Once per key", "Randomly at run time", "Based on key parity"],
    answer: 2
  },
  {
    question: "Which of the following hash collision resolution techniques suffers from secondary clustering?",
    options: ["Quadratic Probing", "Double Hashing", "Separate Chaining", "Linear Probing"],
    answer: 0
  },
  {
    question: "The efficiency of a hash table mainly depends on:",
    options: ["Number of keys", "Type of hash function", "Load factor", "All of the above"],
    answer: 3
  },
  {
    question: "What is the worst-case time for insertion in an open-addressed hash table with a bad hash function?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "In rehashing, which of the following remains unchanged?",
    options: ["Table size", "Load factor", "Hash function", "Number of keys"],
    answer: 3
  },
  {
    question: "A perfect hash function maps:",
    options: [
      "All keys to a fixed address",
      "Colliding keys to same slot",
      "Distinct keys to distinct slots",
      "Equal keys to different slots"
    ],
    answer: 2
  },
  {
    question: "Which approach is generally used to implement dynamic hash tables?",
    options: ["Double hashing", "Extensible hashing", "Quadratic probing", "Rehashing"],
    answer: 1
  },
  {
    question: "In a hash table using quadratic probing, what is the issue with even table sizes?",
    options: ["Infinite loop", "Non-termination", "Not all slots get probed", "Increased clustering"],
    answer: 2
  },
  {
    question: "Which of the following techniques uses bucket splitting and directory doubling?",
    options: ["Linear hashing", "Extensible hashing", "Cuckoo hashing", "Robin Hood hashing"],
    answer: 1
  },
  {
    question: "Which of the following best describes the purpose of a hash function in a hash table?",
    options: ["Reduce memory", "Map key to index efficiently", "Sort data", "Avoid duplicates"],
    answer: 1
  },
  {
    question: "The time complexity of inserting into a hash table using chaining with balanced BSTs in buckets is:",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "In a 2-level perfect hashing system, the second level handles:",
    options: [
      "Randomization",
      "Collision resolution with separate perfect hash",
      "Rehashing",
      "Duplicate key prevention"
    ],
    answer: 1
  },
  {
    question: "What’s the ideal load factor in open addressing to avoid too many collisions?",
    options: ["1.0", "0.75", "0.5", "0.25"],
    answer: 2
  },
  {
    question: "Which of the following is true for dynamic resizing of hash tables?",
    options: ["Reduces collisions immediately", "Requires full rehashing", "Increases insertion speed", "Removes deleted keys"],
    answer: 1
  },
  {
    question: "In cuckoo hashing, what causes insertion to restart with a new hash function?",
    options: ["High load factor", "Duplicate key", "Cycle detection during insertion", "Large key value"],
    answer: 2
  },
  {
    question: "Which method is not suitable if the key space is large and sparsely populated?",
    options: ["Hashing", "Direct addressing", "Binary Search Tree", "Trie"],
    answer: 1
  },
  {
    question: "Which of the following data structures best suits implementing a hash table for caching?",
    options: ["AVL Tree", "Splay Tree", "Hash Table + Doubly Linked List", "Skip List"],
    answer: 2
  },
  {
    question: "When using a hash table with chaining, which condition best indicates the need for resizing?",
    options: [
      "Load factor < 1",
      "Average chain length > threshold",
      "Table is full",
      "Collision count = 0"
    ],
    answer: 1
  },
  {
    question: "In extendible hashing, what does the global depth indicate?",
    options: [
      "Max number of elements in a bucket",
      "Number of buckets",
      "Number of bits used from hash value",
      "Number of hash functions used"
    ],
    answer: 2
  },
  {
    question: "What causes clustering in linear probing?",
    options: [
      "Use of bad hash functions",
      "Too small table size",
      "Keys forming contiguous occupied slots",
      "Poor memory alignment"
    ],
    answer: 2
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
