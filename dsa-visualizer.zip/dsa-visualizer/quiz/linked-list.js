const easyQuestions = [
  {
    question: "What is a singly linked list?",
    options: [
      "A list where each node has two pointers",
      "A list where each node points to the next node",
      "A list where each node points to both next and previous nodes",
      "A list implemented using arrays"
    ],
    answer: 1
  },
  {
    question: "Which of the following is true for a singly linked list?",
    options: [
      "Elements are stored in contiguous memory",
      "Insertion is not possible",
      "Nodes point to the next node",
      "All nodes point to the previous node"
    ],
    answer: 2
  },
  {
    question: "What is the time complexity of inserting a node at the beginning of a singly linked list?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Which data structure is used to implement a singly linked list?",
    options: ["Array", "Queue", "Structure or Class with pointer", "Stack"],
    answer: 2
  },
  {
    question: "What does the last node of a singly linked list point to?",
    options: ["First node", "Itself", "NULL", "Random node"],
    answer: 2
  },
  {
    question: "What does each node in a singly linked list typically contain?",
    options: [
      "Data and memory address of next node",
      "Only data",
      "Data and previous node address",
      "Data and index"
    ],
    answer: 0
  },
  {
    question: "Which operation is not efficient in a singly linked list (without tail pointer)?",
    options: [
      "Insertion at beginning",
      "Insertion at end",
      "Deletion at beginning",
      "Traversal"
    ],
    answer: 1
  },
  {
    question: "Which pointer is used to keep track of the first node in a singly linked list?",
    options: ["current", "temp", "head", "tail"],
    answer: 2
  },
  {
    question: "Which of the following is used to traverse a singly linked list?",
    options: ["Loop variable", "Head node pointer", "Temporary pointer", "All of the above"],
    answer: 3
  },
  {
    question: "How is memory allocated for a singly linked list node?",
    options: ["At compile-time", "At runtime", "In the stack", "Through arrays"],
    answer: 1
  },
  {
    question: "Which keyword is used to create a new node in C++?",
    options: ["malloc", "new", "create", "node"],
    answer: 1
  },
  {
    question: "Which keyword is used to delete a node in C++?",
    options: ["delete", "free", "remove", "pop"],
    answer: 0
  },
  {
    question: "Which of the following is true for singly linked lists?",
    options: [
      "Easy to access the middle element directly",
      "Can grow dynamically",
      "Size must be known beforehand",
      "Cannot be used to implement stacks"
    ],
    answer: 1
  },
  {
    question: "Which operation is easiest in a singly linked list?",
    options: [
      "Accessing last element",
      "Deleting last element",
      "Inserting at beginning",
      "Accessing random element"
    ],
    answer: 2
  },
  {
    question: "Which of these indicates an empty singly linked list?",
    options: ["head = -1", "head = 1", "head = NULL", "head = 0"],
    answer: 2
  },
  {
    question: "What is the output if we print a singly linked list with only one node?",
    options: ["NULL", "Data of that node", "Error", "Data and memory"],
    answer: 1
  },
  {
    question: "In which direction can we traverse a singly linked list?",
    options: ["Forward", "Backward", "Both directions", "Random"],
    answer: 0
  },
  {
    question: "If the head node is NULL, what does it mean?",
    options: ["Linked list is full", "Linked list is empty", "Error", "Node is lost"],
    answer: 1
  },
  {
    question: "What is the correct way to access the data of a node in C++?",
    options: ["node.data", "*node.data", "node->data", "&node->data"],
    answer: 2
  },
  {
    question: "Which of the following is true for singly linked list?",
    options: [
      "Nodes are stored in array",
      "Random access is possible",
      "Insertion is fixed",
      "Dynamic memory is used"
    ],
    answer: 3
  },
  {
    question: "What is required to reverse a singly linked list?",
    options: ["Stack", "Recursion or iteration", "Queue", "Array"],
    answer: 1
  },
  {
    question: "What is the minimum number of nodes in a non-empty singly linked list?",
    options: ["0", "1", "2", "3"],
    answer: 1
  },
  {
    question: "What is the default value of next pointer in a newly created node?",
    options: ["0", "-1", "NULL", "Head"],
    answer: 2
  },
  {
    question: "What is the time complexity for deleting a node from the beginning?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "How can we find the length of a singly linked list?",
    options: ["Using a loop", "Using recursion", "Both A and B", "Not possible"],
    answer: 2
  },
  {
    question: "What will happen if you try to delete a node from an empty list?",
    options: ["Deletes NULL", "Error or exception", "Deletes head", "Nothing happens"],
    answer: 1
  },
  {
    question: "Which node can be accessed first in a singly linked list?",
    options: ["Last", "Middle", "First", "Random"],
    answer: 2
  },
  {
    question: "What type of memory is used by singly linked lists in C/C++?",
    options: ["Static memory", "Heap memory", "Register memory", "Stack memory"],
    answer: 1
  },
  {
    question: "Which of these is not an operation on a singly linked list?",
    options: ["Insert", "Delete", "Merge", "Swap array index"],
    answer: 3
  },
  {
    question: "What is a major advantage of singly linked lists over arrays?",
    options: ["Fixed size", "Faster access", "Dynamic size", "Indexing"],
    answer: 2
  }
];


const mediumQuestions = [
  {
    question: "What is the time complexity of searching for an element in a singly linked list?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which of the following is the correct way to delete a node in the middle of a singly linked list?",
    options: [
      "Free the node before updating the links",
      "Update previous node’s next pointer, then free the current node",
      "Only free the current node",
      "Update next node’s pointer to skip current node"
    ],
    answer: 1
  },
  {
    question: "In a singly linked list, what is the best method to insert a node after a given node?",
    options: [
      "Update head pointer",
      "Change previous node’s pointer",
      "Change the next pointer of the given node",
      "Traverse to the end"
    ],
    answer: 2
  },
  {
    question: "If a singly linked list contains `n` nodes, how many pointers are updated when inserting a node at the beginning?",
    options: ["1", "2", "n", "0"],
    answer: 0
  },
  {
    question: "How can you find the middle element in a singly linked list in one pass?",
    options: ["Using a counter", "Using two pointers (slow and fast)", "By recursion", "Using a stack"],
    answer: 1
  },
  {
    question: "What will happen if the head pointer is lost in a singly linked list?",
    options: [
      "Only the first node is lost",
      "Entire list is inaccessible",
      "Only the tail is lost",
      "Memory is freed"
    ],
    answer: 1
  },
  {
    question: "Which data structure is ideal for implementing a stack using a singly linked list?",
    options: [
      "Circular list",
      "Doubly list",
      "Inserting at tail",
      "Inserting/deleting at head"
    ],
    answer: 3
  },
  {
    question: "How can you reverse a singly linked list?",
    options: [
      "Using stack",
      "Iteratively by changing links",
      "Recursively",
      "All of the above"
    ],
    answer: 3
  },
  {
    question: "What is the key disadvantage of singly linked lists over arrays?",
    options: [
      "Requires more memory",
      "Slow access to random elements",
      "Fixed size",
      "Not suitable for dynamic memory"
    ],
    answer: 1
  },
  {
    question: "When deleting the last node in a singly linked list, what should be updated?",
    options: [
      "Head pointer",
      "Tail pointer",
      "Second last node’s next pointer",
      "None"
    ],
    answer: 2
  },
  {
    question: "In a singly linked list, which operation is more efficient compared to arrays?",
    options: [
      "Accessing nth element",
      "Insertion at end",
      "Deletion at beginning",
      "Searching"
    ],
    answer: 2
  },
  {
    question: "Which of the following cannot be performed efficiently on singly linked list?",
    options: [
      "Insertion at front",
      "Insertion at end without tail",
      "Deletion at front",
      "Traversing forward"
    ],
    answer: 1
  },
  {
    question: "What is the minimum number of nodes needed to delete the second node in a singly linked list?",
    options: ["1", "2", "3", "n"],
    answer: 1
  },
  {
    question: "Which condition indicates that a singly linked list is empty?",
    options: [
      "Head points to NULL",
      "Last node points to NULL",
      "Head and tail are same",
      "List has one node"
    ],
    answer: 0
  },
  {
    question: "What will be the time complexity to delete a node at position `n` in singly linked list?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "Which of the following is *not* a valid operation on singly linked list?",
    options: [
      "Random access in O(1)",
      "Insert at beginning",
      "Insert at end",
      "Delete at beginning"
    ],
    answer: 0
  },
  {
    question: "What is the time complexity of reversing a singly linked list iteratively?",
    options: ["O(1)", "O(n)", "O(n log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Why is memory efficient deletion difficult in singly linked lists?",
    options: [
      "Because of random access",
      "No backward link",
      "Extra pointer required",
      "It uses arrays"
    ],
    answer: 1
  },
  {
    question: "What is the worst-case time complexity to search an element in singly linked list?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which technique is used in finding loops in singly linked lists?",
    options: [
      "DFS",
      "Floyd’s cycle-finding algorithm",
      "Inorder traversal",
      "Hashing"
    ],
    answer: 1
  },
  {
    question: "What is returned when a function tries to delete a node from an empty list?",
    options: ["NULL", "Head", "Runtime Error", "Garbage value"],
    answer: 0
  },
  {
    question: "How to delete a node without head pointer but with access to that node only?",
    options: [
      "Not possible",
      "Copy data from next node and delete next",
      "Use tail pointer",
      "Skip current node"
    ],
    answer: 1
  },
  {
    question: "What happens if we access a freed node in a singly linked list?",
    options: ["Segmentation fault", "Garbage value", "Valid data", "Zero"],
    answer: 0
  },
  {
    question: "Which traversal method is applicable to singly linked lists?",
    options: ["Forward", "Backward", "Random", "Both forward and backward"],
    answer: 0
  },
  {
    question: "Which memory allocation strategy is commonly used in linked lists?",
    options: ["Contiguous", "Static", "Dynamic (heap)", "Constant"],
    answer: 2
  },
  {
    question: "Which one is correct about the tail node in a singly linked list?",
    options: [
      "Points to previous node",
      "Always NULL",
      "Stores head address",
      "Links both ways"
    ],
    answer: 1
  },
  {
    question: "What is the output if you delete the head node in a singly linked list and return the new head?",
    options: ["NULL", "Old head", "Second node", "Last node"],
    answer: 2
  },
  {
    question: "What is the result of inserting a new node at the end of a singly linked list?",
    options: [
      "List remains unchanged",
      "Tail node points to new node",
      "Head node is updated",
      "New node points to NULL and becomes tail"
    ],
    answer: 3
  },
  {
    question: "What must be done before freeing a node in a singly linked list?",
    options: [
      "Print it",
      "Disconnect it from the list",
      "Reverse the list",
      "Nothing"
    ],
    answer: 1
  },
  {
    question: "Which approach helps reduce the time complexity of adding at end in singly linked list?",
    options: [
      "Adding random nodes",
      "Using array",
      "Maintaining a tail pointer",
      "Sorting the list"
    ],
    answer: 2
  }
];


const hardQuestions = [
  {
    question: "Which method is best for detecting a loop in a singly linked list in O(n) time and O(1) space?",
    options: ["Recursion", "Hashing node addresses", "Floyd’s Cycle-Finding Algorithm", "Reversing the list"],
    answer: 2
  },
  {
    question: "What happens when you try to delete a node in a singly linked list given only access to that node?",
    options: ["Cannot be done", "Set it to NULL", "Copy data from next node and delete the next node", "Use recursion to backtrack"],
    answer: 2
  },
  {
    question: "What is the time complexity to reverse a singly linked list of size *n* iteratively?",
    options: ["O(log n)", "O(n²)", "O(n)", "O(1)"],
    answer: 2
  },
  {
    question: "Which of the following operations is not feasible in O(1) time in a singly linked list?",
    options: ["Insert at head", "Delete after given node", "Search for a node", "Insert after given node"],
    answer: 2
  },
  {
    question: "You are given the head of a singly linked list. Which method would you use to find the middle node in a single traversal?",
    options: ["Recursion", "Stack", "Fast and Slow Pointer", "Length calculation"],
    answer: 2
  },
  {
    question: "In which case does a singly linked list use more memory than an array?",
    options: ["When storing integers", "When list is empty", "Always", "When there is frequent dynamic resizing"],
    answer: 0
  },
  {
    question: "What is the time complexity of detecting and removing a loop in a singly linked list using Floyd’s Algorithm?",
    options: ["O(1)", "O(n log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "What is the most efficient way to delete the nth node from the end of a singly linked list in one pass?",
    options: ["Reverse the list", "Use recursion", "Use two pointers with a gap of n", "Count length and subtract"],
    answer: 2
  },
  {
    question: "If a singly linked list has a cycle, which node can be identified as part of the cycle using Floyd’s algorithm?",
    options: ["Head", "Tail", "Meeting point of two pointers", "The last node"],
    answer: 2
  },
  {
    question: "What is the effect of repeatedly reversing the pointers of a singly linked list at each node?",
    options: ["Cycles the list", "Deletes the list", "Reverses the list", "Results in undefined behavior"],
    answer: 2
  },
  {
    question: "If we have access only to the head of a singly linked list, what is the worst-case time complexity to delete the last node?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "In a singly linked list with *n* nodes, how many pointer reassignments are required to reverse the list?",
    options: ["n", "n - 1", "2n", "n + 1"],
    answer: 0
  },
  {
    question: "How many extra pointers are required to reverse a singly linked list iteratively (excluding head)?",
    options: ["0", "1", "2", "3"],
    answer: 3
  },
  {
    question: "What happens if you break the last node’s pointer in a singly linked list with a cycle?",
    options: ["List becomes doubly linked", "Infinite loop", "Cycle breaks", "List deletes itself"],
    answer: 2
  },
  {
    question: "What is the space complexity of recursive reversal of a singly linked list?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "When deleting a node from the middle of a singly linked list, what is required?",
    options: ["Pointer to head", "Pointer to previous node", "Pointer to next node", "Size of list"],
    answer: 1
  },
  {
    question: "In a singly linked list, what’s the best way to detect palindrome data in the list?",
    options: ["Use stack", "Recursion", "Reverse second half", "All of the above"],
    answer: 3
  },
  {
    question: "What is the worst-case time complexity to search for an element in a sorted singly linked list?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "Can a singly linked list be circular?",
    options: ["No", "Yes, if last node points to head", "Only if doubly linked", "Only with a special pointer"],
    answer: 1
  },
  {
    question: "In which scenario will the fast and slow pointer meet?",
    options: ["Always meet at tail", "Only in circular list", "When loop exists", "Never meet"],
    answer: 2
  },
  {
    question: "How many null pointers exist in a singly linked list of size *n* (non-circular)?",
    options: ["0", "1", "n", "n + 1"],
    answer: 1
  },
  {
    question: "Which of the following cannot be efficiently implemented using a singly linked list?",
    options: ["Stack", "Queue", "Deque", "Polynomial"],
    answer: 2
  },
  {
    question: "Which operation would require traversing the entire list?",
    options: ["Insert at head", "Delete from front", "Search for a value", "Print first element"],
    answer: 2
  },
  {
    question: "To remove duplicates from an unsorted singly linked list, what is the optimal approach?",
    options: ["Recursion", "Brute force O(n²)", "Hashing", "Binary Search"],
    answer: 2
  },
  {
    question: "What is the best case time to find the k-th node from the end of a singly linked list?",
    options: ["O(1)", "O(k)", "O(n)", "O(n - k)"],
    answer: 1
  },
  {
    question: "In a recursive delete function for singly linked list, what causes stack overflow?",
    options: ["Too many nodes", "Infinite recursion", "Stack misuse", "Tail recursion"],
    answer: 1
  },
  {
    question: "What’s the key difference between an iterative and recursive implementation of reverse()?",
    options: ["Speed", "Memory usage", "Stack usage", "All of the above"],
    answer: 3
  },
  {
    question: "What property ensures that no node in a singly linked list points to itself?",
    options: ["Acyclic structure", "Null termination", "Head pointer", "Unique data"],
    answer: 0
  },
  {
    question: "What happens if you accidentally delete a node in a looped singly linked list without breaking the loop?",
    options: ["Loop increases", "Loop continues", "Memory leak", "All of the above"],
    answer: 3
  },
  {
    question: "How can you split a singly linked list into two halves in O(n) time?",
    options: ["Count and split", "Stack", "Fast and slow pointers", "Sorting"],
    answer: 2
  }
];



let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
