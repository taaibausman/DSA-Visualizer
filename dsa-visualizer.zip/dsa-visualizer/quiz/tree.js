const easyQuestions = [
  {
    question: "Which of the following is not a type of tree?",
    options: ["Binary Tree", "AVL Tree", "Graph Tree", "B-Tree"],
    answer: 2
  },
  {
    question: "A tree is a:",
    options: ["Linear data structure", "Circular data structure", "Hierarchical data structure", "None"],
    answer: 2
  },
  {
    question: "The topmost node in a tree is called:",
    options: ["Parent node", "Root node", "Leaf node", "Sibling node"],
    answer: 1
  },
  {
    question: "A node with no children is called:",
    options: ["Internal node", "Root node", "Leaf node", "Parent node"],
    answer: 2
  },
  {
    question: "The number of edges from root to a node is called:",
    options: ["Height", "Depth", "Level", "Path length"],
    answer: 1
  },
  {
    question: "In a binary tree, each node has at most:",
    options: ["1 child", "2 children", "3 children", "No limit"],
    answer: 1
  },
  {
    question: "Which traversal method visits the root before its children?",
    options: ["Inorder", "Preorder", "Postorder", "Level order"],
    answer: 1
  },
  {
    question: "What is the maximum number of nodes in a binary tree of height ‘h’?",
    options: ["2^h", "2^h - 1", "h", "h^2"],
    answer: 1
  },
  {
    question: "Which of the following trees is always balanced?",
    options: ["Binary Tree", "AVL Tree", "Tree", "Graph"],
    answer: 1
  },
  {
    question: "Inorder traversal of a binary search tree gives:",
    options: ["Random order", "Descending order", "Sorted order", "Preorder"],
    answer: 2
  }


];
const mediumQuestions = [
      {
    question: "The height of a tree with only root node is:",
    options: ["1", "0", "-1", "2"],
    answer: 1
  },
  {
    question: "Which of the following is not a tree traversal method?",
    options: ["Inorder", "Preorder", "Postorder", "Reorder"],
    answer: 3
  },
  {
    question: "A complete binary tree has all levels filled except possibly the:",
    options: ["Last level", "Second level", "Root", "First level"],
    answer: 0
  },
  {
    question: "A binary tree with ‘n’ nodes has how many edges?",
    options: ["n", "n-1", "n+1", "2n"],
    answer: 1
  },
  {
    question: "Which of these trees maintains sorted order?",
    options: ["AVL", "Binary Search Tree", "Both A and B", "None"],
    answer: 2
  },
  {
    question: "In postorder traversal, root is visited:",
    options: ["First", "Middle", "Last", "Not at all"],
    answer: 2
  },
  {
    question: "A full binary tree with n internal nodes has how many leaf nodes?",
    options: ["n", "n + 1", "2n", "2n + 1"],
    answer: 1
  },
  {
    question: "How many children does a leaf node have?",
    options: ["2", "1", "0", "Infinite"],
    answer: 2
  },
  {
    question: "Which is used to construct an expression tree?",
    options: ["Infix", "Prefix", "Postfix", "Both B and C"],
    answer: 3
  },
  {
    question: "Which traversal is best for copying a tree?",
    options: ["Inorder", "Postorder", "Preorder", "None"],
    answer: 2
  }

];
const hardQuestions = [
      {
    question: "A node’s children are called:",
    options: ["Parents", "Leaves", "Descendants", "Siblings"],
    answer: 2
  },
  {
    question: "Which traversal requires a queue?",
    options: ["Preorder", "Level order", "Postorder", "Inorder"],
    answer: 1
  },
  {
    question: "Which data structure is used in DFS (tree traversal)?",
    options: ["Queue", "Stack", "Array", "Hashmap"],
    answer: 1
  },
  {
    question: "Height of a tree is the number of edges in the longest path from root to:",
    options: ["Any node", "A leaf", "Root", "Internal node"],
    answer: 1
  },
  {
    question: "In a full binary tree, each node has:",
    options: ["0 or 2 children", "At most 3 children", "At least 2 children", "No child"],
    answer: 0
  },
  {
    question: "Minimum number of nodes in a binary tree of height h is:",
    options: ["h", "h+1", "h-1", "1"],
    answer: 1
  },
  {
    question: "Which of the following is not true about a binary search tree?",
    options: ["Left < root < right", "Duplicates allowed", "Inorder gives sorted", "Left is smaller"],
    answer: 1
  },
  {
    question: "Which of the following is used to balance a tree?",
    options: ["Queue", "AVL rotations", "Stack", "BFS"],
    answer: 1
  },
  {
    question: "Which one is not true about leaf nodes?",
    options: ["They are external nodes", "They have no child", "They always have siblings", "They may be at different levels"],
    answer: 2
  },
  {
    question: "Which is a characteristic of binary tree but not general tree?",
    options: ["At most 2 children", "Unlimited children", "Nodes are unordered", "Nodes have unique labels"],
    answer: 0
  }
];

let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
