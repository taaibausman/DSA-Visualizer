const easyQuestions = [
  {
    question: "What is the maximum number of children a node in a BST can have?",
    options: ["1", "2", "3", "4"],
    answer: 1
  },
  {
    question: "Which traversal of BST gives the sorted order of elements?",
    options: ["Preorder", "Inorder", "Postorder", "Level-order"],
    answer: 1
  },
  {
    question: "In a BST, where are smaller elements placed with respect to the root?",
    options: ["Left", "Right", "Center", "Anywhere"],
    answer: 0
  },
  {
    question: "BST stands for:",
    options: ["Binary Sequential Tree", "Binary Search Tree", "Binary Structured Tree", "Binary Stack Tree"],
    answer: 1
  },
  {
    question: "What is the time complexity to search an element in a balanced BST?",
    options: ["O(n)", "O(log n)", "O(n²)", "O(1)"],
    answer: 1
  },
  {
    question: "Which of the following is NOT a valid BST traversal?",
    options: ["Inorder", "Preorder", "Postorder", "Crossorder"],
    answer: 3
  },
  {
    question: "What is the time complexity for insertion in an unbalanced BST (worst-case)?",
    options: ["O(log n)", "O(n)", "O(1)", "O(n log n)"],
    answer: 1
  },
  {
    question: "What will be the inorder traversal of this BST: [10, 5, 15]?",
    options: ["5, 10, 15", "10, 5, 15", "15, 10, 5", "5, 15, 10"],
    answer: 0
  },
  {
    question: "BST is a type of:",
    options: ["Stack", "Queue", "Tree", "Graph"],
    answer: 2
  },
  {
    question: "Which of these is not an operation on a BST?",
    options: ["Insert", "Delete", "Traverse", "Enqueue"],
    answer: 3
  },
  {
    question: "What is the root in a BST?",
    options: ["The smallest node", "The first inserted node", "The last inserted node", "A node with two children only"],
    answer: 1
  },
  {
    question: "Can a BST have duplicate values by default?",
    options: ["Yes", "No", "Maybe", "Always"],
    answer: 1
  },
  {
    question: "What is the height of a single-node BST?",
    options: ["1", "0", "-1", "2"],
    answer: 1
  },
  {
    question: "What does the 'search' operation return if the element is not found in BST?",
    options: ["Null", "-1", "False", "All of the above (depending on implementation)"],
    answer: 3
  },
  {
    question: "Which of the following operations on BST can be recursive?",
    options: ["Search", "Insert", "Delete", "All of the above"],
    answer: 3
  },
  {
    question: "What is the maximum number of nodes in a BST of height h?",
    options: ["2^h", "2^h - 1", "h", "h²"],
    answer: 1
  },
  {
    question: "In BST, if a node has no left or right child, it is called a:",
    options: ["Root", "Internal Node", "Leaf", "None"],
    answer: 2
  },
  {
    question: "Which traversal technique is used to delete a BST safely?",
    options: ["Preorder", "Inorder", "Postorder", "Level-order"],
    answer: 2
  },
  {
    question: "The left subtree of a node in BST contains only:",
    options: ["Smaller values", "Greater values", "Equal values", "Random values"],
    answer: 0
  },
  {
    question: "The right subtree of a node in BST contains only:",
    options: ["Smaller values", "Greater values", "Equal values", "Random values"],
    answer: 1
  },
  {
    question: "Which node is replaced when deleting a node with two children in BST?",
    options: ["Root", "Leaf", "Inorder successor or predecessor", "Random node"],
    answer: 2
  },
  {
    question: "A BST with n nodes can have a height in the worst-case of:",
    options: ["log₂(n)", "√n", "n", "1"],
    answer: 2
  },
  {
    question: "Which of the following is true for BST?",
    options: ["Left child > Parent", "Right child < Parent", "Left child < Parent", "Right child = Parent"],
    answer: 2
  },
  {
    question: "BST is not suitable for:",
    options: ["Sorted data (without balancing)", "Random data", "Dynamic data", "All of the above"],
    answer: 0
  },
  {
    question: "What type of tree is BST if all elements are inserted in ascending order?",
    options: ["Balanced", "Full", "Skewed", "Complete"],
    answer: 2
  },
  {
    question: "How many BSTs can be made from 3 distinct keys?",
    options: ["1", "3", "5", "7"],
    answer: 2
  },
  {
    question: "BST can be constructed from which of the following data structures easily?",
    options: ["Array", "Stack", "Queue", "Linked List"],
    answer: 0
  },
  {
    question: "Which traversal is used to print all nodes of a BST in descending order?",
    options: ["Inorder", "Preorder", "Reverse Inorder", "Postorder"],
    answer: 2
  },
  {
    question: "What is the key property of a BST?",
    options: ["Parent is always less than both children", "Left < Root < Right", "All children are greater than parent", "Root is smallest"],
    answer: 1
  },
  {
    question: "Which of the following is the best case height for BST?",
    options: ["n", "n/2", "log₂(n)", "√n"],
    answer: 2
  }
];
const mediumQuestions = [
  {
    question: "What is the time complexity to search an element in a balanced BST with `n` nodes?",
    options: ["O(log n)", "O(n)", "O(n log n)", "O(1)"],
    answer: 0
  },
  {
    question: "Which traversal order of a BST results in sorted order output?",
    options: ["Preorder", "Postorder", "Inorder", "Level-order"],
    answer: 2
  },
  {
    question: "Inserting elements in ascending order into a BST creates:",
    options: ["A balanced tree", "A left-skewed tree", "A right-skewed tree", "A complete binary tree"],
    answer: 2
  },
  {
    question: "Which condition breaks the BST property during insertion?",
    options: ["left < root", "right > root", "left > root", "All nodes follow the property"],
    answer: 2
  },
  {
    question: "Which of the following is not a valid traversal for BST?",
    options: ["Level order", "Depth first", "Inorder", "Heap order"],
    answer: 3
  },
  {
    question: "BST worst-case height for `n` nodes occurs when:",
    options: ["Tree is complete", "All nodes inserted in random order", "Nodes inserted in sorted order", "Tree is balanced"],
    answer: 2
  },
  {
    question: "Which of the following is true after deleting a node with two children in a BST?",
    options: ["No changes in structure", "Replace node with its left child", "Replace node with its inorder successor", "Replace node with maximum element"],
    answer: 2
  },
  {
    question: "To find the minimum element in a BST, we move:",
    options: ["Right until NULL", "Left until NULL", "Both directions", "Cannot be determined"],
    answer: 1
  },
  {
    question: "Which BST operation may require rebalancing?",
    options: ["Insert", "Delete", "Both", "Traversal"],
    answer: 2
  },
  {
    question: "Which of these is not a self-balancing BST?",
    options: ["AVL Tree", "Red-Black Tree", "B-tree", "Binary Heap"],
    answer: 3
  },
  {
    question: "What is the average-case time complexity of deletion in a BST?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Which node in BST has the highest value?",
    options: ["Root", "Leftmost", "Rightmost", "Any leaf node"],
    answer: 2
  },
  {
    question: "In BST, which node will be visited last in preorder traversal?",
    options: ["Leftmost node", "Rightmost node", "Root", "Inorder successor"],
    answer: 1
  },
  {
    question: "BST can be constructed uniquely if we are given:",
    options: ["Inorder traversal", "Preorder + Inorder", "Postorder + Preorder", "Inorder + Level-order"],
    answer: 1
  },
  {
    question: "If a BST contains `n` nodes, the number of NULL pointers in its link representation is:",
    options: ["n", "n-1", "n+1", "2n"],
    answer: 2
  },
  {
    question: "Which traversal gives the descending order of BST?",
    options: ["Preorder", "Inorder", "Reverse inorder", "Postorder"],
    answer: 2
  },
  {
    question: "What is the height of a BST with 1 node?",
    options: ["-1", "0", "1", "Cannot say"],
    answer: 1
  },
  {
    question: "Maximum number of nodes in a BST of height h (0-based):",
    options: ["2^h", "2^(h+1) - 1", "2h", "h²"],
    answer: 1
  },
  {
    question: "Deleting a leaf node from a BST requires:",
    options: ["Replacing with child", "Replacing with root", "Simply removing the node", "Balancing"],
    answer: 2
  },
  {
    question: "Which node replaces a deleted node having only one child?",
    options: ["Root", "Parent", "Child", "None"],
    answer: 2
  },
  {
    question: "What is returned by searching a missing element in BST?",
    options: ["0", "NULL", "-1", "Garbage value"],
    answer: 1
  },
  {
    question: "A BST is also a:",
    options: ["Heap", "Graph", "Tree", "Both b and c"],
    answer: 3
  },
  {
    question: "Number of comparisons to find a key in a BST of height `h`:",
    options: ["h", "h+1", "log h", "2^h"],
    answer: 1
  },
  {
    question: "In which case does BST reduce to linear time for search?",
    options: ["Balanced", "Random insertions", "Sorted insertions", "Self-balanced"],
    answer: 2
  },
  {
    question: "Which of these is false about BST?",
    options: ["Left < root < right", "Duplicates are never allowed", "Traversal takes O(n)", "It is recursive in nature"],
    answer: 1
  },
  {
    question: "If we delete the root of a BST with two children, the new root is:",
    options: ["Left child", "Right child", "Inorder successor", "Parent"],
    answer: 2
  },
  {
    question: "Which one is not a valid BST application?",
    options: ["Dictionary", "Priority Queue", "Indexing", "Symbol table"],
    answer: 1
  },
  {
    question: "Height of a skewed BST with `n` nodes:",
    options: ["log n", "n", "√n", "n log n"],
    answer: 1
  },
  {
    question: "Which of the following affects time complexity in BST?",
    options: ["Node values", "Structure", "Tree depth", "Both b and c"],
    answer: 3
  },
  {
    question: "Which is the best-case time complexity for insertion in a BST?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n log n)"],
    answer: 2
  }
];
const hardQuestions = [
  {
    question: "In a BST, the maximum number of comparisons needed to search for a value in a skewed tree with n nodes is:",
    options: ["log₂n", "n/2", "n", "n - 1"],
    answer: 2
  },
  {
    question: "The time complexity to convert a BST to a sorted doubly linked list is:",
    options: ["O(n log n)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "Which traversal is used to create a sorted array from a BST?",
    options: ["Pre-order", "Post-order", "In-order", "Level-order"],
    answer: 2
  },
  {
    question: "The maximum height of a BST with `n` distinct keys is:",
    options: ["log₂n", "n", "√n", "n/2"],
    answer: 1
  },
  {
    question: "What is the best way to balance a BST for optimal operations?",
    options: ["Insert keys in decreasing order", "Use AVL trees", "Perform post-order traversal", "Delete duplicates"],
    answer: 1
  },
  {
    question: "Which of the following is not a characteristic of BST?",
    options: ["Duplicate keys allowed", "In-order traversal gives sorted data", "Left < root < right", "Each node has at most two children"],
    answer: 0
  },
  {
    question: "What happens if you insert elements into a BST in ascending order?",
    options: ["Tree is balanced", "Tree becomes left-skewed", "Tree becomes right-skewed", "Tree becomes circular"],
    answer: 2
  },
  {
    question: "Which condition must be checked when deleting a node with two children in BST?",
    options: ["Maximum of right subtree", "Minimum of left subtree", "Minimum of right subtree", "Height of tree"],
    answer: 2
  },
  {
    question: "The space complexity for recursive BST traversal is:",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Which operation is hardest to perform in a BST?",
    options: ["Insert", "Delete", "Search", "Traverse"],
    answer: 1
  },
  {
    question: "What does the successor of a node in BST refer to?",
    options: ["Previous smaller value", "Next larger value", "Left child", "Rightmost node"],
    answer: 1
  },
  {
    question: "Which BST property ensures efficient searching?",
    options: ["Self-balancing", "Complete structure", "Left subtree < root < right subtree", "Heap order"],
    answer: 2
  },
  {
    question: "What's the average time complexity of insertion in a random BST?",
    options: ["O(log n)", "O(n)", "O(1)", "O(n log n)"],
    answer: 0
  },
  {
    question: "Which case makes deletion in BST most complicated?",
    options: ["Leaf node", "Node with one child", "Node with two children", "Root node"],
    answer: 2
  },
  {
    question: "In BST, inserting `n` elements in random order results in height close to:",
    options: ["n", "√n", "log₂n", "n/2"],
    answer: 2
  },
  {
    question: "The in-order predecessor of a node is:",
    options: ["Node with smallest value", "Node with largest value", "Maximum of left subtree", "Minimum of right subtree"],
    answer: 2
  },
  {
    question: "For optimal BST performance, input should be:",
    options: ["Sorted", "Reverse-sorted", "Random", "Balanced"],
    answer: 3
  },
  {
    question: "A degenerate BST behaves like:",
    options: ["AVL Tree", "Heap", "Linked List", "Red-Black Tree"],
    answer: 2
  },
  {
    question: "Insertion of a duplicate element in BST typically:",
    options: ["Replaces old value", "Inserts in left subtree", "Is ignored", "Inserts in right subtree"],
    answer: 2
  },
  {
    question: "For `n` nodes, number of unique BSTs that can be formed is:",
    options: ["n!", "2^n", "Catalan number C(n)", "n²"],
    answer: 2
  },
  {
    question: "To implement a BST iteratively, you replace recursion with:",
    options: ["Queue", "Stack", "Deque", "Set"],
    answer: 1
  },
  {
    question: "What is the worst-case height of a BST with `n` nodes?",
    options: ["log n", "n", "n/2", "√n"],
    answer: 1
  },
  {
    question: "Which traversal is best for deleting all nodes from a BST?",
    options: ["In-order", "Post-order", "Pre-order", "Level-order"],
    answer: 1
  },
  {
    question: "How many comparisons are needed to find an element in an optimal BST?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Which of the following is true about BST vs Heap?",
    options: ["Heap is faster for search", "BST is faster for insert", "BST gives sorted output", "Heap is balanced BST"],
    answer: 2
  },
  {
    question: "Which of these is used in balancing BSTs?",
    options: ["Stack", "Rotation", "Swapping", "Sorting"],
    answer: 1
  },
  {
    question: "Finding floor of a number in BST means:",
    options: ["Smallest number ≥ key", "Smallest number ≤ key", "Largest number ≤ key", "Largest number ≥ key"],
    answer: 2
  },
  {
    question: "Can a BST ever become a complete binary tree?",
    options: ["No", "Yes, if elements inserted in perfect order", "Only for even n", "Only for sorted arrays"],
    answer: 1
  },
  {
    question: "If preorder and inorder traversals of BST are known, the tree can be:",
    options: ["Partially built", "Fully built", "Not constructed", "Constructed only if postorder is given"],
    answer: 1
  },
  {
    question: "Which of the following traversals is not sufficient to construct a BST uniquely?",
    options: ["Inorder alone", "Preorder and inorder", "Postorder and inorder", "All of the above"],
    answer: 0
  }
];

let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
