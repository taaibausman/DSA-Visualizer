const easyQuestions = [
  {
    question: "In a circular linked list, the last node points to:",
    options: ["NULL", "Head node", "Next node", "Itself"],
    answer: 1
  },
  {
    question: "A circular linked list can be:",
    options: ["Singly", "Doubly", "Both", "None"],
    answer: 2
  },
  {
    question: "What is the time complexity to traverse a circular linked list of size `n`?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Circular linked lists are often used in:",
    options: ["Stacks", "Binary Trees", "CPU Scheduling", "Hashing"],
    answer: 2
  },
  {
    question: "In a circular linked list, the head can be accessed from:",
    options: ["The last node", "The middle node", "NULL", "Only the first node"],
    answer: 0
  },
  {
    question: "A circular singly linked list has how many NULL pointers?",
    options: ["0", "1", "2", "n"],
    answer: 0
  },
  {
    question: "Which traversal is not straightforward in a circular singly linked list?",
    options: ["Forward", "Backward", "Both", "None"],
    answer: 1
  },
  {
    question: "To check if a circular list is empty, we check if:",
    options: ["head == tail", "head == NULL", "tail->next == head", "None of these"],
    answer: 1
  },
  {
    question: "Which of the following is false about circular linked list?",
    options: ["The end node links to head", "It has no beginning or end", "It cannot be singly linked", "It can be used in buffer management"],
    answer: 2
  },
  {
    question: "In a circular singly linked list with only one node, `head->next` is:",
    options: ["NULL", "Itself", "Tail", "Garbage"],
    answer: 1
  },
  {
    question: "Circular linked list removes the need for:",
    options: ["Memory allocation", "Loop counters", "NULL checks in end traversal", "Initialization"],
    answer: 2
  },
  {
    question: "Which operation is efficient in circular linked list compared to array?",
    options: ["Random Access", "Insertion at start", "Binary Search", "Sorting"],
    answer: 1
  },
  {
    question: "Which pointer is needed for insertion at end in circular singly linked list?",
    options: ["NULL", "Head", "Tail", "Middle"],
    answer: 2
  },
  {
    question: "A circular list is preferred over singly linked list when:",
    options: ["We want bidirectional traversal", "Memory is limited", "We need continuous looping", "We need sorted data"],
    answer: 2
  },
  {
    question: "What is printed if a circular list with 3 elements is traversed 5 times?",
    options: ["First 3 elements", "Infinite loop", "First 2 elements again", "First 3 elements repeated 2 times"],
    answer: 3
  },
  {
    question: "How many times does the loop run to visit all nodes of a circular list with `n` nodes?",
    options: ["n-1", "n", "n+1", "Infinite"],
    answer: 1
  },
  {
    question: "Which data structure is ideal for multiplayer games using turns?",
    options: ["Stack", "Queue", "Circular Linked List", "Array"],
    answer: 2
  },
  {
    question: "Which traversal is not possible in circular singly linked list?",
    options: ["Start to end", "End to start", "Looping infinitely", "Traversing with counter"],
    answer: 1
  },
  {
    question: "What is the key property of circular linked list?",
    options: ["First points to NULL", "Last points to NULL", "Last points to first", "Last is always NULL"],
    answer: 2
  },
  {
    question: "Which linked list has nodes connected in a loop?",
    options: ["Doubly", "Circular", "Singly", "Binary Tree"],
    answer: 1
  },
  {
    question: "Which application is best suited for circular linked list?",
    options: ["Sorting", "Quick Access", "Round Robin Scheduling", "Searching"],
    answer: 2
  },
  {
    question: "In a circular singly linked list, the insertion at front needs:",
    options: ["Only tail pointer", "Only head pointer", "Both head and tail pointer", "Only NULL pointer"],
    answer: 2
  },
  {
    question: "What happens if you forget to update tail’s next in a circular list?",
    options: ["Program crashes", "Infinite loop", "Tail becomes NULL", "First node is lost"],
    answer: 3
  },
  {
    question: "A circular linked list with two nodes has:",
    options: ["Two NULL links", "Each pointing to each other", "One NULL link", "Infinite loop"],
    answer: 1
  },
  {
    question: "In circular linked list, what is used to stop traversal?",
    options: ["NULL check", "Head pointer comparison", "Length counter", "Sentinel node"],
    answer: 1
  },
  {
    question: "What is the best way to avoid infinite loop in circular list traversal?",
    options: ["Count node visits", "Use flags", "Stop when node equals head again", "None"],
    answer: 2
  },
  {
    question: "Which traversal logic is correct for circular list?",
    options: ["While (ptr != NULL)", "While (true)", "Do { ... } while(ptr != head)", "Until EOF"],
    answer: 2
  },
  {
    question: "Circular linked lists can be used in:",
    options: ["Undo functionality", "Hash tables", "Round-robin CPU algorithms", "Priority queue"],
    answer: 2
  },
  {
    question: "Which pointer must always be updated after insertion at rear?",
    options: ["Head", "Tail", "Middle", "NULL"],
    answer: 1
  },
  {
    question: "In circular singly linked list, is it possible to have tail only and still traverse the list?",
    options: ["Yes", "No"],
    answer: 0
  }
];
const mediumQuestions = [
  {
    question: "Which of the following is true about the last node in a circular singly linked list?",
    options: ["It always points to NULL", "It points to the second node", "It points back to the first node", "It stores the count of nodes"],
    answer: 2
  },
  {
    question: "What is the time complexity to insert a node at the end of a circular linked list (without a tail pointer)?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "In a circular doubly linked list, each node has pointers to:",
    options: ["Only next node", "Next and previous node", "Only previous node", "None of the above"],
    answer: 1
  },
  {
    question: "Which of the following traversal is not possible in a circular singly linked list?",
    options: ["Forward traversal", "Backward traversal", "Repeated traversal", "Circular traversal"],
    answer: 1
  },
  {
    question: "To delete the head node in a circular linked list, you must:",
    options: ["Change the next of head to NULL", "Traverse the whole list to the last node", "Set head to NULL", "Use a stack"],
    answer: 1
  },
  {
    question: "Which pointer(s) is/are required for a circular doubly linked list?",
    options: ["One pointer", "Two pointers (prev and next)", "Only prev pointer", "None"],
    answer: 1
  },
  {
    question: "In a circular linked list with tail pointer, which node does `tail->next` refer to?",
    options: ["NULL", "Head", "Previous node", "Middle node"],
    answer: 1
  },
  {
    question: "Which condition signifies an empty circular linked list?",
    options: ["head == NULL", "head->next == NULL", "head->next == head", "All nodes point to NULL"],
    answer: 0
  },
  {
    question: "How many NULL pointers are there in a circular singly linked list with one node?",
    options: ["0", "1", "2", "Infinite"],
    answer: 0
  },
  {
    question: "What is the worst-case time complexity for deleting the last node in a circular singly linked list without tail?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "A circular linked list is best suited for:",
    options: ["LIFO operations", "Stack implementations", "Scheduling processes in OS", "Polynomial multiplication"],
    answer: 2
  },
  {
    question: "To insert at the beginning of a circular singly linked list, we must:",
    options: ["Change all node links", "Update last node’s next pointer", "Free memory", "None of these"],
    answer: 1
  },
  {
    question: "What will happen if you don’t update the last node while inserting at head in circular list?",
    options: ["Program crashes", "Infinite loop", "List is not circular anymore", "Memory leak"],
    answer: 2
  },
  {
    question: "Which data structure is more efficient for traversing circular list multiple times?",
    options: ["Stack", "Queue", "Circular queue", "Circular linked list"],
    answer: 3
  },
  {
    question: "Which of these is true for traversing a circular singly linked list of n nodes from any node?",
    options: ["Stops at NULL", "After n-1 steps, returns to start", "After n steps, returns to start", "Infinite loop"],
    answer: 2
  },
  {
    question: "Which is a valid advantage of circular linked list over array?",
    options: ["Fixed memory", "Constant-time access", "No shifting needed for deletion", "Random access"],
    answer: 2
  },
  {
    question: "Circular linked list can be used to implement:",
    options: ["LRU cache", "Stack", "Binary tree", "Heap"],
    answer: 0
  },
  {
    question: "To reverse a circular singly linked list, we need to:",
    options: ["Use recursion", "Modify every node’s next pointer", "Delete and re-insert", "Use stack"],
    answer: 1
  },
  {
    question: "How can we detect the end of a circular list during traversal?",
    options: ["When node == NULL", "When node->next == NULL", "When current == head", "When current == tail"],
    answer: 2
  },
  {
    question: "In circular doubly linked list, what’s the condition for a single-node list?",
    options: ["node->next == node", "node->prev == node", "Both A and B", "node->next == NULL"],
    answer: 2
  },
  {
    question: "How many pointers are updated while inserting a node between two nodes in circular doubly linked list?",
    options: ["2", "3", "4", "5"],
    answer: 2
  },
  {
    question: "To count nodes in circular singly linked list:",
    options: ["Use recursion", "Traverse until pointer == NULL", "Traverse until we revisit the head", "Use stack"],
    answer: 2
  },
  {
    question: "In circular linked list, which case requires extra care during deletion?",
    options: ["Deleting middle node", "Deleting tail node", "Deleting head node", "Both B and C"],
    answer: 3
  },
  {
    question: "If you traverse circular singly linked list using `while(curr!=head)`, what must you ensure before loop?",
    options: ["curr = NULL", "curr = head->next", "curr = head", "curr = head->next->next"],
    answer: 1
  },
  {
    question: "Why does circular linked list not suffer from dangling pointer issue in tail?",
    options: ["Because it has garbage collection", "Because all nodes are static", "Because last node always points to head", "Because tail is never NULL"],
    answer: 2
  },
  {
    question: "Which of these operations is more efficient in circular singly linked list with tail pointer?",
    options: ["Insertion at end", "Deletion at end", "Insertion at beginning", "Both A and C"],
    answer: 3
  },
  {
    question: "Circular list helps in solving problems involving:",
    options: ["Stacks", "Queues", "Round-robin scheduling", "Binary trees"],
    answer: 2
  },
  {
    question: "Which of the following is true about circular linked list size calculation?",
    options: ["O(1)", "O(n)", "O(log n)", "Not possible"],
    answer: 1
  },
  {
    question: "How can circular linked list be used in audio players?",
    options: ["To store metadata", "To maintain history", "To loop playlist continuously", "For UI rendering"],
    answer: 2
  },
  {
    question: "Why do we prefer circular linked list for buffer implementations?",
    options: ["Easy for fixed memory allocation", "Random access possible", "No fragmentation", "Allows continuous traversal"],
    answer: 3
  }
];

const hardQuestions = [
  {
    question: "In a circular linked list with a single node, what condition is true?",
    options: ["node->next == NULL", "node->next == node", "node->next == head", "node->prev == node"],
    answer: 1
  },
  {
    question: "What is the time complexity of deleting a node with a known pointer in a circular singly linked list with a tail pointer?",
    options: ["O(1)", "O(n)", "O(1) if tail is not involved", "O(1) always"],
    answer: 3
  },
  {
    question: "Which operation is most efficient in a circular linked list compared to a singly linked list?",
    options: ["Insertion at front", "Insertion at rear", "Deletion from front", "Deletion from rear"],
    answer: 1
  },
  {
    question: "How many NULL links are present in a properly implemented circular doubly linked list?",
    options: ["0", "1", "2", "Depends on the implementation"],
    answer: 0
  },
  {
    question: "What is the result of traversing a circular list infinitely without a break condition?",
    options: ["Segmentation fault", "Compilation error", "Infinite loop", "None of the above"],
    answer: 2
  },
  {
    question: "In a circular singly linked list with n nodes, how many comparisons are needed in the worst case to find a node?",
    options: ["n", "n - 1", "n + 1", "n"],
    answer: 3
  },
  {
    question: "Which of these is not a valid use case of a circular linked list?",
    options: ["Memory-efficient FIFO buffer", "Circular scheduling", "Dynamic array simulation", "Multiplayer game turn manager"],
    answer: 2
  },
  {
    question: "In a circular doubly linked list, the previous pointer of the head points to:",
    options: ["NULL", "Tail", "Self", "Next node"],
    answer: 1
  },
  {
    question: "If tail is the pointer in a circular singly linked list, inserting after tail is equivalent to:",
    options: ["Inserting at head", "Inserting at rear", "Inserting at middle", "Deleting rear"],
    answer: 1
  },
  {
    question: "Which of the following statements about circular linked lists is false?",
    options: ["They can be singly or doubly linked", "They can be used to simulate a queue", "They cannot contain NULL pointers", "Traversal must be terminated by a condition"],
    answer: 2
  },
  {
    question: "To break a circular singly linked list into a linear list, you need to:",
    options: ["Change the head", "Set last node's next to NULL", "Delete tail", "Insert NULL node"],
    answer: 1
  },
  {
    question: "In a circular linked list with head pointer only, which operation is least efficient?",
    options: ["Insertion at beginning", "Insertion at end", "Deletion at beginning", "Search operation"],
    answer: 1
  },
  {
    question: "A circular singly linked list allows easier implementation of which data structure?",
    options: ["Binary Heap", "Hash Table", "Queue", "Stack"],
    answer: 2
  },
  {
    question: "What condition helps detect completion of traversal in a circular singly linked list?",
    options: ["ptr == NULL", "ptr->next == NULL", "ptr == head", "ptr->data == head->data"],
    answer: 2
  },
  {
    question: "What is the minimum number of pointers needed to reverse a circular singly linked list in-place?",
    options: ["2", "3", "4", "1"],
    answer: 1
  },
  {
    question: "If you have only the tail pointer in a circular linked list, how can you access the head?",
    options: ["tail->prev", "tail->next", "tail", "tail->next->next"],
    answer: 1
  },
  {
    question: "Which is a major drawback of circular linked list?",
    options: ["Extra memory usage", "Traversal requires special termination logic", "Can’t insert at end", "Inflexible data type"],
    answer: 1
  },
  {
    question: "What is the best method to detect a loop in a circular linked list?",
    options: ["Hashing", "Count nodes", "Fast and slow pointers", "Stack"],
    answer: 2
  },
  {
    question: "Deleting a node after the current node in a circular singly linked list involves:",
    options: ["Modifying current->next only", "Modifying current only", "Searching from head", "Reversing list"],
    answer: 0
  },
  {
    question: "How does a circular list handle the end condition of insertion operations?",
    options: ["By reassigning NULL", "By updating tail pointer", "By checking next to be NULL", "No specific handling needed"],
    answer: 1
  },
  {
    question: "In circular doubly linked list, deleting the tail requires updating:",
    options: ["Only tail", "Tail and its previous", "Only head", "Next of head"],
    answer: 1
  },
  {
    question: "If the circular linked list has only one node and that node is deleted, what should be done?",
    options: ["head = NULL", "head->next = NULL", "head->next = head", "return"],
    answer: 0
  },
  {
    question: "In a circular linked list, how do you check if the list is empty?",
    options: ["head == NULL", "head->next == NULL", "tail == NULL", "tail->next == NULL"],
    answer: 0
  },
  {
    question: "What happens if the traversal logic in circular list forgets to include loop-termination check?",
    options: ["Stops early", "Access violation", "Infinite loop", "Segmentation fault"],
    answer: 2
  },
  {
    question: "In circular doubly linked list, if a new node is inserted before head, what must be updated?",
    options: ["Only head", "Previous of head and next of tail", "Next of tail only", "None of the above"],
    answer: 1
  },
  {
    question: "Which of the following is not required to insert a node at beginning in circular doubly linked list?",
    options: ["Update head", "Update previous of head", "Update next of tail", "Update tail pointer"],
    answer: 3
  },
  {
    question: "Which traversal method is preferred in circular linked list to avoid infinite loops?",
    options: ["Until NULL", "Until tail", "Until current == head", "No need"],
    answer: 2
  },
  {
    question: "What’s the space complexity of a circular linked list with n nodes?",
    options: ["O(n)", "O(1)", "O(n²)", "O(log n)"],
    answer: 0
  },
  {
    question: "What will be the effect of a missing base case in recursive traversal of circular linked list?",
    options: ["Stack underflow", "Stack overflow", "Nothing", "Segmentation fault"],
    answer: 1
  },
  {
    question: "If the circular linked list is implemented with only a tail pointer, which operation is easiest?",
    options: ["Insertion at front", "Insertion at end", "Deletion at front", "Search"],
    answer: 1
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
