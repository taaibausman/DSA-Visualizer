const easyQuestions = [
  {
    question: "What is a Min Heap?",
    options: [
      "A tree where the right child is always smaller",
      "A tree where parent is smaller than both children",
      "A binary tree where each parent node is less than or equal to its children",
      "A heap with maximum elements"
    ],
    answer: 2
  },
  {
    question: "The root node in a Min Heap contains:",
    options: ["Middle value", "Minimum value", "Maximum value", "Random value"],
    answer: 1
  },
  {
    question: "In Min Heap, the smallest element is found:",
    options: ["At the bottom", "At the last index", "At the root", "In the leftmost leaf"],
    answer: 2
  },
  {
    question: "A complete binary tree means:",
    options: [
      "All nodes are filled",
      "All leaf nodes are at same level",
      "All levels are completely filled except possibly the last",
      "Tree has only one child"
    ],
    answer: 2
  },
  {
    question: "Which operation is used to remove the smallest element in Min Heap?",
    options: ["Insert", "Update", "Search", "Extract Min"],
    answer: 3
  },
  {
    question: "Time complexity of inserting an element in a Min Heap:",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 1
  },
  {
    question: "Which data structure is commonly used to implement a Min Heap?",
    options: ["Linked List", "Hash Table", "Array", "Stack"],
    answer: 2
  },
  {
    question: "What is the parent of node at index `i` in an array-based Min Heap?",
    options: ["i + 1", "i - 1", "(i - 1) / 2", "2i + 1"],
    answer: 2
  },
  {
    question: "Which of the following maintains Min Heap property after insertion?",
    options: ["Merge", "Build Max Heap", "Heapify Up (or Bubble Up)", "Reverse"],
    answer: 2
  },
  {
    question: "In a Min Heap, what is the left child index of node `i`?",
    options: ["2i + 2", "i - 1", "2i + 1", "2i - 1"],
    answer: 2
  },
  {
    question: "Heap is a type of:",
    options: ["Linked list", "Complete Binary Tree", "AVL Tree", "B-Tree"],
    answer: 1
  },
  {
    question: "The Heap property for Min Heap is:",
    options: [
      "Parent is greater than children",
      "Parent is smaller than or equal to children",
      "Children are equal",
      "Only leaf nodes are sorted"
    ],
    answer: 1
  },
  {
    question: "Which of the following operations does NOT modify the structure of a Min Heap?",
    options: ["Insert", "Delete", "Peek", "Extract Min"],
    answer: 2
  },
  {
    question: "How many children can a node have in a binary Min Heap?",
    options: ["At most 1", "At most 2", "Exactly 2", "Unlimited"],
    answer: 1
  },
  {
    question: "What is the last step after deleting the root from Min Heap?",
    options: ["Append 0", "Insert new root", "Heapify Down", "Heapify Up"],
    answer: 2
  },
  {
    question: "Can a Min Heap have duplicate values?",
    options: ["No", "Yes", "Only in leaf", "Only at root"],
    answer: 1
  },
  {
    question: "In array representation of Min Heap, what is the right child of node at index `i`?",
    options: ["2i + 3", "2i + 2", "2i", "i - 1"],
    answer: 1
  },
  {
    question: "Which of the following applications use Min Heap?",
    options: ["DFS", "BFS", "Infix to Postfix", "Dijkstra's Algorithm"],
    answer: 3
  },
  {
    question: "What happens when you insert into a Min Heap?",
    options: [
      "Root is removed",
      "New node is added and bubbled up",
      "Tree becomes unbalanced",
      "Middle node is deleted"
    ],
    answer: 1
  },
  {
    question: "What is the maximum number of nodes at height `h` in a binary Min Heap?",
    options: ["h", "2^h", "h^2", "log(h)"],
    answer: 1
  },
  {
    question: "What is the result of applying \"Heapify\" on a subtree?",
    options: ["Inserts a node", "Restores heap property", "Deletes leaf", "Builds tree"],
    answer: 1
  },
  {
    question: "What is the best case time complexity of Extract-Min?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "If Min Heap has `n` elements, what is the height?",
    options: ["n", "n/2", "log₂n", "√n"],
    answer: 2
  },
  {
    question: "Which of the following is true for the build heap operation?",
    options: ["O(n log n)", "O(n)", "O(log n)", "O(1)"],
    answer: 1
  },
  {
    question: "Which property is true for every leaf node in Min Heap?",
    options: ["No child", "Maximum element", "Heap property is maintained", "Duplicate only"],
    answer: 2
  },
  {
    question: "What is the first step in Extract-Min operation?",
    options: [
      "Replace root with last element",
      "Remove leftmost leaf",
      "Swap all elements",
      "Reverse array"
    ],
    answer: 0
  },
  {
    question: "Can a binary Min Heap be implemented using trees?",
    options: ["No", "Yes", "Only for small heaps", "Only for sorted input"],
    answer: 1
  },
  {
    question: "The array [1, 5, 3, 10, 6] represents a:",
    options: ["Max Heap", "Min Heap", "AVL Tree", "Stack"],
    answer: 1
  },
  {
    question: "After inserting a smaller element than the root in Min Heap:",
    options: [
      "Root is unchanged",
      "Tree is rebalanced",
      "Heapify Up is performed",
      "Nothing happens"
    ],
    answer: 2
  },
  {
    question: "What is the condition to stop bubbling up during insertion?",
    options: [
      "When current is even",
      "When parent is smaller than child",
      "When heap property is restored",
      "After reaching left child"
    ],
    answer: 2
  }
];
const mediumQuestions = [
  {
    question: "Which operation requires the most time in a Min Heap?",
    options: ["Insertion", "Finding the minimum", "Deletion of root", "Swapping two elements"],
    answer: 2
  },
  {
    question: "What is the time complexity of building a Min Heap using the `heapify()` method?",
    options: ["O(n log n)", "O(log n)", "O(n)", "O(1)"],
    answer: 2
  },
  {
    question: "Which array index contains the minimum element in a Min Heap?",
    options: ["0", "n-1", "n/2", "Any leaf node"],
    answer: 0
  },
  {
    question: "After inserting an element into a Min Heap, which method is used to restore heap order?",
    options: ["Sift-down", "Sift-left", "Sift-right", "Sift-up"],
    answer: 3
  },
  {
    question: "The children of the node at index `i` in a Min Heap are located at:",
    options: ["2*i and 2*i+1", "i/2 and i/2+1", "2*i+1 and 2*i+2", "i-1 and i+1"],
    answer: 2
  },
  {
    question: "Which of the following trees can be a Min Heap?",
    options: ["Complete Binary Tree", "Binary Search Tree", "AVL Tree", "Red-Black Tree"],
    answer: 0
  },
  {
    question: "What is the height of a Min Heap with `n` nodes?",
    options: ["log n", "n", "√n", "n log n"],
    answer: 0
  },
  {
    question: "Which node will be deleted first in successive `deleteMin()` calls?",
    options: ["Leftmost leaf", "Rightmost node", "Root", "Last inserted node"],
    answer: 2
  },
  {
    question: "How many comparisons are needed to insert into a Min Heap of height `h`?",
    options: ["h", "h/2", "log h", "O(1)"],
    answer: 0
  },
  {
    question: "Which of the following applications commonly uses Min Heaps?",
    options: ["BFS", "DFS", "Huffman Encoding", "Binary Search"],
    answer: 2
  },
  {
    question: "Which of the following is a valid property of a Min Heap?",
    options: [
      "A node is smaller than its descendants",
      "It is a balanced binary tree",
      "It allows O(1) insertion",
      "All nodes are sorted"
    ],
    answer: 0
  },
  {
    question: "If the root of a Min Heap is replaced with a larger value, what should be done?",
    options: ["Do nothing", "Heapify up", "Heapify down", "Rebuild the heap"],
    answer: 2
  },
  {
    question: "In a Min Heap, what can be said about the children of the minimum node?",
    options: ["They are greater or equal", "They are always smaller", "They can be any value", "They are sorted"],
    answer: 0
  },
  {
    question: "What is the worst-case time complexity of deleting an element from a Min Heap?",
    options: ["O(log n)", "O(1)", "O(n)", "O(n log n)"],
    answer: 0
  },
  {
    question: "To implement a priority queue using a Min Heap, the highest priority is given to:",
    options: ["Largest number", "Median value", "Smallest number", "Random value"],
    answer: 2
  },
  {
    question: "What happens when you insert elements in decreasing order into a Min Heap?",
    options: [
      "Heap remains sorted",
      "Each insertion takes O(1)",
      "Each insertion causes maximum swaps",
      "The heap becomes a BST"
    ],
    answer: 2
  },
  {
    question: "Can a Min Heap have duplicate values?",
    options: ["No", "Yes", "Only if complete", "Only at leaves"],
    answer: 1
  },
  {
    question: "Which is true about leaf nodes in a Min Heap?",
    options: ["They are always the largest", "They have children", "They are at the top", "They satisfy heap property"],
    answer: 3
  },
  {
    question: "Which is the correct order of operations for `deleteMin()` in a Min Heap?",
    options: [
      "Remove root → replace with right child",
      "Remove leaf → do nothing",
      "Remove root → replace with last element → heapify",
      "Replace root → add leaf"
    ],
    answer: 2
  },
  {
    question: "In a Min Heap, if node at index `i` has value less than both children, it is:",
    options: ["Not a heap", "A leaf", "A valid heap node", "The largest element"],
    answer: 2
  },
  {
    question: "What structure does Python's `heapq` module use for its heap?",
    options: ["Max Heap", "Binary Search Tree", "AVL Tree", "Min Heap"],
    answer: 3
  },
  {
    question: "In a Min Heap, which of these is always false?",
    options: ["Root is smallest", "Leaves are smallest", "It is complete binary tree", "Insertion takes O(log n)"],
    answer: 1
  },
  {
    question: "How many leaf nodes can a Min Heap of height `h` have at most?",
    options: ["2^h", "h", "log h", "2h"],
    answer: 0
  },
  {
    question: "Which data structure is commonly used to implement Dijkstra’s Algorithm?",
    options: ["Queue", "Stack", "Min Heap", "Graph"],
    answer: 2
  },
  {
    question: "After removing the root from Min Heap, what element replaces it?",
    options: ["Left child", "Right child", "Last inserted node", "Median"],
    answer: 2
  },
  {
    question: "If a Min Heap is stored in an array and has `n` nodes, which range contains leaf nodes?",
    options: ["0 to n/2", "n/2 to n-1", "1 to n", "n/2+1 to n"],
    answer: 1
  },
  {
    question: "A Min Heap with 7 elements has how many internal nodes?",
    options: ["3", "4", "2", "6"],
    answer: 0
  },
  {
    question: "How do you ensure the heap property when decreasing a key in Min Heap?",
    options: ["Heapify up", "Heapify down", "Swap with root", "Delete and reinsert"],
    answer: 0
  },
  {
    question: "What is the parent of the node at index `i` in an array-based Min Heap?",
    options: ["i - 1", "floor((i-1)/2)", "2*i", "ceil(i/2)"],
    answer: 1
  },
  {
    question: "Which traversal method can be used to print all elements of a Min Heap in sorted order?",
    options: ["In-order", "Level-order", "Heap sort", "Post-order"],
    answer: 2
  }
];
const hardQuestions = [
  {
    question: "In a Min Heap with `n` elements, the maximum number of nodes that can be at height `h` is:",
    options: ["⌊n / 2^h⌋", "2^h", "n - h", "⌈n / h⌉"],
    answer: 0
  },
  {
    question: "The time complexity of finding the *k-th* smallest element in a Min Heap using a min-heap-based auxiliary data structure is:",
    options: ["O(k log k)", "O(k)", "O(k log n)", "O(n log k)"],
    answer: 0
  },
  {
    question: "Given a complete binary tree of `n` nodes, how many distinct Min Heaps can be formed?",
    options: ["Catalan(n)", "n!", "n^n", "Depends on structure and recursive combinations"],
    answer: 3
  },
  {
    question: "Which of the following scenarios leads to a worst-case time complexity of O(log n) in a Min Heap?",
    options: ["Deleting the minimum element", "Searching for a specific key", "Inserting a new element", "Both A and C"],
    answer: 3
  },
  {
    question: "In a Min Heap represented by array `A`, which of the following must always hold true?",
    options: [
      "A[i] ≥ A[2*i]",
      "A[i] ≤ A[2*i+1]",
      "A[i] ≥ A[(i-1)/2]",
      "A[i] ≤ A[2*i] and A[i] ≤ A[2*i+1]"
    ],
    answer: 3
  },
  {
    question: "If you need to merge two Min Heaps of size `n` and `m`, what is the optimal time complexity?",
    options: ["O(n + m)", "O(log n + log m)", "O(n log m)", "O((n + m) log(n + m))"],
    answer: 3
  },
  {
    question: "Which traversal cannot be used to validate the heap property in Min Heap?",
    options: ["Level order", "Inorder", "Preorder", "Postorder"],
    answer: 1
  },
  {
    question: "Which of the following operations will violate the structure of Min Heap?",
    options: [
      "Swap root with a leaf",
      "Remove the root and replace with last leaf",
      "Insert a node at the root directly",
      "Swap two leaf nodes"
    ],
    answer: 2
  },
  {
    question: "What is the number of comparisons required to build a Min Heap from an unsorted array of size `n` using Floyd’s method?",
    options: ["O(n log n)", "O(n)", "O(n^2)", "O(log n)"],
    answer: 1
  },
  {
    question: "How many children can a node in a d-ary Min Heap have?",
    options: ["2", "3", "d", "Depends on height"],
    answer: 2
  },
  {
    question: "Which of the following best describes a ternary Min Heap?",
    options: [
      "Heap with 2 children per node",
      "Heap with 3 children per node",
      "Heap with minimum depth 3",
      "Heap with maximum 3 levels"
    ],
    answer: 1
  },
  {
    question: "Which of the following best represents the root node in a Min Heap when implemented using array?",
    options: ["A[n]", "A[1]", "A[0]", "A[n/2]"],
    answer: 2
  },
  {
    question: "What is the amortized complexity of inserting `n` elements into an initially empty Min Heap?",
    options: ["O(log n)", "O(n log n)", "O(n)", "O(n^2)"],
    answer: 2
  },
  {
    question: "The number of nodes in a Min Heap that are not leaves is:",
    options: ["⌊n / 2⌋", "n - 1", "⌈n / 2⌉", "log₂n"],
    answer: 0
  },
  {
    question: "Which of the following statements is TRUE for a Min Heap of height h?",
    options: [
      "It has exactly 2^h leaf nodes",
      "All leaves are at the same level",
      "It is not necessarily balanced",
      "It is always a full binary tree"
    ],
    answer: 2
  },
  {
    question: "Which data structure is best for implementing Dijkstra's algorithm with minimum time complexity?",
    options: ["Binary Search Tree", "Min Heap", "Stack", "Queue"],
    answer: 1
  },
  {
    question: "Which method is not valid for creating a Min Heap from an unsorted array?",
    options: [
      "Heapify from bottom-up",
      "Insert one by one",
      "Sort the array in ascending order",
      "Use Floyd’s algorithm"
    ],
    answer: 2
  },
  {
    question: "The time complexity to delete an arbitrary node (not the root) in a Min Heap is:",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Which of the following algorithms uses Min Heap for optimization?",
    options: ["Kruskal’s", "Prim’s (with heap)", "Bellman-Ford", "Floyd-Warshall"],
    answer: 1
  },
  {
    question: "What is the height of a complete Min Heap with `n` elements?",
    options: ["log₂n", "n", "√n", "⌈log₂(n+1)⌉ - 1"],
    answer: 3
  },
  {
    question: "Which operation is used repeatedly in `heapify`?",
    options: ["BFS", "DFS", "Bubble-down", "Backtracking"],
    answer: 2
  },
  {
    question: "If you repeatedly insert the same element in a Min Heap, what is the final structure?",
    options: ["Invalid", "Skewed", "Balanced", "Depends on implementation"],
    answer: 2
  },
  {
    question: "Which data structure does NOT preserve the heap property?",
    options: ["Max Heap", "Min Heap", "BST", "Binomial Heap"],
    answer: 2
  },
  {
    question: "What is the worst-case time complexity to search a value in a Min Heap?",
    options: ["O(log n)", "O(n)", "O(n log n)", "O(1)"],
    answer: 1
  },
  {
    question: "If you perform an inorder traversal on a Min Heap, what result do you get?",
    options: ["Sorted array", "Descending order", "Heap order", "No guaranteed order"],
    answer: 3
  },
  {
    question: "What is the best-case time complexity for inserting into a Min Heap?",
    options: ["O(log n)", "O(1)", "O(n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "What happens when you swap the root and a leaf in a Min Heap without reheapifying?",
    options: ["Heap becomes Max Heap", "Heap remains valid", "Heap becomes invalid", "Heap gets sorted"],
    answer: 2
  },
  {
    question: "Which of these is FALSE about Min Heap?",
    options: [
      "Every subtree is also a Min Heap",
      "It supports O(log n) insertion",
      "It is always a balanced binary tree",
      "The root contains the maximum value"
    ],
    answer: 3
  },
  {
    question: "To build a Min Heap from a large dataset for streaming, the preferred approach is:",
    options: ["Recursive insertion", "Floyd’s algorithm", "Merge Sort", "Radix Sort"],
    answer: 1
  },
  {
    question: "Which scenario is ideal for using a Min Heap over a BST?",
    options: [
      "When fast insert and delete are required",
      "When sorted traversal is required",
      "When duplicate elements must be avoided",
      "When O(1) search is required"
    ],
    answer: 0
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
