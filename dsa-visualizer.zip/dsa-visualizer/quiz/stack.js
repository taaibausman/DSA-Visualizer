// Questions for Stack
const easyQuestions = [
  {
    question: "A stack follows which access policy?",
    options: ["FIFO", "LIFO", "Random", "Priority"],
    answer: 1
  },
  {
    question: "What operation removes the top element from a stack?",
    options: ["push", "pop", "peek", "insert"],
    answer: 1
  },
  {
    question: "What operation only views the top element?",
    options: ["peek", "pop", "push", "delete"],
    answer: 0
  },
  {
    question: "Which operation adds an element to the top?",
    options: ["pop", "push", "enqueue", "peek"],
    answer: 1
  },
  {
    question: "In an empty stack, calling pop causes:",
    options: ["success", "underflow", "overflow", "exception-free behavior"],
    answer: 1
  },
  {
    question: "Pushing on a full bounded stack results in:",
    options: ["overflow", "underflow", "success", "null"],
    answer: 0
  },
  {
    question: "A stack implemented via array needs tracking of:",
    options: ["head index", "tail index", "top index", "front index"],
    answer: 2
  },
  {
    question: "A singly linked list where insertion and deletion occur at head can serve as:",
    options: ["queue", "stack", "tree", "graph"],
    answer: 1
  },
  {
    question: "What is the time complexity for push in a stack?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n log n)"],
    answer: 0
  },
  {
    question: "pop() time complexity?",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "peek() time complexity?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n^2)"],
    answer: 1
  },
  {
    question: "Which is not a stack operation?",
    options: ["push", "peek", "enqueue", "pop"],
    answer: 2
  },
  {
    question: "Stack can check for balanced parentheses in an expression.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To reverse a string, a stack can be used.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Which data structure can implement recursion?",
    options: ["Queue", "Stack", "Graph", "Set"],
    answer: 1
  },
  {
    question: "Infix-to-postfix conversion uses a stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Matching HTML tags is done using:",
    options: ["Heap", "Queue", "Set", "Stack"],
    answer: 3
  },
  {
    question: "Stack overflow bug occurs when:",
    options: ["pop too much", "push on full memory", "peek empty", "using queue"],
    answer: 1
  },
  {
    question: "Calling peek on an empty stack often returns:",
    options: ["null", "exception", "garbage", "depends on implementation"],
    answer: 3
  },
  {
    question: "Which error can peek on empty cause?",
    options: ["overflow", "underflow", "segmentation fault", "queue-full"],
    answer: 2
  },
  {
    question: "Postfix evaluation uses a stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Preorder traversal of a tree can be implemented with a stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "During undo operations, software uses a stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Converting decimal to binary can use stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Iterative stack implementation requires:",
    options: ["recursion", "top pointer", "tail pointer", "random access"],
    answer: 1
  },
  {
    question: "In Java, `Stack` class extends:",
    options: ["Vector", "ArrayList", "LinkedList", "HashMap"],
    answer: 0
  },
  {
    question: "In C++, `std::stack` uses which container adaptor by default?",
    options: ["list", "deque", "vector", "queue"],
    answer: 1
  },
  {
    question: "Which language-level array supports stack operations fastest?",
    options: ["Python list", "Python set", "Python dict", "Python tuple"],
    answer: 0
  },
  {
    question: "Balanced bracket algorithm uses a stack of:",
    options: ["ints", "chars", "floats", "doubles"],
    answer: 1
  },
  {
    question: "The bottom of stack is:",
    options: ["where pop occurs", "where push occurs", "where no operations occur", "opposite end from top"],
    answer: 3
  }
];


const mediumQuestions = [
  {
    question: "After pushing 10, 20, 30, calling pop twice returns:",
    options: ["10", "20", "30 then 20", "20 then 10"],
    answer: 2
  },
  {
    question: "Sequence of ops: push 5, push 8, peek, pop, peek → returns:",
    options: ["8, 8", "8, 5", "5, 8", "5, 5"],
    answer: 1
  },
  {
    question: "Depth‑first search uses:",
    options: ["queue", "stack", "heap", "set"],
    answer: 1
  },
  {
    question: "Reverse a queue using a stack: you must:",
    options: ["push all queue items, then pop back", "use recursion only", "use heap", "not possible"],
    answer: 0
  },
  {
    question: "We can check palindrome using 1 stack in O(n) time.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To sort a stack using only another stack (no recursion), min operations:",
    options: ["O(n)", "O(n log n)", "O(n^2)", "O(1)"],
    answer: 2
  },
  {
    question: "Infix “a+b*c” → postfix:",
    options: ["a b + c *", "a b c * +", "a + b * c", "a b * c +"],
    answer: 1
  },
  {
    question: "Which stacks algorithm detects a cycle in graph?",
    options: ["Tarjan's SCC", "Topological sort", "DFS recursion stack", "Union-Find"],
    answer: 2
  },
  {
    question: "Convert “((()))” – depth max =?",
    options: ["1", "2", "3", "4"],
    answer: 2
  },
  {
    question: "Check if given sequence is stack-permutation: use additional stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Reverse first k elements of stack: only 2 auxiliary stacks?",
    options: ["True", "False"],
    answer: 1
  },
  {
    question: "Minimum stacks to sort 3 pancakes =?",
    options: ["1", "2", "3", "0"],
    answer: 0
  },
  {
    question: "Largest rectangle histogram uses stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "You can evaluate prefix expressions using stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "For every push there's a corresponding pop in balanced operations: stack is:",
    options: ["full", "balanced", "empty", "overflowed"],
    answer: 1
  },
  {
    question: "To implement call stack, OS/Runtime uses:",
    options: ["circular buffer", "stack segment", "queue", "heap segment"],
    answer: 1
  },
  {
    question: "Postfix “7 8 + 3 *” yields:",
    options: ["15 3 *", "7 8 3 * +", "(7+8)*3 = 45", "7 + (8*3) = 31"],
    answer: 2
  },
  {
    question: "Eliminate recursion by using explicit stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "A stack of size n requires how much space?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n log n)"],
    answer: 1
  },
  {
    question: "“Stack of plates” analogy describes:",
    options: ["stack", "queue", "heap", "tree"],
    answer: 3
  },
  {
    question: "Use two stacks to implement a queue.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "“rainwater trapping” problem uses stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Largest rectangle in matrix uses stacks per row.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Implementing undo/redo needs two stacks.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "What’s the auxiliary space to reverse a stack of size n (using recursion)?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 1
  },
  {
    question: "Middle element of a stack can be accessed in O(1) if using:",
    options: ["singly linked list", "doubly linked list", "array", "queue"],
    answer: 1
  },
  {
    question: "Balanced brackets with three bracket types use stack of:",
    options: ["parentheses only", "characters", "ints", "arrays"],
    answer: 1
  },
  {
    question: "Kth smallest in stack?",
    options: ["direct", "needs pop till k and re-push", "using peek", "not possible"],
    answer: 1
  },
  {
    question: "Expression evaluation converts to:",
    options: ["infix", "prefix", "postfix", "quantifier"],
    answer: 2
  },
  {
    question: "Use stack to evaluate “3 + 4 * 2 / (1 - 5)” by converting to postfix.",
    options: ["True", "False"],
    answer: 0
  }
];


const hardQuestions = [
  {
    question: "To design a min-stack supporting getMin() in O(1), what structure?",
    options: ["single stack", "stack + auxiliary min-stack", "queue", "heap"],
    answer: 1
  },
  {
    question: "For max-stack similarly.",
    options: ["heap", "stack + aux max-stack", "list", "set"],
    answer: 1
  },
  {
    question: "To get median in stack in O(log n), use:",
    options: ["two heaps + stack", "single stack", "BST", "queue"],
    answer: 0
  },
  {
    question: "Evaluate sliding-window maximum in O(n) using:",
    options: ["stack", "deque", "queue", "heap"],
    answer: 1
  },
  {
    question: "Next greater element to right uses stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Next smaller element to left uses stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Largest rectangle in histogram complexity:",
    options: ["O(n²)", "O(n)", "O(n log n)", "O(log n)"],
    answer: 1
  },
  {
    question: "Depth of recursion for balanced tree traversal:",
    options: ["O(n)", "O(log n)", "O(1)", "O(n²)"],
    answer: 1
  },
  {
    question: "Validate BST using iterative stack:",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Reverse Polish notation parsing uses:",
    options: ["stack", "queue", "heap", "list"],
    answer: 0
  },
  {
    question: "A stack automaton is more powerful than:",
    options: ["DFA", "Turing machine", "Unrestricted grammar", "Tree"],
    answer: 0
  },
  {
    question: "Recognizing palindromes with a stack belongs to:",
    options: ["regular languages", "context-free languages", "context-sensitive", "recursive"],
    answer: 1
  },
  {
    question: "How many stacks to simulate queue in amortized O(1)?",
    options: ["1", "2", "3", "n"],
    answer: 1
  },
  {
    question: "For n pushes & pops on two-stack queue, amortized cost per op is:",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "Use stack to detect cycle in directed graph via:",
    options: ["adjacency matrix", "recursion stack", "BFS", "union-find"],
    answer: 1
  },
  {
    question: "Combined push-pop operations count to sort stack:",
    options: ["𝑂(n)", "𝑂(n²)", "𝑂(n log n)", "𝑂(log n)"],
    answer: 1
  },
  {
    question: "A push-only stack is equivalent to:",
    options: ["write-only memory", "read-only", "Turing complete", "FSM"],
    answer: 0
  },
  {
    question: "Use two stacks to support getMin() in O(1).",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "To implement queue with three stacks faster than 2-stack method?",
    options: ["possible", "not beneficial"],
    answer: 1
  },
  {
    question: "Balanced parentheses is a context‑free decision problem.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Recognizing sequence 0ⁿ1ⁿ uses stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "One stack can simulate two stacks?",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "Simulating two stacks via one: need to store:",
    options: ["mid pointer", "current top flag", "queue", "priority queue"],
    answer: 1
  },
  {
    question: "A stack with resizing array amortizes push to:",
    options: ["O(n)", "O(1)", "O(log n)", "O(1 ? tricky)"],
    answer: 1
  },
  {
    question: "Evaluate postfix with variables and – operator: need to check:",
    options: ["operand ordering", "stack sorted", "array length", "recursion"],
    answer: 0
  },
  {
    question: "In arithmetic expression stack, operator precedence handled via:",
    options: ["recursion", "two stacks (operands + operators)", "hash-map", "tree"],
    answer: 1
  },
  {
    question: "Implementing `undo` that supports redo: requires:",
    options: ["one stack", "two stacks", "queue", "tree"],
    answer: 1
  },
  {
    question: "For iterative tree traversal post-order using stack, we need:",
    options: ["visited flag", "recursion", "two stacks", "parent pointers"],
    answer: 0
  },
  {
    question: "Largest area rectangle in matrix: reduce to histogram per row + stack.",
    options: ["True", "False"],
    answer: 0
  },
  {
    question: "For concurrent stack, to avoid race condition use:",
    options: ["locks or atomic operations", "queue", "no protection", "heap"],
    answer: 0
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
