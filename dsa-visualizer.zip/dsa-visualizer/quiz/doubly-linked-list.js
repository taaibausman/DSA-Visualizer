const easyQuestions = [
  {
    question: "Which of the following is true about a doubly linked list?",
    options: ["It uses arrays", "Each node has only one link", "Each node has links to both previous and next nodes", "It cannot be traversed in reverse"],
    answer: 2
  },
  {
    question: "In a doubly linked list, the pointer to the previous node of the head is:",
    options: ["NULL", "Points to the tail", "Points to itself", "Not defined"],
    answer: 0
  },
  {
    question: "The last node of a doubly linked list has its next pointer set to:",
    options: ["Address of head", "NULL", "Address of previous node", "Garbage value"],
    answer: 1
  },
  {
    question: "What is the time complexity of inserting a node at the beginning of a doubly linked list?",
    options: ["O(n)", "O(n log n)", "O(1)", "O(log n)"],
    answer: 2
  },
  {
    question: "What is the data structure used in browser history navigation (back and forward)?",
    options: ["Stack", "Queue", "Array", "Doubly linked list"],
    answer: 3
  },
  {
    question: "Which field is NOT found in a node of a doubly linked list?",
    options: ["Next pointer", "Data", "Previous pointer", "Random pointer"],
    answer: 3
  },
  {
    question: "A doubly linked list allows traversal in:",
    options: ["Only forward direction", "Only backward direction", "Both directions", "Circular direction only"],
    answer: 2
  },
  {
    question: "In a doubly linked list, what does the ‘prev’ pointer in a node point to?",
    options: ["Next node", "Previous node", "Head node", "NULL"],
    answer: 1
  },
  {
    question: "Which of the following is NOT an advantage of a doubly linked list over a singly linked list?",
    options: ["Easier reverse traversal", "Easier deletion of a node", "Extra memory for previous pointer", "Can go forward and backward"],
    answer: 2
  },
  {
    question: "Which is the correct way to delete a node from a doubly linked list?",
    options: ["Modify only next pointer", "Modify only prev pointer", "Modify both next and prev pointers", "None"],
    answer: 2
  },
  {
    question: "If a doubly linked list has only one node, both its next and prev pointers point to:",
    options: ["Head node", "NULL", "Tail node", "Random address"],
    answer: 1
  },
  {
    question: "In a doubly linked list, insertion at the end requires updating:",
    options: ["One pointer", "Two pointers", "Three pointers", "No pointers"],
    answer: 1
  },
  {
    question: "Which traversal is easier in a doubly linked list than singly?",
    options: ["Forward", "Reverse", "Both same", "Random"],
    answer: 1
  },
  {
    question: "To delete the last node in a DLL, we must:",
    options: ["Change head", "Set prev’s next to NULL", "Set next’s prev to NULL", "Nothing"],
    answer: 1
  },
  {
    question: "What is required in a doubly linked list node?",
    options: ["Data and one pointer", "Only data", "Data and two pointers", "Only pointers"],
    answer: 2
  },
  {
    question: "DLL uses more memory than SLL because:",
    options: ["It uses arrays", "It stores node index", "It has two pointers per node", "It is slow"],
    answer: 2
  },
  {
    question: "What will be the result if we forget to update the prev pointer while inserting a node?",
    options: ["Forward traversal breaks", "Backward traversal breaks", "Both traversals break", "No issue"],
    answer: 1
  },
  {
    question: "Which node type is required for a doubly linked list?",
    options: ["Node with only next pointer", "Node with only prev pointer", "Node with both prev and next pointers", "Array element"],
    answer: 2
  },
  {
    question: "When deleting the head node, what should the new head’s prev pointer be?",
    options: ["NULL", "Same as old head", "Tail", "Not changed"],
    answer: 0
  },
  {
    question: "The main difference between SLL and DLL is:",
    options: ["SLL uses less memory", "DLL cannot be reversed", "DLL uses arrays", "SLL is faster in reverse traversal"],
    answer: 0
  },
  {
    question: "If a DLL has N nodes, how many prev pointers exist?",
    options: ["N-1", "N", "N+1", "2N"],
    answer: 1
  },
  {
    question: "To traverse DLL backward from the tail, we use:",
    options: ["Next pointers", "Prev pointers", "Index", "NULL"],
    answer: 1
  },
  {
    question: "Which of these supports backward traversal efficiently?",
    options: ["Stack", "Queue", "Array", "Doubly Linked List"],
    answer: 3
  },
  {
    question: "The extra pointer in DLL is mainly used for:",
    options: ["Random access", "Backward traversal", "Memory optimization", "Sorting"],
    answer: 1
  },
  {
    question: "To update a value in DLL, we need to:",
    options: ["Traverse to the node and update data", "Update prev", "Update next", "Delete and reinsert"],
    answer: 0
  },
  {
    question: "Insertion before a given node in DLL requires access to:",
    options: ["Only next pointer", "Only prev pointer", "Both next and prev pointers", "Random pointer"],
    answer: 2
  },
  {
    question: "The predecessor of a node in DLL is accessed using:",
    options: ["Next", "Prev", "Head", "Index"],
    answer: 1
  },
  {
    question: "The successor of a node in DLL is accessed using:",
    options: ["Prev", "Head", "Next", "Index"],
    answer: 2
  },
  {
    question: "Is it possible to insert a node in O(1) time in DLL if we have the pointer to the node before it?",
    options: ["No", "Yes", "Only in singly list", "Not sure"],
    answer: 1
  },
  {
    question: "What is the primary use case of DLL over SLL?",
    options: ["Compact storage", "Two-way traversal", "Stack implementation", "Easy sorting"],
    answer: 1
  }
];
const mediumQuestions = [
  {
    question: "What is the time complexity of deleting a node from a doubly linked list if the pointer to the node is given?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 0
  },
  {
    question: "Which of the following is NOT true about doubly linked lists?",
    options: [
      "Each node has pointers to the next and previous nodes",
      "Head’s previous pointer is NULL",
      "Tail’s next pointer is not NULL",
      "Traversal is possible in both directions"
    ],
    answer: 2
  },
  {
    question: "Which operation is more efficient in a doubly linked list than in a singly linked list?",
    options: ["Traversal", "Insertion at head", "Deletion of a given node", "Searching"],
    answer: 2
  },
  {
    question: "To delete the last node in a DLL, we need access to:",
    options: ["Only head node", "Only last node", "Head and last node", "Node before last"],
    answer: 3
  },
  {
    question: "What is the minimum number of pointers required to insert a node in the middle of a DLL?",
    options: ["1", "2", "3", "4"],
    answer: 2
  },
  {
    question: "In a DLL, what would be the result of setting both the `next` and `prev` pointers of a node to NULL?",
    options: ["Circular list", "Deletion of the node", "Node becomes an isolated node", "Infinite loop"],
    answer: 2
  },
  {
    question: "What does a typical node in a DLL contain?",
    options: [
      "Only data and next pointer",
      "Only data and prev pointer",
      "Data, next and prev pointers",
      "Only one pointer"
    ],
    answer: 2
  },
  {
    question: "Which of the following is required for reverse traversal in DLL?",
    options: ["Tail pointer", "Head pointer", "Looping to the end", "All of the above"],
    answer: 3
  },
  {
    question: "What is the worst-case time complexity of searching for an element in a DLL of size n?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
    answer: 2
  },
  {
    question: "To implement a DLL, how many types of pointers are maintained in each node?",
    options: ["1", "2", "3", "4"],
    answer: 1
  },
  {
    question: "Which of the following operations is easiest to implement in a DLL compared to a SLL?",
    options: ["Reversing the list", "Searching a node", "Traversing forward", "Counting nodes"],
    answer: 0
  },
  {
    question: "What will be the result if we forget to update the `prev` pointer during insertion in a DLL?",
    options: ["Memory leak", "Segmentation fault", "Broken link", "Cyclic structure"],
    answer: 2
  },
  {
    question: "What is the space complexity of a DLL with n elements?",
    options: ["O(n)", "O(1)", "O(log n)", "O(n²)"],
    answer: 0
  },
  {
    question: "To insert a node at the beginning of a DLL, which pointers need to be updated?",
    options: ["New node’s next", "Head node’s prev", "Head pointer", "All of the above"],
    answer: 3
  },
  {
    question: "Which node in a DLL has a NULL next pointer?",
    options: ["First node", "Last node", "Middle node", "None"],
    answer: 1
  },
  {
    question: "Which condition indicates the DLL is empty?",
    options: ["Head points to NULL", "Tail points to NULL", "Head == Tail", "Head and Tail point to the same node"],
    answer: 0
  },
  {
    question: "If you insert a node after a given node in DLL, what pointers are updated?",
    options: ["Given node’s next", "New node’s next", "New node’s prev", "All of the above"],
    answer: 3
  },
  {
    question: "When deleting the head node in a DLL, what should be done?",
    options: ["Set new head", "Set new head’s prev to NULL", "Free old head", "All of the above"],
    answer: 3
  },
  {
    question: "What happens if you forget to update the tail pointer during deletion of the last node?",
    options: [
      "List becomes circular",
      "Null pointer exception",
      "Tail still points to freed memory",
      "Nothing happens"
    ],
    answer: 2
  },
  {
    question: "DLLs are preferred over SLLs when:",
    options: [
      "Memory is limited",
      "Forward traversal is enough",
      "Frequent insertions and deletions in the middle are required",
      "Recursion is used"
    ],
    answer: 2
  },
  {
    question: "Can a doubly linked list be circular?",
    options: ["Yes", "No", "Only forward circular", "Only backward circular"],
    answer: 0
  },
  {
    question: "What is the result of deleting a node with only a single node in DLL?",
    options: ["Nothing", "List becomes NULL", "Segmentation fault", "Infinite loop"],
    answer: 1
  },
  {
    question: "What should be done after inserting a node between two nodes in a DLL?",
    options: [
      "Update next and prev pointers of adjacent nodes",
      "Free the node",
      "Update only data",
      "Do nothing"
    ],
    answer: 0
  },
  {
    question: "Which traversal method is used to print the DLL in reverse?",
    options: ["Recursion on next", "While using tail", "Using a stack", "Head to tail"],
    answer: 1
  },
  {
    question: "Which of the following allows faster deletion in DLL?",
    options: [
      "No traversal needed to access previous node",
      "Storing addresses in hash",
      "Using recursion",
      "Reversing the list"
    ],
    answer: 0
  },
  {
    question: "Which one is more space-efficient?",
    options: ["DLL", "SLL", "Both are equal", "None"],
    answer: 1
  },
  {
    question: "If a DLL node is corrupted (say one pointer lost), what is the likely issue?",
    options: ["One-way traversal only", "Data loss", "List breaks", "Infinite loop"],
    answer: 2
  },
  {
    question: "How do you identify the middle of a DLL efficiently?",
    options: ["Two-pointer method", "Recursion", "Hashing", "Linear search"],
    answer: 0
  },
  {
    question: "Which language natively supports DLLs using library types?",
    options: ["C++ STL (list)", "C (struct only)", "JavaScript", "Python (set)"],
    answer: 0
  },
  {
    question: "To reverse a DLL in-place, how many pointers need to be manipulated per node?",
    options: ["1", "2", "3", "None"],
    answer: 1
  }
];
const hardQuestions = [
  {
    question: "Which of the following operation is most challenging in doubly linked lists due to pointer handling complexity?",
    options: ["Insertion at beginning", "Deletion at end", "Insertion before a given node", "Traversing from head"],
    answer: 2
  },
  {
    question: "In a doubly linked list with `n` nodes, what is the maximum number of pointer changes required to insert a new node before a given node?",
    options: ["1", "2", "3", "4"],
    answer: 2
  },
  {
    question: "Which scenario is most prone to segmentation fault when manipulating pointers in a doubly linked list?",
    options: ["Traversing from head to tail", "Reversing the list", "Accessing `prev->next` when `prev` is NULL", "Deleting the last node"],
    answer: 2
  },
  {
    question: "What happens if during node deletion, only one of the `prev` or `next` pointer updates is missed?",
    options: ["The node is still deleted properly", "Memory leak occurs", "List becomes inconsistent/corrupted", "All of the above"],
    answer: 2
  },
  {
    question: "Consider a sorted doubly linked list. Which algorithm uses the structure effectively for finding a pair with a given sum?",
    options: ["Binary Search", "Hashing", "Two-pointer technique", "DFS"],
    answer: 2
  },
  {
    question: "A doubly linked list is circular. Which node condition can indicate the end of backward traversal?",
    options: ["next == NULL", "prev == head", "prev == tail", "prev == start node again"],
    answer: 3
  },
  {
    question: "What is the minimum number of node pointer manipulations to reverse a doubly linked list?",
    options: ["n", "2n", "3n", "n/2"],
    answer: 1
  },
  {
    question: "Which property allows O(1) deletion of a middle node in a doubly linked list when given a pointer to it?",
    options: ["Forward traversal", "Backward traversal", "Access to both previous and next", "Tail pointer"],
    answer: 2
  },
  {
    question: "In a multithreaded environment, what is the major issue while inserting in a doubly linked list?",
    options: ["Memory allocation", "Data races on pointer updates", "Deallocation timing", "Traversal time"],
    answer: 1
  },
  {
    question: "When implementing undo-redo functionality, doubly linked list is used because:",
    options: ["It supports fast traversal", "It is memory efficient", "It allows bidirectional traversal", "It has better insert complexity"],
    answer: 2
  },
  {
    question: "You accidentally delete the head node but have its pointer stored. How can you recover the list?",
    options: ["Access `prev`", "Access `next` and relink", "Cannot recover", "Use a global tail pointer"],
    answer: 1
  },
  {
    question: "When recursively deleting a doubly linked list from the end, which pointer must be handled first?",
    options: ["prev", "next", "head", "tail"],
    answer: 0
  },
  {
    question: "Which structure is most suitable for a web browser’s back and forward functionality?",
    options: ["Stack", "Queue", "Doubly Linked List", "Circular Queue"],
    answer: 2
  },
  {
    question: "You reverse a DLL and mistakenly update only `next` pointers. What’s the consequence?",
    options: ["List works normally", "You can traverse forward but not backward", "Complete corruption", "It becomes singly linked"],
    answer: 1
  },
  {
    question: "What’s the worst-case time complexity to find the predecessor of a node in a sorted DLL?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
    answer: 0
  },
  {
    question: "How many NULL pointers exist in a non-circular DLL of `n` nodes?",
    options: ["1", "2", "n", "n+1"],
    answer: 1
  },
  {
    question: "For inserting at the tail in O(1), what should you maintain?",
    options: ["Only head pointer", "Tail pointer", "Both head and tail pointers", "None"],
    answer: 2
  },
  {
    question: "DLL is more space-consuming than SLL because:",
    options: ["Stores extra data", "Stores two pointers", "Pointer overhead", "Requires more traversals"],
    answer: 1
  },
  {
    question: "In implementing a deque using DLL, what is the time complexity of both enqueue and dequeue operations?",
    options: ["O(n)", "O(log n)", "O(1)", "O(n log n)"],
    answer: 2
  },
  {
    question: "When converting SLL to DLL, how many pointer modifications per node are required?",
    options: ["1", "2", "3", "4"],
    answer: 1
  },
  {
    question: "In a DLL, if we remove a node and forget to update its adjacent node’s pointers, what’s the major issue?",
    options: ["Memory leak", "Segmentation fault", "Dangling pointers", "Broken links"],
    answer: 3
  },
  {
    question: "Which pointer structure must be carefully managed during backward traversal of DLL?",
    options: ["next", "prev", "tail", "NULL"],
    answer: 1
  },
  {
    question: "Which operation becomes inefficient if DLL is made circular without a dummy head?",
    options: ["Insertion at head", "Insertion at tail", "Traversal to detect end", "Deletion from middle"],
    answer: 2
  },
  {
    question: "Which of the following avoids using recursion in DLL reversal?",
    options: ["Loop", "Stack", "Backtracking", "Tail pointer"],
    answer: 0
  },
  {
    question: "What is the extra pointer logic added during merge of two DLLs?",
    options: ["Managing single next pointer", "Managing only head", "Managing both next and prev", "Managing a circular link"],
    answer: 2
  },
  {
    question: "If a DLL node points to itself in both directions, what type of structure is it?",
    options: ["Loop node", "Self-loop DLL", "Circular DLL of 1 node", "Stack"],
    answer: 2
  },
  {
    question: "In undo/redo with DLL, if you delete a command, how do you maintain the integrity?",
    options: ["Remove only from head", "Update both adjacent nodes' pointers", "Nullify data", "Restart pointer tracking"],
    answer: 1
  },
  {
    question: "How to ensure data consistency in a large DLL used in databases?",
    options: ["Use hashing", "Backup in arrays", "Use transaction logs", "Limit list length"],
    answer: 2
  },
  {
    question: "What structure enables quick node swaps in DLL (e.g. bubble sort)?",
    options: ["next-only", "prev-only", "next and prev", "circular-only"],
    answer: 2
  },
  {
    question: "While debugging a DLL in memory, how can you detect a loop manually?",
    options: ["Print addresses", "Use a visited hash", "Use Floyd’s cycle detection", "All of the above"],
    answer: 3
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
