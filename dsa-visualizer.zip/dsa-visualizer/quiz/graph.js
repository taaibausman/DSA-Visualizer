const easyQuestions = [
  {
    question: "What is a graph in DSA?",
    options: ["A tree structure", "A hierarchical structure", "A collection of nodes and edges", "A linear list"],
    answer: 2
  },
  {
    question: "Which of the following is a type of graph?",
    options: ["Binary tree", "AVL tree", "Directed graph", "Linked list"],
    answer: 2
  },
  {
    question: "What do edges in a graph represent?",
    options: ["Loops", "Trees", "Relationships between nodes", "Heights of nodes"],
    answer: 2
  },
  {
    question: "What is the maximum number of edges in an undirected graph with *n* vertices?",
    options: ["n", "n + 1", "n(n + 1)/2", "n(n - 1)/2"],
    answer: 3
  },
  {
    question: "A graph with no cycles is called a:",
    options: ["Complete graph", "Cyclic graph", "Acyclic graph", "Simple graph"],
    answer: 2
  },
  {
    question: "In a complete graph with *n* vertices, how many edges are there?",
    options: ["n", "n - 1", "n(n - 1)/2", "n(n + 1)/2"],
    answer: 2
  },
  {
    question: "What is a self-loop in a graph?",
    options: [
      "An edge connecting two vertices",
      "An edge that connects a vertex to itself",
      "A cycle of two nodes",
      "A disconnected edge"
    ],
    answer: 1
  },
  {
    question: "In which type of graph do edges have direction?",
    options: ["Undirected", "Weighted", "Directed", "Unweighted"],
    answer: 2
  },
  {
    question: "The degree of a vertex in an undirected graph is:",
    options: [
      "Number of edges in the graph",
      "Number of nodes",
      "Number of edges incident to the vertex",
      "Number of cycles"
    ],
    answer: 2
  },
  {
    question: "What is a path in a graph?",
    options: ["A cycle", "A sequence of vertices connected by edges", "A node", "A degree"],
    answer: 1
  },
  {
    question: "A graph is said to be connected if:",
    options: [
      "Every vertex is isolated",
      "There are no edges",
      "Every pair of vertices has a path",
      "It contains cycles"
    ],
    answer: 2
  },
  {
    question: "A tree is a special case of:",
    options: ["Linked list", "Heap", "Graph", "Queue"],
    answer: 2
  },
  {
    question: "Which of the following is NOT a graph traversal algorithm?",
    options: ["BFS", "DFS", "Dijkstra", "Inorder"],
    answer: 3
  },
  {
    question: "What is the time complexity of BFS on a graph with V vertices and E edges?",
    options: ["O(V²)", "O(V + E)", "O(VE)", "O(E log V)"],
    answer: 1
  },
  {
    question: "A graph that contains a cycle is called:",
    options: ["Directed", "Cyclic", "Acyclic", "Connected"],
    answer: 1
  },
  {
    question: "Which of the following represents a disconnected graph?",
    options: [
      "All vertices are connected",
      "Graph with isolated vertices",
      "Graph with no cycles",
      "Graph with equal degrees"
    ],
    answer: 1
  },
  {
    question:
      "Which data structure is used to represent a graph using space proportional to number of vertices + edges?",
    options: ["Adjacency Matrix", "Adjacency List", "Stack", "Queue"],
    answer: 1
  },
  {
    question: "A minimum spanning tree is applicable to:",
    options: [
      "Directed Acyclic Graphs",
      "Weighted undirected graphs",
      "Trees only",
      "Simple paths only"
    ],
    answer: 1
  },
  {
    question: "In an undirected graph, each edge contributes how many degrees to the total?",
    options: ["0", "1", "2", "4"],
    answer: 2
  },
  {
    question: "In a directed graph, the out-degree of a vertex is:",
    options: [
      "Number of incoming edges",
      "Number of outgoing edges",
      "Sum of incoming and outgoing edges",
      "Total vertices"
    ],
    answer: 1
  },
  {
    question: "In a simple graph, what is the maximum number of edges possible with *n* vertices?",
    options: ["n", "n(n-1)/2", "n²", "n(n+1)/2"],
    answer: 1
  },
  {
    question: "An edge that connects a vertex to itself is called:",
    options: ["Path", "Self-loop", "Bidirectional edge", "Cross-edge"],
    answer: 1
  },
  {
    question: "Which of the following algorithms is used to find shortest paths?",
    options: ["DFS", "BFS", "Dijkstra", "Prim’s"],
    answer: 2
  },
  {
    question: "What is the basic requirement for applying Dijkstra’s algorithm?",
    options: [
      "Directed graph",
      "Unweighted graph",
      "Non-negative edge weights",
      "Graph with cycles only"
    ],
    answer: 2
  },
  {
    question: "Which traversal method uses a queue?",
    options: ["DFS", "BFS", "Inorder", "Postorder"],
    answer: 1
  },
  {
    question: "Which of the following is true for a directed graph?",
    options: [
      "Each edge is bidirectional",
      "Each edge has a direction",
      "No self-loops",
      "No cycles"
    ],
    answer: 1
  },
  {
    question: "What is a complete graph?",
    options: [
      "A graph with self-loops",
      "A graph where every node is connected to every other node",
      "A graph with no edges",
      "A graph with one edge"
    ],
    answer: 1
  },
  {
    question: "What is the name of the data structure where adjacency is stored in a 2D matrix?",
    options: ["Adjacency List", "Queue", "Adjacency Matrix", "Hash table"],
    answer: 2
  },
  {
    question: "What is the worst-case space complexity of an adjacency matrix for a graph with *V* vertices?",
    options: ["O(V)", "O(V + E)", "O(V²)", "O(E log V)"],
    answer: 2
  },
  {
    question: "Which algorithm is commonly used to find a Minimum Spanning Tree?",
    options: ["Dijkstra", "Kruskal", "DFS", "BFS"],
    answer: 1
  }
];
const mediumQuestions = [
  {
    question: "Which of the following data structures is most suitable for implementing an adjacency list?",
    options: ["Queue", "Array", "Linked List", "Stack"],
    answer: 2
  },
  {
    question: "In an undirected graph with V vertices and E edges, what is the total number of elements in its adjacency matrix?",
    options: ["V + E", "2E", "V × V", "V + V"],
    answer: 2
  },
  {
    question: "What is the space complexity of an adjacency list for a graph with V vertices and E edges?",
    options: ["O(V²)", "O(V + E)", "O(E²)", "O(V)"],
    answer: 1
  },
  {
    question: "A graph that has no cycles and is connected is known as a:",
    options: ["DAG", "Tree", "Complete Graph", "Multigraph"],
    answer: 1
  },
  {
    question: "The Breadth-First Search (BFS) uses which of the following data structures?",
    options: ["Stack", "Queue", "Priority Queue", "Heap"],
    answer: 1
  },
  {
    question: "Which algorithm is best suited to find shortest paths in an unweighted graph?",
    options: ["Dijkstra’s", "BFS", "Bellman-Ford", "DFS"],
    answer: 1
  },
  {
    question: "What will be the result of applying DFS on a cyclic graph without marking visited nodes?",
    options: ["Shortest path", "No traversal", "Infinite loop", "Tree construction"],
    answer: 2
  },
  {
    question: "Which of the following graphs can be topologically sorted?",
    options: ["Undirected graphs", "Cyclic directed graphs", "Directed Acyclic Graphs (DAG)", "Complete graphs"],
    answer: 2
  },
  {
    question: "Which algorithm detects a cycle in a graph?",
    options: ["Dijkstra", "Prim’s", "DFS with visited stack", "Kruskal’s"],
    answer: 2
  },
  {
    question: "In Prim's algorithm, how is the next vertex selected?",
    options: ["Random vertex", "Last inserted", "Minimum weight edge", "Maximum weight edge"],
    answer: 2
  },
  {
    question: "In Kruskal's algorithm, which data structure is used to detect cycles efficiently?",
    options: ["Stack", "Disjoint Set", "Queue", "Heap"],
    answer: 1
  },
  {
    question: "What is the time complexity of Dijkstra's algorithm using a min-priority queue?",
    options: ["O(V²)", "O((V + E) log V)", "O(E log V)", "O(VE)"],
    answer: 1
  },
  {
    question: "Bellman-Ford algorithm is capable of detecting:",
    options: ["Loops", "Negative weight cycles", "Euler circuits", "Self-loops"],
    answer: 1
  },
  {
    question: "Which of the following algorithms does NOT guarantee the shortest path in graphs with negative edges?",
    options: ["Dijkstra", "Bellman-Ford", "BFS", "Floyd-Warshall"],
    answer: 0
  },
  {
    question: "The Floyd-Warshall algorithm is an example of:",
    options: ["Greedy", "Dynamic Programming", "Backtracking", "Divide and Conquer"],
    answer: 1
  },
  {
    question: "Which of the following is not possible in a simple undirected graph?",
    options: ["Cycle", "Self-loop", "Path", "Forest"],
    answer: 1
  },
  {
    question: "What is the maximum number of edges in a directed graph with n vertices and no parallel edges?",
    options: ["n", "n(n−1)", "n²", "n/2"],
    answer: 1
  },
  {
    question: "A connected graph is Eulerian if:",
    options: ["It has no cycle", "All vertices have even degree", "It has a loop", "All vertices have odd degree"],
    answer: 1
  },
  {
    question: "Which graph traversal can be used to check bipartiteness of a graph?",
    options: ["BFS", "Prim’s", "Dijkstra’s", "Topological Sort"],
    answer: 0
  },
  {
    question: "In a connected undirected graph, the number of edges in a spanning tree is:",
    options: ["V + 1", "V – 1", "E", "V × E"],
    answer: 1
  },
  {
    question: "Which graph representation is best for dense graphs?",
    options: ["Adjacency List", "Adjacency Matrix", "Incidence Matrix", "Hash Table"],
    answer: 1
  },
  {
    question: "What’s the time complexity to check if an edge exists in an adjacency matrix?",
    options: ["O(V)", "O(1)", "O(log V)", "O(E)"],
    answer: 1
  },
  {
    question: "Which property is unique to complete graphs?",
    options: ["No edges", "All vertices have odd degrees", "Every pair of distinct vertices is connected", "No cycles"],
    answer: 2
  },
  {
    question: "The minimum number of colors needed to color a bipartite graph:",
    options: ["3", "2", "Depends on number of vertices", "1"],
    answer: 1
  },
  {
    question: "In a directed graph, what is the sum of in-degrees of all vertices?",
    options: ["2E", "V", "E", "0"],
    answer: 2
  },
  {
    question: "A graph with 5 vertices and 10 edges must be:",
    options: ["Tree", "Cyclic", "DAG", "Bipartite"],
    answer: 1
  },
  {
    question: "The articulation point in a graph is:",
    options: ["A node in a cycle", "A node whose removal increases connected components", "A bridge", "A leaf node"],
    answer: 1
  },
  {
    question: "Kosaraju’s algorithm is used to find:",
    options: ["MST", "Strongly Connected Components", "Shortest path", "Negative cycles"],
    answer: 1
  },
  {
    question: "Tarjan’s algorithm finds:",
    options: ["Longest path", "Articulation points and bridges", "Bipartite graphs", "Disjoint sets"],
    answer: 1
  },
  {
    question: "The edge classification \"cross edge\" occurs in:",
    options: ["BFS only", "DFS", "Prim’s", "Kruskal’s"],
    answer: 1
  }
];
const hardQuestions = [
  {
    question: "Which of the following statements is true about an undirected graph with n vertices and n edges?",
    options: ["It must be connected", "It must contain a cycle", "It must be a tree", "It must be a complete graph"],
    answer: 1
  },
  {
    question: "A topological sort is possible if and only if the graph is:",
    options: ["Directed and cyclic", "Undirected and acyclic", "Directed and acyclic", "Undirected and cyclic"],
    answer: 2
  },
  {
    question: "In a directed graph with negative edge weights, which algorithm fails to find the shortest path?",
    options: ["Dijkstra’s algorithm", "Bellman-Ford algorithm", "Floyd-Warshall algorithm", "BFS"],
    answer: 0
  },
  {
    question: "Which algorithm can detect negative weight cycles in a graph?",
    options: ["Dijkstra’s algorithm", "Prim’s algorithm", "Kruskal’s algorithm", "Bellman-Ford algorithm"],
    answer: 3
  },
  {
    question: "What is the maximum number of edges in a directed graph with n nodes and no self-loops?",
    options: ["n²", "n(n-1)/2", "n(n-1)", "(n+1)(n+2)/2"],
    answer: 2
  },
  {
    question: "Which traversal technique is most suitable for detecting cycles in a directed graph?",
    options: ["DFS with recursion stack", "BFS", "Topological sort", "Union-Find"],
    answer: 0
  },
  {
    question: "Which of the following is not a valid application of graphs?",
    options: ["Parsing expressions", "Social networks", "Web page linking", "Compiling source code"],
    answer: 0
  },
  {
    question: "What is the time complexity of checking if a graph is bipartite using BFS?",
    options: ["O(n)", "O(n²)", "O(V + E)", "O(log n)"],
    answer: 2
  },
  {
    question: "Which algorithm is used to find strongly connected components in a directed graph?",
    options: ["Prim’s algorithm", "Tarjan’s algorithm", "Kruskal’s algorithm", "BFS"],
    answer: 1
  },
  {
    question: "Which of the following graph representations has the fastest edge lookup?",
    options: ["Adjacency Matrix", "Adjacency List", "Incidence Matrix", "Edge List"],
    answer: 0
  },
  {
    question: "Kosaraju's algorithm is used for:",
    options: ["Shortest path", "Minimum spanning tree", "Strongly connected components", "Bipartite checking"],
    answer: 2
  },
  {
    question: "Which graph property makes it impossible to perform topological sorting?",
    options: ["Being disconnected", "Being cyclic", "Having isolated nodes", "Being undirected"],
    answer: 1
  },
  {
    question: "If a graph has exactly one MST, what can we say about its edge weights?",
    options: ["All are distinct", "All are equal", "All are zero", "Any number can be repeated"],
    answer: 0
  },
  {
    question: "How many minimum edges must be removed from a complete graph with n vertices to make it a tree?",
    options: ["n-1", "n", "n(n-1)/2 - (n-1)", "(n²)/2"],
    answer: 2
  },
  {
    question: "Which of the following algorithms does NOT use greedy strategy?",
    options: ["Prim’s", "Kruskal’s", "Dijkstra’s", "Bellman-Ford"],
    answer: 3
  },
  {
    question: "Which is the best representation for a sparse graph?",
    options: ["Adjacency matrix", "Edge list", "Adjacency list", "Incidence matrix"],
    answer: 2
  },
  {
    question: "Which traversal is guaranteed to find the shortest path in an unweighted graph?",
    options: ["DFS", "BFS", "Bellman-Ford", "Dijkstra"],
    answer: 1
  },
  {
    question: "Which graph algorithm works correctly only for Directed Acyclic Graphs (DAGs)?",
    options: ["BFS", "DFS", "Topological Sort", "Dijkstra’s"],
    answer: 2
  },
  {
    question: "What is the maximum number of edges in a complete undirected graph with n vertices?",
    options: ["n²", "n(n-1)", "n(n+1)/2", "n(n-1)/2"],
    answer: 3
  },
  {
    question: "Which data structure is typically used to implement DFS?",
    options: ["Queue", "Stack", "Heap", "Priority Queue"],
    answer: 1
  },
  {
    question: "Which graph traversal is more memory efficient for wide graphs?",
    options: ["DFS", "BFS", "Both are equal", "None"],
    answer: 0
  },
  {
    question: "Which algorithm is most suitable to find the shortest path in a weighted graph with negative edges but no negative cycles?",
    options: ["Dijkstra", "Kruskal", "Bellman-Ford", "Prim"],
    answer: 2
  },
  {
    question: "Which graph has the property that all nodes are reachable from every other node?",
    options: ["Bipartite", "Complete", "Tree", "DAG"],
    answer: 1
  },
  {
    question: "Which of the following is true about a graph with no cycles?",
    options: ["It is always connected", "It is a tree", "It is a forest", "It is a DAG"],
    answer: 2
  },
  {
    question: "Which of the following cannot be the degree sequence of a simple undirected graph?",
    options: ["3, 3, 3, 3", "2, 2, 2, 2", "1, 1, 1, 1", "4, 3, 2, 1"],
    answer: 0
  },
  {
    question: "Which algorithm is used to find the articulation points in a graph?",
    options: ["Prim’s", "Kruskal’s", "Tarjan’s", "Floyd-Warshall"],
    answer: 2
  },
  {
    question: "Which of the following indicates a bridge in a graph?",
    options: ["Removal disconnects the graph", "Removal creates a cycle", "Addition increases connectivity", "It's a leaf node"],
    answer: 0
  },
  {
    question: "Which concept is essential for solving the \"minimum cut\" problem in a flow network?",
    options: ["Graph coloring", "Bipartiteness", "Max-flow", "MST"],
    answer: 2
  },
  {
    question: "Which problem is NP-Complete on general graphs but solvable in polynomial time on trees?",
    options: ["Graph coloring", "Hamiltonian path", "Shortest path", "Vertex cover"],
    answer: 3
  },
  {
    question: "If a graph contains an Eulerian circuit, which must be true?",
    options: ["All vertices have even degree", "Graph must be complete", "Graph must be directed", "All edges have the same weight"],
    answer: 0
  }
];


let currentQuestions = [];

function loadQuestions() {
  const level = document.getElementById("difficulty").value;
  if (level === "easy") currentQuestions = easyQuestions;
  else if (level === "medium") currentQuestions = mediumQuestions;
  else currentQuestions = hardQuestions;

  const container = document.getElementById("quizContainer");
  container.innerHTML = "";

  currentQuestions.forEach((q, i) => {
    const block = document.createElement("div");
    block.className = "question-block";
    block.innerHTML = `
      <h3>Q${i + 1}: ${q.question}</h3>
      ${q.options.map((opt, j) => `
        <div class="option">
          <input type="radio" name="q${i}" id="q${i}_o${j}" value="${j}">
          <label for="q${i}_o${j}">${opt}</label>
        </div>
      `).join("")}
    `;
    container.appendChild(block);
  });

  document.getElementById("quizResult").innerHTML = "";
}

function submitQuiz() {
  let correct = 0, wrong = 0, attempted = 0;

  currentQuestions.forEach((q, i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    const radios = document.getElementsByName(`q${i}`);
    if (selected) {
      attempted++;
      const ans = parseInt(selected.value);
      const label = selected.nextElementSibling;

      if (ans === q.answer) {
        label.classList.add("correct");
        correct++;
      } else {
        label.classList.add("incorrect");
        wrong++;
        // blink correct one
        radios[q.answer].nextElementSibling.classList.add("correct", "blink");
      }
    }
  });

  const result = `
    🧮 Attempted: ${attempted} <br>
    ✅ Correct: ${correct} <br>
    ❌ Wrong: ${wrong}
  `;
  document.getElementById("quizResult").innerHTML = result;
}

// Theme toggle logic
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});

// Load default level (easy) on page load
window.onload = loadQuestions;
