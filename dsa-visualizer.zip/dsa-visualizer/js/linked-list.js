let head = null;

class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}
function renderLinkedList() {
  const box = document.getElementById("llBox");
  box.innerHTML = "";

  let temp = head;
  let isFirst = true;

  while (temp) {
    const div = document.createElement("div");
    div.className = "node";
    div.textContent = isFirst ? `Head: ${temp.value}` : temp.value;

    const arrow = document.createElement("span");
    arrow.textContent = temp.next ? " → " : "";
    arrow.className = "arrow";

    box.appendChild(div);
    box.appendChild(arrow);

    temp = temp.next;
    isFirst = false;
  }
}

function insertTail() {
  const val = document.getElementById("llInput").value.trim();
  if (val === "") return;

  const newNode = new Node(val);
  if (!head) {
    head = newNode;
    logLLExplain(`🟢 Head node "${val}" created.`);
  } else {
    let temp = head;
    while (temp.next) {
      temp = temp.next;
    }
    temp.next = newNode;
    logLLExplain(`➕ Inserted "${val}" after tail.`);
  }

  renderLinkedList();
  document.getElementById("llInput").value = "";
}

function deleteByValue() {
  const val = document.getElementById("llInput").value.trim();
  if (val === "") return;

  if (!head) {
    logLLExplain("⚠️ List is empty.");
    return;
  }

  if (head.value === val) {
    head = head.next;
    renderLinkedList();
    logLLExplain(`🗑️ Deleted "${val}" from head.`);
    return;
  }

  let curr = head;
  while (curr.next && curr.next.value !== val) {
    curr = curr.next;
  }

  if (curr.next && curr.next.value === val) {
    curr.next = curr.next.next;
    renderLinkedList();
    logLLExplain(`🗑️ Deleted "${val}" from list.`);
  } else {
    logLLExplain(`❌ Value "${val}" not found.`);
  }

  document.getElementById("llInput").value = "";
}

function resetList() {
  head = null;
  document.getElementById("llBox").innerHTML = "";
  document.getElementById("llExplainList").innerHTML = "";
  logLLExplain("🔄 Linked list has been reset.");
}

function renderLinkedList() {
  const box = document.getElementById("llBox");
  box.innerHTML = "";
  let temp = head;
  while (temp) {
    const div = document.createElement("div");
    div.className = "node";
    div.textContent = temp.value;

    const arrow = document.createElement("span");
    arrow.textContent = temp.next ? " → " : "";
    arrow.className = "arrow";

    box.appendChild(div);
    box.appendChild(arrow);
    temp = temp.next;
  }
}

function logLLExplain(msg) {
  const list = document.getElementById("llExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}

const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
})