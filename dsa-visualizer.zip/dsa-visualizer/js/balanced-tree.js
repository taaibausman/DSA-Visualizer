const explanation = document.getElementById("btExplainSection");
const box = document.getElementById("btBox");

class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
    this.height = 1;
  }
}

let root = null;

function height(node) {
  return node ? node.height : 0;
}

function getBalance(node) {
  return node ? height(node.left) - height(node.right) : 0;
}

function rightRotate(y) {
  const x = y.left;
  const T2 = x.right;
  x.right = y;
  y.left = T2;
  y.height = 1 + Math.max(height(y.left), height(y.right));
  x.height = 1 + Math.max(height(x.left), height(x.right));
  return x;
}

function leftRotate(x) {
  const y = x.right;
  const T2 = y.left;
  y.left = x;
  x.right = T2;
  x.height = 1 + Math.max(height(x.left), height(x.right));
  y.height = 1 + Math.max(height(y.left), height(y.right));
  return y;
}
function insertBalanced(node, value) {
  if (!node) {
    logExplain(`🟢 Inserted "${value}"`);
    return new TreeNode(value);
  }

  if (value < node.value) {
    node.left = insertBalanced(node.left, value);
  } else if (value > node.value) {
    node.right = insertBalanced(node.right, value);
  } else {
    logExplain(`❌ Value "${value}" already exists.`);
    return node;
  }

  node.height = 1 + Math.max(height(node.left), height(node.right));
  const balance = getBalance(node);

  // 🔁 Rotations with explanation
  if (balance > 1 && value < node.left.value) {
    logExplain(`🔁 Left-Left (LL) imbalance at "${node.value}". Performing Right Rotation.`);
    return rightRotate(node);
  }

  if (balance < -1 && value > node.right.value) {
    logExplain(`🔁 Right-Right (RR) imbalance at "${node.value}". Performing Left Rotation.`);
    return leftRotate(node);
  }

  if (balance > 1 && value > node.left.value) {
    logExplain(`🔁 Left-Right (LR) imbalance at "${node.value}". Performing Left-Right Rotation.`);
    node.left = leftRotate(node.left);
    return rightRotate(node);
  }

  if (balance < -1 && value < node.right.value) {
    logExplain(`🔁 Right-Left (RL) imbalance at "${node.value}". Performing Right-Left Rotation.`);
    node.right = rightRotate(node.right);
    return leftRotate(node);
  }

  return node;
}

function insertNode() {
  const val = document.getElementById("btInput").value.trim();
  if (val === "") return;
  root = insertBalanced(root, val);
  document.getElementById("btInput").value = "";
  renderTree();
}

function renderTree() {
  box.innerHTML = "";
  if (!root) return;

  const canvasWidth = box.offsetWidth;
  const centerX = canvasWidth / 2;
  const startY = 60;
  const baseSpacing = 200; // Increased from 120 or 100
  const verticalSpacing = 100;

  function placeNode(node, x, y, level) {
    if (!node) return;

    const nodeDiv = document.createElement("div");
    nodeDiv.className = "bt-node";
    nodeDiv.textContent = node.value;
    nodeDiv.style.left = `${x}px`;
    nodeDiv.style.top = `${y}px`;
    box.appendChild(nodeDiv);

    const offset = baseSpacing / Math.pow(2, level); // Adjust spacing by level

    placeNode(node.left, x - offset, y + verticalSpacing, level + 1);
    placeNode(node.right, x + offset, y + verticalSpacing, level + 1);
  }

  placeNode(root, centerX, startY, 0);
}

function resetTree() {
  root = null;
  box.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Tree reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

function traverseTree(type) {
  let result = [];
  if (type === "inorder") inorder(root, result);
  logExplain(`🔍 Inorder: ${result.join(" → ")}`);
}

function inorder(node, res) {
  if (!node) return;
  inorder(node.left, res);
  res.push(node.value);
  inorder(node.right, res);
}
function deleteNodeFromAVL(value) {
  if (!root) {
    logExplain(`⚠️ Tree is empty.`);
    return;
  }

  const [newRoot, deleted] = deleteAVL(root, value);
  if (deleted) {
    root = newRoot;
    logExplain(`🗑️ Node "${value}" deleted from AVL Tree.`);
    renderTree();
  } else {
    logExplain(`❌ Value "${value}" not found.`);
  }
}

function deleteAVL(node, value) {
  if (!node) return [null, false];

  let deleted = false;

  if (value < node.value) {
    [node.left, deleted] = deleteAVL(node.left, value);
  } else if (value > node.value) {
    [node.right, deleted] = deleteAVL(node.right, value);
  } else {
    deleted = true;
    if (!node.left || !node.right) {
      node = node.left || node.right;
    } else {
      let successor = node.right;
      while (successor.left) successor = successor.left;
      node.value = successor.value;
      [node.right] = deleteAVL(node.right, successor.value);
    }
  }

  if (!node) return [null, deleted];

  node.height = 1 + Math.max(height(node.left), height(node.right));
  const balance = getBalance(node);

  // Rebalancing with logs
  if (balance > 1 && getBalance(node.left) >= 0) {
    logExplain(`🔁 Right Rotation (LL imbalance) at node "${node.value}"`);
    return [rightRotate(node), deleted];
  }
  if (balance > 1 && getBalance(node.left) < 0) {
    logExplain(`🔁 Left-Right Rotation (LR imbalance) at node "${node.value}"`);
    node.left = leftRotate(node.left);
    return [rightRotate(node), deleted];
  }
  if (balance < -1 && getBalance(node.right) <= 0) {
    logExplain(`🔁 Left Rotation (RR imbalance) at node "${node.value}"`);
    return [leftRotate(node), deleted];
  }
  if (balance < -1 && getBalance(node.right) > 0) {
    logExplain(`🔁 Right-Left Rotation (RL imbalance) at node "${node.value}"`);
    node.right = rightRotate(node.right);
    return [leftRotate(node), deleted];
  }

  return [node, deleted];
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
