let priorityQueue = [];

function pqEnqueue() {
  const val = document.getElementById("pqValue").value.trim();
  const priority = parseInt(document.getElementById("pqPriority").value);
  if (val === "" || isNaN(priority)) return;

  // Insert by priority (lower number = higher priority)
  priorityQueue.push({ val, priority });
  priorityQueue.sort((a, b) => a.priority - b.priority);

  renderPQ();
  logPQExplain(`✅ Enqueued "${val}" with priority ${priority}.`);
  document.getElementById("pqValue").value = "";
  document.getElementById("pqPriority").value = "";
}

function pqDequeue() {
  if (priorityQueue.length === 0) {
    logPQExplain("⚠️ Queue is empty. Cannot dequeue.");
    return;
  }
  const removed = priorityQueue.shift();
  renderPQ();
  logPQExplain(`🗑️ Dequeued "${removed.val}" (priority ${removed.priority}).`);
}

function pqReset() {
  priorityQueue = [];
  renderPQ();
  document.getElementById("pqExplainList").innerHTML = "";
  logPQExplain("🔄 Priority Queue has been reset.");
}

function renderPQ() {
  const box = document.getElementById("pqBox");
  box.innerHTML = "";
  priorityQueue.forEach(item => {
    const div = document.createElement("div");
    div.className = "queue-item";
    div.textContent = `${item.val} (${item.priority})`;
    box.appendChild(div);
  });
}

function logPQExplain(msg) {
  const list = document.getElementById("pqExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}
