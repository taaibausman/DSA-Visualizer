const graph = {};
let positions = {};
const box = document.getElementById("graphBox");
const svg = document.getElementById("graphSvg");

function addVertex() {
  const name = document.getElementById("vertexInput").value.trim();
  if (!name || graph[name]) return;
  graph[name] = [];
  logExplain(`🟢 Added vertex "${name}"`);
  updatePositions();
  renderGraph();
  document.getElementById("vertexInput").value = "";
}

function deleteVertex() {
  const name = document.getElementById("deleteVertexInput").value.trim();
  if (!name || !graph[name]) return;
  delete graph[name];
  for (let node in graph) {
    graph[node] = graph[node].filter(([v]) => v !== name);
  }
  logExplain(`🗑️ Deleted vertex "${name}"`);
  updatePositions();
  renderGraph();
  document.getElementById("deleteVertexInput").value = "";
}

function addEdge() {
  const u = document.getElementById("edgeFrom").value.trim();
  const v = document.getElementById("edgeTo").value.trim();
  const w = parseFloat(document.getElementById("edgeWeight").value.trim());
  if (!u || !v || isNaN(w) || !graph[u] || !graph[v]) return;

  // Prevent duplicate
  if (!graph[u].some(([neighbor]) => neighbor === v)) {
    graph[u].push([v, w]);
    logExplain(`🔗 Added edge from "${u}" to "${v}" with weight ${w}`);
  }

  renderGraph();
  document.getElementById("edgeFrom").value = "";
  document.getElementById("edgeTo").value = "";
  document.getElementById("edgeWeight").value = "";
}

function deleteEdge() {
  const u = document.getElementById("edgeFrom").value.trim();
  const v = document.getElementById("edgeTo").value.trim();
  if (!u || !v || !graph[u]) return;
  graph[u] = graph[u].filter(([node]) => node !== v);
  logExplain(`❌ Deleted edge from "${u}" to "${v}"`);
  renderGraph();
  document.getElementById("edgeFrom").value = "";
  document.getElementById("edgeTo").value = "";
}

function updatePositions() {
  const keys = Object.keys(graph);
  const centerX = box.offsetWidth / 2;
  const centerY = box.offsetHeight / 2;
  const radius = Math.min(centerX, centerY) - 80;

  positions = {};
  keys.forEach((name, i) => {
    const angle = (2 * Math.PI * i) / keys.length;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    positions[name] = { x, y };
  });
}

function renderGraph() {
  box.innerHTML = "";
  svg.innerHTML = "";

  // Draw edges first
  for (let u in graph) {
    for (let [v, w] of graph[u]) {
      drawEdge(u, v, w);
    }
  }

  // Draw nodes
  for (let node in positions) {
    const { x, y } = positions[node];
    const div = document.createElement("div");
    div.className = "bt-node";
    div.textContent = node;
    div.style.left = `${x}px`;
    div.style.top = `${y}px`;
    box.appendChild(div);
  }
}

function drawEdge(fromNode, toNode, weight) {
  const nodeRadius = 20;
  const from = positions[fromNode];
  const to = positions[toNode];

  const fromX = from.x + nodeRadius;
  const fromY = from.y + nodeRadius;
  const toX = to.x + nodeRadius;
  const toY = to.y + nodeRadius;

  const dx = toX - fromX;
  const dy = toY - fromY;
  const angle = Math.atan2(dy, dx);

  const x1 = fromX + nodeRadius * Math.cos(angle);
  const y1 = fromY + nodeRadius * Math.sin(angle);
  const x2 = toX - nodeRadius * Math.cos(angle);
  const y2 = toY - nodeRadius * Math.sin(angle);

   // Create arrowhead marker if not already defined
  if (!document.getElementById("arrow")) {
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker");
    marker.setAttribute("id", "arrow");
    marker.setAttribute("viewBox", "0 0 10 10");
    marker.setAttribute("refX", "10");
    marker.setAttribute("refY", "5");
    marker.setAttribute("markerWidth", "6");
    marker.setAttribute("markerHeight", "6");
    marker.setAttribute("orient", "auto");

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", "M 0 0 L 10 5 L 0 10 z");
    path.setAttribute("fill", "#444");
    marker.appendChild(path);
    defs.appendChild(marker);
    svg.appendChild(defs);
  }

  // Line (with arrow)
  const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line.setAttribute("x1", x1);
  line.setAttribute("y1", y1);
  line.setAttribute("x2", x2);
  line.setAttribute("y2", y2);
  line.setAttribute("stroke", "#444");
  line.setAttribute("stroke-width", "2");
  line.setAttribute("marker-end", "url(#arrow)");
  svg.appendChild(line);

  // Label position above line
  const midX = (x1 + x2) / 2;
  const midY = (y1 + y2) / 2;
  const offset = 12;
  const normalX = -(y2 - y1);
  const normalY = x2 - x1;
  const length = Math.sqrt(normalX ** 2 + normalY ** 2);
  const offsetX = (offset * normalX) / length;
  const offsetY = (offset * normalY) / length;

  const labelX = midX + offsetX;
  const labelY = midY + offsetY;

  // Weight label
  const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
  text.setAttribute("x", labelX);
  text.setAttribute("y", labelY);
  text.setAttribute("fill", "black");
  text.setAttribute("font-size", "14px");
  text.setAttribute("text-anchor", "middle");
  text.setAttribute("dominant-baseline", "middle");
  text.textContent = weight;
  svg.appendChild(text);
}

function resetGraph() {
  for (let key in graph) delete graph[key];
  positions = {};
  box.innerHTML = "";
  svg.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Graph reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}
function highlightPath(path) {
  const allNodes = document.querySelectorAll(".bt-node");
  allNodes.forEach((node) => {
    if (path.includes(node.textContent)) {
      node.style.backgroundColor = "gold";
    }
  });
}

function visualizeDijkstra() {
  const start = document.getElementById("sourceNode").value.trim();
  const goal = document.getElementById("targetNode").value.trim();
  if (!graph[start] || !graph[goal]) return;

  const dist = {};
  const prev = {};
  const visited = new Set();
  const pq = [];

  document.getElementById("btExplainList").innerHTML = "";

  for (let node in graph) {
    dist[node] = Infinity;
    prev[node] = null;
  }
  dist[start] = 0;
  pq.push([start, 0]);

  while (pq.length) {
    pq.sort((a, b) => a[1] - b[1]); // Min heap behavior
    const [node, cost] = pq.shift();

    if (visited.has(node)) continue;
    visited.add(node);
    logExplain(`🔍 Visiting "${node}" with cost ${cost}`);

    if (node === goal) break;

    for (let [neighbor, weight] of graph[node]) {
      const newDist = dist[node] + weight;
      if (newDist < dist[neighbor]) {
        dist[neighbor] = newDist;
        prev[neighbor] = node;
        pq.push([neighbor, newDist]);
      }
    }
  }

  if (dist[goal] === Infinity) {
    logExplain("⚠️ No path found.");
    return;
  }

  // Reconstruct path
  const path = [];
  let current = goal;
  while (current) {
    path.unshift(current);
    current = prev[current];
  }

  highlightPath(path);
  logExplain(`🎯 Dijkstra path: ${path.join(" → ")}, cost = ${dist[goal]}`);
}
function visualizeDFS() {
  const start = document.getElementById("sourceNode").value.trim();
  const goal = document.getElementById("targetNode").value.trim();
  if (!graph[start] || !graph[goal]) return;

  let minPath = null;
  let minCost = Infinity;

  function dfs(node, path, cost, visited) {
    if (cost >= minCost) return;
    if (node === goal) {
      if (cost < minCost) {
        minCost = cost;
        minPath = [...path, node];
      }
      return;
    }

    visited[node] = true;
    for (let [neighbor, weight] of graph[node]) {
      if (!visited[neighbor]) {
        dfs(neighbor, [...path, node], cost + weight, { ...visited });
      }
    }
  }

  document.getElementById("btExplainList").innerHTML = "";
  dfs(start, [], 0, {});
  
  if (minPath) {
    highlightPath(minPath);
    logExplain(`🎯 DFS path: ${minPath.join(" → ")}, cost = ${minCost}`);
  } else {
    logExplain("⚠️ No path found.");
  }
}
function visualizeBFS() {
  const start = document.getElementById("sourceNode").value.trim();
  const goal = document.getElementById("targetNode").value.trim();
  if (!graph[start] || !graph[goal]) return;

  const queue = [[start, 0, [start]]];
  const visited = {};
  let minPath = null;
  let minCost = Infinity;

  document.getElementById("btExplainList").innerHTML = "";

  while (queue.length) {
    const [node, cost, path] = queue.shift();

    if (visited[node] && visited[node] <= cost) continue;
    visited[node] = cost;

    logExplain(`🔵 BFS visiting "${node}" with cost ${cost}`);

    if (node === goal) {
      if (cost < minCost) {
        minCost = cost;
        minPath = path;
      }
      continue;
    }

    for (let [neighbor, weight] of graph[node]) {
      if (!path.includes(neighbor)) {
        queue.push([neighbor, cost + weight, [...path, neighbor]]);
      }
    }
  }

  if (minPath) {
    highlightPath(minPath);
    logExplain(`🎯 BFS path: ${minPath.join(" → ")}, cost = ${minCost}`);
  } else {
    logExplain("⚠️ No path found.");
  }
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
