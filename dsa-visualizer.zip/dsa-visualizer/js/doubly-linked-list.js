let head = null;

class DLLNode {
  constructor(value) {
    this.value = value;
    this.next = null;
    this.prev = null;
  }
}

function insertAtHead() {
  const val = document.getElementById("dllInput").value.trim();
  if (val === "") return;

  const node = new DLLNode(val);
  if (head) {
    node.next = head;
    head.prev = node;
  }
  head = node;

  renderDLL();
  logDLLExplain(`🔼 Inserted "${val}" at head.`);
  document.getElementById("dllInput").value = "";
}
function insertAfter() {
  const newVal = document.getElementById("dllInput").value.trim();
  const targetVal = document.getElementById("dllTarget").value.trim();

  if (newVal === "" || targetVal === "") return;

  let curr = head;
  while (curr && curr.value !== targetVal) {
    curr = curr.next;
  }

  if (!curr) {
    logDLLExplain(`❌ Node "${targetVal}" not found.`);
    return;
  }

  const newNode = new DLLNode(newVal);
  newNode.next = curr.next;
  newNode.prev = curr;

  if (curr.next) {
    curr.next.prev = newNode;
  }

  curr.next = newNode;

  renderDLL();
  logDLLExplain(`🧩 Inserted "${newVal}" after "${targetVal}".`);
  document.getElementById("dllInput").value = "";
  document.getElementById("dllTarget").value = "";
}

function insertAtTail() {
  const val = document.getElementById("dllInput").value.trim();
  if (val === "") return;

  const node = new DLLNode(val);
  if (!head) {
    head = node;
  } else {
    let temp = head;
    while (temp.next) temp = temp.next;
    temp.next = node;
    node.prev = temp;
  }

  renderDLL();
  logDLLExplain(`🔽 Inserted "${val}" at tail.`);
  document.getElementById("dllInput").value = "";
}

function deleteByValue() {
  const val = document.getElementById("dllInput").value.trim();
  if (!head || val === "") return;

  let temp = head;
  while (temp && temp.value !== val) {
    temp = temp.next;
  }

  if (!temp) {
    logDLLExplain(`❌ "${val}" not found.`);
    return;
  }

  if (temp.prev) temp.prev.next = temp.next;
  else head = temp.next;

  if (temp.next) temp.next.prev = temp.prev;

  renderDLL();
  logDLLExplain(`🗑️ Deleted "${val}" from list.`);
  document.getElementById("dllInput").value = "";
}

function resetDLL() {
  head = null;
  document.getElementById("dllBox").innerHTML = "";
  document.getElementById("dllExplainList").innerHTML = "";
  logDLLExplain("🔄 Doubly linked list has been reset.");
}

function renderDLL() {
  const box = document.getElementById("dllBox");
  box.innerHTML = "";

  let temp = head;
  while (temp) {
    const node = document.createElement("div");
    node.className = "node";
    node.textContent = temp.value;

    const forward = document.createElement("span");
    forward.className = "arrow";
    forward.textContent = temp.next ? "⇄" : "";

    box.appendChild(node);
    box.appendChild(forward);
    temp = temp.next;
  }
}

function logDLLExplain(msg) {
  const list = document.getElementById("dllExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}

const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
})