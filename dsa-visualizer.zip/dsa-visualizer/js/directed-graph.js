const graph = {};
let positions = {};
const box = document.getElementById("graphBox");
const svg = document.getElementById("graphSvg");

function addVertex() {
  const name = document.getElementById("vertexInput").value.trim();
  if (!name || graph[name]) return;
  graph[name] = [];
  logExplain(`🟢 Added vertex "${name}"`);
  updatePositions();
  renderGraph();
  document.getElementById("vertexInput").value = "";
}

function deleteVertex() {
  const name = document.getElementById("deleteVertexInput").value.trim();
  if (!name || !graph[name]) return;
  delete graph[name];
  for (let node in graph) {
    graph[node] = graph[node].filter((v) => v !== name);
  }
  logExplain(`🗑️ Deleted vertex "${name}"`);
  updatePositions();
  renderGraph();
  document.getElementById("deleteVertexInput").value = "";
}

function addEdge() {
  const u = document.getElementById("edgeFrom").value.trim();
  const v = document.getElementById("edgeTo").value.trim();
  if (!u || !v || !graph[u] || !graph[v]) return;
  if (!graph[u].includes(v)) graph[u].push(v);
  logExplain(`🔗 Added edge from "${u}" to "${v}"`);
  renderGraph();
  document.getElementById("edgeFrom").value = "";
  document.getElementById("edgeTo").value = "";
}

function deleteEdge() {
  const u = document.getElementById("edgeFrom").value.trim();
  const v = document.getElementById("edgeTo").value.trim();
  if (!u || !v || !graph[u]) return;
  graph[u] = graph[u].filter((x) => x !== v);
  logExplain(`❌ Deleted edge from "${u}" to "${v}"`);
  renderGraph();
  document.getElementById("edgeFrom").value = "";
  document.getElementById("edgeTo").value = "";
}

function updatePositions() {
  const keys = Object.keys(graph);
  const centerX = box.offsetWidth / 2;
  const centerY = box.offsetHeight / 2;
  const radius = Math.min(centerX, centerY) - 80;

  positions = {};
  keys.forEach((name, i) => {
    const angle = (2 * Math.PI * i) / keys.length;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    positions[name] = { x, y };
  });
}

function renderGraph() {
  box.innerHTML = "";
  svg.innerHTML = "";

  // Define arrowhead
  if (!document.getElementById("arrow")) {
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker");
    marker.setAttribute("id", "arrow");
    marker.setAttribute("viewBox", "0 0 10 10");
    marker.setAttribute("refX", "10");
    marker.setAttribute("refY", "5");
    marker.setAttribute("markerWidth", "6");
    marker.setAttribute("markerHeight", "6");
    marker.setAttribute("orient", "auto");

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", "M 0 0 L 10 5 L 0 10 z");
    path.setAttribute("fill", "#444");
    marker.appendChild(path);
    defs.appendChild(marker);
    svg.appendChild(defs);
  }

  // Draw arrows
  for (let u in graph) {
    for (let v of graph[u]) {
      drawArrow(positions[u], positions[v]);
    }
  }

  // Draw nodes
  for (let node in graph) {
    const { x, y } = positions[node];
    const div = document.createElement("div");
    div.className = "bt-node";
    div.textContent = node;
    div.style.left = `${x}px`;
    div.style.top = `${y}px`;
    box.appendChild(div);
  }
}

function drawArrow(from, to) {
  const nodeRadius = 20; // Node radius (half of 40px)

  // Center of nodes
  const fromX = from.x + nodeRadius;
  const fromY = from.y + nodeRadius;
  const toX = to.x + nodeRadius;
  const toY = to.y + nodeRadius;

  const dx = toX - fromX;
  const dy = toY - fromY;
  const angle = Math.atan2(dy, dx);

  // Arrow should touch the border of each circle
  const startX = fromX + nodeRadius * Math.cos(angle);
  const startY = fromY + nodeRadius * Math.sin(angle);
  const endX = toX - nodeRadius * Math.cos(angle);
  const endY = toY - nodeRadius * Math.sin(angle);

  const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line.setAttribute("x1", startX);
  line.setAttribute("y1", startY);
  line.setAttribute("x2", endX);
  line.setAttribute("y2", endY);
  line.setAttribute("stroke", "#444");
  line.setAttribute("stroke-width", "2");
  line.setAttribute("marker-end", "url(#arrow)");
  svg.appendChild(line);
}


function visualizeBFS() {
  const start = document.getElementById("sourceNode").value.trim();
  const goal = document.getElementById("targetNode").value.trim();
  if (!graph[start] || !graph[goal]) return;

  const visited = {};
  const queue = [[start]];

  document.getElementById("btExplainList").innerHTML = "";

  while (queue.length) {
    const path = queue.shift();
    const node = path[path.length - 1];

    if (!visited[node]) {
      visited[node] = true;
      logExplain(`🔵 BFS visiting "${node}"`);

      if (node === goal) {
        highlightPath(path);
        logExplain(`🎯 BFS path: ${path.join(" → ")}`);
        document.getElementById("sourceNode").value = "";
        document.getElementById("targetNode").value = "";
        return;
      }

      for (let neighbor of graph[node]) {
        if (!visited[neighbor]) {
          queue.push([...path, neighbor]);
        }
      }
    }
  }

  logExplain("⚠️ No path found.");
}

function visualizeDFS() {
  const start = document.getElementById("sourceNode").value.trim();
  const goal = document.getElementById("targetNode").value.trim();
  if (!graph[start] || !graph[goal]) return;

  const visited = {};
  const resultPath = [];

  function dfs(node, currentPath) {
    if (visited[node]) return false;
    visited[node] = true;
    currentPath.push(node);
    logExplain(`🟢 DFS visiting "${node}"`);
    if (node === goal) return true;

    for (let neighbor of graph[node]) {
      if (dfs(neighbor, currentPath)) return true;
    }

    currentPath.pop();
    return false;
  }

  if (dfs(start, resultPath)) {
    highlightPath(resultPath);
    logExplain(`🎯 DFS path: ${resultPath.join(" → ")}`);
  } else {
    logExplain("⚠️ No path found.");
  }

  document.getElementById("sourceNode").value = "";
  document.getElementById("targetNode").value = "";
}

function highlightPath(path) {
  const allNodes = document.querySelectorAll(".bt-node");
  allNodes.forEach((node) => {
    if (path.includes(node.textContent)) {
      node.style.backgroundColor = "gold";
    }
  });
}

function resetGraph() {
  Object.keys(graph).forEach((key) => delete graph[key]);
  Object.keys(positions).forEach((key) => delete positions[key]);
  box.innerHTML = "";
  svg.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Graph reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
