const graph = {};
const box = document.getElementById("graphBox");
const svg = document.getElementById("graphSvg");

function addVertex() {
  const name = document.getElementById("vertexInput").value.trim();
  if (!name || graph[name]) return;

  graph[name] = [];
  logExplain(`🟢 Added vertex "${name}"`);
  updatePositions(); // call to recalculate positions
  renderGraph();
  document.getElementById("vertexInput").value = "";
}

let positions = {}; // ✅ allows reassignment

function updatePositions() {
  const keys = Object.keys(graph);
  const centerX = box.offsetWidth / 2;
  const centerY = box.offsetHeight / 2;
  const radius = Math.min(centerX, centerY) - 100;

  positions = {}; // ✅ now this works
  keys.forEach((name, i) => {
    const angle = (2 * Math.PI * i) / keys.length;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    positions[name] = { x, y };
  });
}

function isOverlapping(x, y, minDist) {
  for (let key in positions) {
    const pos = positions[key];
    const dx = pos.x - x;
    const dy = pos.y - y;
    if (Math.sqrt(dx * dx + dy * dy) < minDist) return true;
  }
  return false;
}

function addEdge() {
  const u = document.getElementById("edgeFrom").value.trim();
  const v = document.getElementById("edgeTo").value.trim();
  if (!u || !v || !graph[u] || !graph[v] || u === v) return;

  if (!graph[u].includes(v)) graph[u].push(v);
  if (!graph[v].includes(u)) graph[v].push(u);

  logExplain(`🔗 Added edge between "${u}" and "${v}"`);
  renderGraph();
  document.getElementById("edgeFrom").value = "";
  document.getElementById("edgeTo").value = "";
}

function renderGraph() {
  box.innerHTML = "";
  svg.innerHTML = "";

  // Step 1: Draw all nodes
  for (let node in graph) {
    const { x, y } = positions[node];
    const div = document.createElement("div");
    div.className = "bt-node";
    div.textContent = node;
    div.style.left = `${x}px`;
    div.style.top = `${y}px`;
    box.appendChild(div);
  }

  // Step 2: Wait for layout, then draw edges
  requestAnimationFrame(() => {
    for (let u in graph) {
      for (let v of graph[u]) {
        if (u < v) drawLine(positions[u], positions[v]);
      }
    }
  });
}

function drawLine(from, to) {
  const svgRect = svg.getBoundingClientRect();
  const boxRect = box.getBoundingClientRect();

  const offsetX = boxRect.left - svgRect.left;
  const offsetY = boxRect.top - svgRect.top;

  const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line.setAttribute("x1", from.x + offsetX + 20);
  line.setAttribute("y1", from.y + offsetY + 20);
  line.setAttribute("x2", to.x + offsetX + 20);
  line.setAttribute("y2", to.y + offsetY + 20);
  line.setAttribute("stroke", "#888");
  line.setAttribute("stroke-width", "2");
  svg.appendChild(line);
}


function resetGraph() {
  Object.keys(graph).forEach(key => delete graph[key]);
  Object.keys(positions).forEach(key => delete positions[key]);
  box.innerHTML = "";
  svg.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Graph reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}
function deleteVertex() {
  const name = document.getElementById("deleteVertexInput").value.trim();
  if (!graph[name]) {
    logExplain(`❌ Vertex "${name}" does not exist.`);
    return;
  }

  // Remove from all adjacency lists
  for (let v in graph) {
    graph[v] = graph[v].filter(n => n !== name);
  }

  // Delete vertex and position
  delete graph[name];
  delete positions[name];

  logExplain(`🗑️ Deleted vertex "${name}"`);
  updatePositions();
  renderGraph();
  document.getElementById("deleteVertexInput").value = "";
}
function visualizeBFS() {
  const start = prompt("Enter starting vertex for BFS:");
  const goal = prompt("Enter goal vertex for BFS:");
  if (!graph[start] || !graph[goal]) {
    logExplain(`❌ Invalid vertex: start or goal does not exist.`);
    return;
  }

  const visited = {};
  const queue = [start];
  const path = { [start]: null };
  const steps = [];

  visited[start] = true;

  while (queue.length) {
    const current = queue.shift();
    steps.push(current);

    for (const neighbor of graph[current]) {
      if (!visited[neighbor]) {
        visited[neighbor] = true;
        queue.push(neighbor);
        path[neighbor] = current;
      }
    }
  }

  let i = 0;
  const interval = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(interval);

      if (!path.hasOwnProperty(goal)) {
        logExplain(`❌ Goal "${goal}" not reachable from "${start}".`);
        return;
      }

      const shortest = [];
      let temp = goal;
      while (temp !== null) {
        shortest.push(temp);
        temp = path[temp];
      }
      shortest.reverse();
      logExplain(`📍 BFS path from "${start}" to "${goal}": ${shortest.join(" → ")}`);
      shortest.forEach((v, idx) => {setTimeout(() => highlightNode(v, "path"), 300 * idx);});

      return;
    }

    const node = steps[i];
    highlightNode(node, "bfs");
    logExplain(`🔵 BFS visiting "${node}"`);
    i++;
  }, 700);
}
function visualizeDFS() {
  const start = prompt("Enter starting vertex for DFS:");
  const goal = prompt("Enter goal vertex for DFS:");
  if (!graph[start] || !graph[goal]) {
    logExplain(`❌ Invalid vertex: start or goal does not exist.`);
    return;
  }

  const visited = {};
  const parent = { [start]: null };
  const steps = [];

  function dfs(node) {
    visited[node] = true;
    steps.push(node);

    for (const neighbor of graph[node]) {
      if (!visited[neighbor]) {
        parent[neighbor] = node;
        dfs(neighbor);
      }
    }
  }

  dfs(start);

  let i = 0;
  const interval = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(interval);

      if (!parent.hasOwnProperty(goal)) {
        logExplain(`❌ Goal "${goal}" not reachable from "${start}".`);
        return;
      }

      const path = [];
      let temp = goal;
      while (temp !== null) {
        path.push(temp);
        temp = parent[temp];
      }
      path.reverse();
      logExplain(`📍 DFS path to "${start}" to "${goal}": ${path.join(" → ")}`);
      path.forEach((v, idx) => {setTimeout(() => highlightNode(v, "path"), 300 * idx);});
      return;
    }

    const node = steps[i];
    highlightNode(node, "dfs");
    logExplain(`🟢 DFS visiting "${node}"`);
    i++;
  }, 700);
}

function highlightNode(node, type) {
  const all = document.querySelectorAll(".bt-node");
  all.forEach(n => n.classList.remove("highlight-bfs", "highlight-dfs"));
  const div = Array.from(all).find(n => n.textContent === node);
  if (div) {
    div.classList.add(type === "bfs" ? "highlight-bfs" : "highlight-dfs");
  }
}
function deleteEdge() {
  const u = document.getElementById("deleteEdgeFrom").value.trim();
  const v = document.getElementById("deleteEdgeTo").value.trim();

  if (!u || !v || !graph[u] || !graph[v]) {
    logExplain(`❌ Invalid vertex name(s) or edge.`);
    return;
  }

  const removedFromU = graph[u].includes(v);
  const removedFromV = graph[v].includes(u);

  // Remove v from u's adjacency list
  graph[u] = graph[u].filter(vertex => vertex !== v);
  // Remove u from v's adjacency list
  graph[v] = graph[v].filter(vertex => vertex !== u);

  if (removedFromU || removedFromV) {
    logExplain(`🗑️ Deleted edge between "${u}" and "${v}".`);
  } else {
    logExplain(`⚠️ Edge between "${u}" and "${v}" does not exist.`);
  }

  renderGraph();

  document.getElementById("deleteEdgeFrom").value = "";
  document.getElementById("deleteEdgeTo").value = "";
}

// Theme toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
