let head = null;

class CLLNode {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

function insertTail() {
  const val = document.getElementById("cllInput").value.trim();
  if (val === "") return;

  const node = new CLLNode(val);
  if (!head) {
    node.next = node;
    head = node;
    logCLLExplain(`🟢 Head node "${val}" created.`);
  } else {
    let temp = head;
    while (temp.next !== head) {
      temp = temp.next;
    }
    temp.next = node;
    node.next = head;
    logCLLExplain(`➕ Inserted "${val}" at tail.`);
  }

  renderCLL();
  document.getElementById("cllInput").value = "";
}

function deleteByValue() {
  const val = document.getElementById("cllInput").value.trim();
  if (val === "") return;
  if (!head) {
    logCLLExplain("⚠️ List is empty.");
    return;
  }

  let curr = head, prev = null;
  let found = false;

  do {
    if (curr.value === val) {
      found = true;
      break;
    }
    prev = curr;
    curr = curr.next;
  } while (curr !== head);

  if (!found) {
    logCLLExplain(`❌ "${val}" not found.`);
    return;
  }

  if (curr === head && curr.next === head) {
    head = null;
  } else if (curr === head) {
    let temp = head;
    while (temp.next !== head) temp = temp.next;
    head = head.next;
    temp.next = head;
  } else {
    prev.next = curr.next;
  }

  renderCLL();
  logCLLExplain(`🗑️ Deleted "${val}" from list.`);
  document.getElementById("cllInput").value = "";
}

function resetCLL() {
  head = null;
  document.getElementById("cllBox").innerHTML = "";
  document.getElementById("cllExplainList").innerHTML = "";
  logCLLExplain("🔄 Circular linked list has been reset.");
}

function renderCLL() {
  const box = document.getElementById("cllBox");
  box.innerHTML = "";

  if (!head) return;

  let temp = head;
  do {
    const node = document.createElement("div");
    node.className = "node";
    node.textContent = temp.value;

    const arrow = document.createElement("span");
    arrow.textContent = temp.next !== head ? " → " : " ⟳";
    arrow.className = "arrow";

    box.appendChild(node);
    box.appendChild(arrow);

    temp = temp.next;
  } while (temp !== head);
}

function logCLLExplain(msg) {
  const list = document.getElementById("cllExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}

const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
})