const MAX = 6;
let cq = new Array(MAX).fill(null);
let front = 0;
let rear = 0;

function renderCQ() {
  const box = document.getElementById("cqBox");
  box.innerHTML = "";
  for (let i = 0; i < MAX; i++) {
    const div = document.createElement("div");
    div.className = "queue-item";
    div.textContent = cq[i] !== null ? cq[i] : "•";
    box.appendChild(div);
  }
}

function cqEnqueue() {
  const input = document.getElementById("cqInput");
  const val = input.value.trim();
  if (val === "") return;

  const nextRear = (rear + 1) % MAX;
  if (nextRear === front) {
    logCQExplain("⚠️ Queue is full. Cannot enqueue.");
    return;
  }

  rear = nextRear;
  cq[rear] = val;
  renderCQ();
  logCQExplain(`✅ Enqueued "${val}" at index ${rear}.`);
  input.value = "";
}

function cqDequeue() {
  if (front === rear) {
    logCQExplain("⚠️ Queue is empty. Cannot dequeue.");
    return;
  }

  front = (front + 1) % MAX;
  const removed = cq[front];
  cq[front] = null;

  renderCQ();
  logCQExplain(`🗑️ Dequeued "${removed}" from index ${front}.`);
}

function cqReset() {
  cq = new Array(MAX).fill(null);
  front = rear = 0;
  renderCQ();
  document.getElementById("cqExplainList").innerHTML = "";
  logCQExplain("🔄 Circular Queue has been reset.");
}

function logCQExplain(msg) {
  const list = document.getElementById("cqExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}

window.onload = renderCQ;
