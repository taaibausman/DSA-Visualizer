const SIZE = 7;
let deque = new Array(SIZE).fill(null);
let front = 0, rear = 0;

function renderDeque() {
  const box = document.getElementById("dequeBox");
  box.innerHTML = "";
  for (let i = 0; i < SIZE; i++) {
    const div = document.createElement("div");
    div.className = "queue-item";
    div.textContent = deque[i] !== null ? deque[i] : "•";
    box.appendChild(div);
  }
}

function isFull() {
  return (rear + 1) % SIZE === front;
}

function isEmpty() {
  return front === rear;
}

function insertFront() {
  const val = document.getElementById("dequeInput").value.trim();
  if (val === "") return;

  if (isFull()) {
    logDequeExplain("⚠️ Deque is full. Cannot insert front.");
    return;
  }

  front = (front - 1 + SIZE) % SIZE;
  deque[front] = val;
  renderDeque();
  logDequeExplain(`⬅️ Inserted "${val}" at front.`);
  document.getElementById("dequeInput").value = "";
}

function insertRear() {
  const val = document.getElementById("dequeInput").value.trim();
  if (val === "") return;

  if (isFull()) {
    logDequeExplain("⚠️ Deque is full. Cannot insert rear.");
    return;
  }

  rear = (rear + 1) % SIZE;
  deque[rear] = val;
  renderDeque();
  logDequeExplain(`➡️ Inserted "${val}" at rear.`);
  document.getElementById("dequeInput").value = "";
}

function deleteFront() {
  if (isEmpty()) {
    logDequeExplain("⚠️ Deque is empty. Cannot delete front.");
    return;
  }

  front = (front + 1) % SIZE;
  const removed = deque[front];
  deque[front] = null;
  renderDeque();
  logDequeExplain(`🗑️ Removed "${removed}" from front.`);
}

function deleteRear() {
  if (isEmpty()) {
    logDequeExplain("⚠️ Deque is empty. Cannot delete rear.");
    return;
  }

  const removed = deque[rear];
  deque[rear] = null;
  rear = (rear - 1 + SIZE) % SIZE;
  renderDeque();
  logDequeExplain(`🗑️ Removed "${removed}" from rear.`);
}

function resetDeque() {
  deque = new Array(SIZE).fill(null);
  front = rear = 0;
  renderDeque();
  document.getElementById("dequeExplainList").innerHTML = "";
  logDequeExplain("🔄 Deque has been reset.");
}

function logDequeExplain(msg) {
  const list = document.getElementById("dequeExplainList");
  const li = document.createElement("li");
  li.textContent = msg;
  list.appendChild(li);
}

window.onload = renderDeque;
