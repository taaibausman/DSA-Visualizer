const explanation = document.getElementById("btExplainSection");
const rootOffset = 100;
let currentY = 40;
const box = document.getElementById("btBox");
const svg = document.getElementById("btLines");

class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

let root = null;

function containsValue(node, val) {
  if (!node) return false;
  if (node.value === val) return true;
  return containsValue(node.left, val) || containsValue(node.right, val);
}

function insertNode() {
  const val = document.getElementById("btInput").value.trim();
  if (val === "") return;

  if (containsValue(root, val)) {
    logExplain(`❌ Value "${val}" already exists.`);
    return;
  }

  const newNode = new TreeNode(val);
  if (!root) {
    root = newNode;
    logExplain(`🟢 Root node "${val}" inserted.`);
  } else {
    const queue = [root];
    while (queue.length) {
      const node = queue.shift();
      if (!node.left) {
        node.left = newNode;
        logExplain(`➕ Inserted "${val}" to left of "${node.value}".`);
        break;
      } else queue.push(node.left);

      if (!node.right) {
        node.right = newNode;
        logExplain(`➕ Inserted "${val}" to right of "${node.value}".`);
        break;
      } else queue.push(node.right);
    }
  }

  document.getElementById("btInput").value = "";
  renderTree();
}
function renderTree() {
  box.innerHTML = "";
  svg.innerHTML = "";
  if (!root) return;

  const nodeMap = new Map();
  const nodeRadius = 20;
  const horizontalSpacing = 80;
  const verticalSpacing = 100;

  function calculateNodePositions(node, depth = 0, xOffset = 0) {
    if (!node) return { width: 0, center: xOffset };

    const left = calculateNodePositions(node.left, depth + 1, xOffset);
    const currentX = left.center + left.width * horizontalSpacing;
    const currentY = depth * verticalSpacing + 50;

    const nodeDiv = document.createElement("div");
    nodeDiv.className = "bt-node";
    nodeDiv.textContent = node.value;
    nodeDiv.style.left = `${currentX}px`;
    nodeDiv.style.top = `${currentY}px`;
    box.appendChild(nodeDiv);

    nodeMap.set(node.value, { x: currentX, y: currentY });

    const right = calculateNodePositions(node.right, depth + 1, currentX + horizontalSpacing);

    return {
      width: left.width + 1 + right.width,
      center: left.center
    };
  }

  calculateNodePositions(root);
  drawBranches(nodeMap);
}

function drawBranches(nodeMap) {
  svg.innerHTML = "";

  const connect = (parent, child) => {
    if (!nodeMap.has(parent) || !nodeMap.has(child)) return;

    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", nodeMap[parent].x + 20);
    line.setAttribute("y1", nodeMap[parent].y + 20);
    line.setAttribute("x2", nodeMap[child].x + 20);
    line.setAttribute("y2", nodeMap[child].y + 20);
    line.setAttribute("stroke", "#999");
    line.setAttribute("stroke-width", "2");
    svg.appendChild(line);
  };

  const queue = [{ node: root }];
  while (queue.length) {
    const { node } = queue.shift();
    if (node.left) {
      connect(node.value, node.left.value);
      queue.push({ node: node.left });
    }
    if (node.right) {
      connect(node.value, node.right.value);
      queue.push({ node: node.right });
    }
  }
}


  function drawLine(fromNode, toNode) {
  const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line.setAttribute("x1", fromNode.x + 20); // center of node (40px diameter)
  line.setAttribute("y1", fromNode.y + 20);
  line.setAttribute("x2", toNode.x + 20);
  line.setAttribute("y2", toNode.y + 20);
  line.setAttribute("stroke", "#999");
  line.setAttribute("stroke-width", "2");
  svg.appendChild(line);
}



function resetTree() {
  root = null;
  document.getElementById("btBox").innerHTML = "";
  document.getElementById("btLines").innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Tree reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

function traverseTree(type) {
  let result = [];
  switch (type) {
    case "preorder": preorder(root, result); break;
    case "inorder": inorder(root, result); break;
    case "postorder": postorder(root, result); break;
  }
  logExplain(`🔍 ${type}: ${result.join(" → ")}`);
}

function preorder(node, res) {
  if (!node) return;
  res.push(node.value);
  preorder(node.left, res);
  preorder(node.right, res);
}

function inorder(node, res) {
  if (!node) return;
  inorder(node.left, res);
  res.push(node.value);
  inorder(node.right, res);
}

function postorder(node, res) {
  if (!node) return;
  postorder(node.left, res);
  postorder(node.right, res);
  res.push(node.value);
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
