function enqueue() {
  const input = document.getElementById("queueInput");
  const value = input.value.trim();
  if (value === "") return;

  const queueBox = document.getElementById("queueBox");
  const newItem = document.createElement("div");
  newItem.classList.add("queue-item");
  newItem.textContent = value;

  // Animate: slide in
  newItem.style.opacity = "0";
  newItem.style.transform = "translateX(50px)";
  queueBox.appendChild(newItem);

  setTimeout(() => {
    newItem.style.transition = "all 0.4s ease";
    newItem.style.opacity = "1";
    newItem.style.transform = "translateX(0)";
  }, 10);

  logQueueExplain(`✅ Enqueued "${value}" into the queue.`);
  input.value = "";
}

function dequeue() {
  const queueBox = document.getElementById("queueBox");
  const items = queueBox.getElementsByClassName("queue-item");
  if (items.length === 0) {
    logQueueExplain("⚠️ Queue is empty. Cannot dequeue.");
    return;
  }

  const frontItem = items[0];
  const value = frontItem.textContent;

  // Animate: slide out
  frontItem.style.transition = "all 0.4s ease";
  frontItem.style.opacity = "0";
  frontItem.style.transform = "translateX(-50px)";

  setTimeout(() => {
    queueBox.removeChild(frontItem);
  }, 400);

  logQueueExplain(`🗑️ Dequeued "${value}" from the queue.`);
}

function resetQueue() {
  const queueBox = document.getElementById("queueBox");
  queueBox.innerHTML = "";
  document.getElementById("queueExplainList").innerHTML = "";
  logQueueExplain("🔄 Queue has been reset.");
}

function logQueueExplain(message) {
  const list = document.getElementById("queueExplainList");
  const item = document.createElement("li");
  item.textContent = message;
  list.appendChild(item);
}

const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
})