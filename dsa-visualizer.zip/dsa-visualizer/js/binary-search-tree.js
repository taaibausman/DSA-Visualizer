const explanation = document.getElementById("bstExplainSection");
const box = document.getElementById("bstBox");

class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

let root = null;

function insertBST() {
  const val = document.getElementById("bstInput").value.trim();
  if (val === "") return;

  if (containsValue(root, val)) {
    logExplain(`❌ Value "${val}" already exists.`);
    return;
  }

  root = insertRec(root, val);
  logExplain(`🟢 Inserted "${val}"`);
  document.getElementById("bstInput").value = "";
  renderTree();
}

function containsValue(node, val) {
  if (!node) return false;
  if (node.value === val) return true;
  return val < node.value
    ? containsValue(node.left, val)
    : containsValue(node.right, val);
}

function insertRec(node, val) {
  if (!node) return new TreeNode(val);
  if (val < node.value) node.left = insertRec(node.left, val);
  else node.right = insertRec(node.right, val);
  return node;
}

function renderTree() {
  box.innerHTML = "";
  if (!root) return;

  const nodeMap = new Map();
  const startX = box.offsetWidth / 2;
  const startY = 40;
  const horizontalSpacing = 90;
  const verticalSpacing = 100;

  function placeNode(node, x, y, level) {
    if (!node) return;

    const nodeDiv = document.createElement("div");
    nodeDiv.className = "bt-node";
    nodeDiv.textContent = node.value;
    nodeDiv.style.left = `${x}px`;
    nodeDiv.style.top = `${y}px`;
    box.appendChild(nodeDiv);

    const offset = horizontalSpacing / Math.pow(2, level + 1);
    placeNode(node.left, x - offset, y + verticalSpacing, level + 1);
    placeNode(node.right, x + offset, y + verticalSpacing, level + 1);
  }

  placeNode(root, startX, startY, 0);
}

function resetTree() {
  root = null;
  box.innerHTML = "";
  document.getElementById("bstExplainList").innerHTML = "";
  logExplain("🔄 Tree reset.");
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("bstExplainList").appendChild(li);
}

function traverseTree(type) {
  const result = [];
  switch (type) {
    case "inorder": inorder(root, result); break;
    case "preorder": preorder(root, result); break;
    case "postorder": postorder(root, result); break;
  }
  logExplain(`🔍 ${type}: ${result.join(" → ")}`);
}

function inorder(node, res) {
  if (!node) return;
  inorder(node.left, res);
  res.push(node.value);
  inorder(node.right, res);
}

function preorder(node, res) {
  if (!node) return;
  res.push(node.value);
  preorder(node.left, res);
  preorder(node.right, res);
}

function postorder(node, res) {
  if (!node) return;
  postorder(node.left, res);
  postorder(node.right, res);
  res.push(node.value);
}


const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
