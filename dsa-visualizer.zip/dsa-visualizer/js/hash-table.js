const tableSize = 10;
const hashTable = Array.from({ length: tableSize }, () => []);
const grid = document.getElementById("hashTableGrid");

// Initial rendering
renderTable();

function hash(key, action = "") {
  let hashValue = 0;
  let steps = [];
  for (let i = 0; i < key.length; i++) {
    const charCode = key.charCodeAt(i);
    hashValue += charCode;
    steps.push(`${key[i]}(${charCode})`);
  }

  const index = hashValue % tableSize;

  if (action) {
    logExplain(
      `🔢 Hashing "${key}" for ${action}: [${steps.join(" + ")}] = ${hashValue} → ${hashValue} % ${tableSize} = ${index}`
    );
  }

  return index;
}

function insert() {
  const key = document.getElementById("keyInput").value.trim();
  const value = document.getElementById("valueInput").value.trim();
  if (!key || !value) return;

  const index = hash(key, "insert");
  const bucket = hashTable[index];

  const exists = bucket.some(([k]) => k === key);
  if (exists) {
    logExplain(`⚠️ Key "${key}" already exists! Use the Update button to modify.`);
  } else {
    bucket.push([key, value]);
    logExplain(`🟢 Inserted key "${key}" at index ${index}`);
  }

  renderTable();
  document.getElementById("keyInput").value = "";
  document.getElementById("valueInput").value = "";
}
function update() {
  const key = document.getElementById("keyInput").value.trim();
  const value = document.getElementById("valueInput").value.trim();
  if (!key || !value) return;

  const index = hash(key, "update");
  const bucket = hashTable[index];
  const found = bucket.find(([k]) => k === key);

  if (found) {
    found[1] = value;
    logExplain(`✏️ Updated key "${key}" at index ${index} with new value "${value}"`);
    renderTable();
    highlightCell(index, key);
  } else {
    logExplain(`❌ Cannot update. Key "${key}" not found.`);
  }

  document.getElementById("keyInput").value = "";
  document.getElementById("valueInput").value = "";
}



function search() {
  const key = document.getElementById("keyInput").value.trim();
  if (!key) return;
const index = hash(key, "search");
  const bucket = hashTable[index];
  const found = bucket.find(([k]) => k === key);

  document.getElementById("btExplainList").innerHTML = "";
  if (found) {
    logExplain(`🔍 Found key "${key}" at index ${index} with value "${found[1]}"`);
    highlightCell(index, key);
  } else {
    logExplain(`❌ Key "${key}" not found`);
  }

  document.getElementById("keyInput").value = "";
}

function remove() {
  const key = document.getElementById("keyInput").value.trim();
  if (!key) return;
const index = hash(key, "delete");
  const bucket = hashTable[index];
  const originalLength = bucket.length;
  hashTable[index] = bucket.filter(([k]) => k !== key);

  if (bucket.length !== originalLength) {
    logExplain(`🗑️ Deleted key "${key}" from index ${index}`);
  } else {
    logExplain(`❌ Key "${key}" not found to delete`);
  }

  renderTable();
  document.getElementById("keyInput").value = "";
}

function resetTable() {
  for (let i = 0; i < tableSize; i++) {
    hashTable[i] = [];
  }
  document.getElementById("btExplainList").innerHTML = "";
  renderTable();
  logExplain("🔄 Hash table reset.");
}

function renderTable() {
  grid.innerHTML = "";
  for (let i = 0; i < tableSize; i++) {
    const bucketDiv = document.createElement("div");
    bucketDiv.className = "hash-bucket";
    const title = document.createElement("div");
    title.className = "bucket-title";
    title.textContent = `Index ${i}`;
    bucketDiv.appendChild(title);

    hashTable[i].forEach(([k, v]) => {
      const cell = document.createElement("div");
      cell.className = "bucket-cell";
      cell.textContent = `${k}: ${v}`;
      bucketDiv.appendChild(cell);
    });

    grid.appendChild(bucketDiv);
  }
}

function highlightCell(index, key) {
  const bucket = grid.children[index];
  const cells = bucket.querySelectorAll(".bucket-cell");
  for (let cell of cells) {
    if (cell.textContent.startsWith(key + ":")) {
      cell.style.backgroundColor = "gold";
      break;
    }
  }
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
