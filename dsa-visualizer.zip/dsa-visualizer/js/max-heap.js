const box = document.getElementById("heapBox");
const svg = document.getElementById("heapLines");
const explanation = document.getElementById("btExplainSection");
let heap = [];

function insertMaxHeap() {
  const val = document.getElementById("heapInput").value.trim();
  if (val === "") return;
  heap.push(val);
  logExplain(`➕ Inserted "${val}" to heap.`);
  heapifyUp(heap.length - 1);
  document.getElementById("heapInput").value = "";
  renderHeap();
}

function heapifyUp(index) {
  if (index === 0) return;

  const parentIdx = Math.floor((index - 1) / 2);
  if (heap[parentIdx] < heap[index]) {
    logExplain(`🔁 Swapping ${heap[parentIdx]} and ${heap[index]}`);
    [heap[parentIdx], heap[index]] = [heap[index], heap[parentIdx]];
    heapifyUp(parentIdx);
  }
}

function resetMaxHeap() {
  heap = [];
  box.innerHTML = "";
  svg.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Heap reset.");
}

function renderHeap() {
  box.innerHTML = "";
  svg.innerHTML = "";
  if (heap.length === 0) return;

  const nodeMap = new Map();
  const canvasWidth = box.clientWidth;
  const centerX = canvasWidth / 2;
  const spacingY = 90;
  const baseSpacingX = 120;

  function place(index, x, y, level) {
    if (index >= heap.length) return;

    const node = document.createElement("div");
    node.className = "bt-node";
    node.textContent = heap[index];
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
    box.appendChild(node);

    nodeMap.set(index, { x, y });

    const offset = baseSpacingX / Math.pow(2, level);
    const leftIdx = 2 * index + 1;
    const rightIdx = 2 * index + 2;

    if (leftIdx < heap.length) {
      place(leftIdx, x - offset, y + spacingY, level + 1);
    }
    if (rightIdx < heap.length) {
      place(rightIdx, x + offset, y + spacingY, level + 1);
    }
  }

  place(0, centerX, 60, 1);
  drawLines(nodeMap);
}

function drawLines(nodeMap) {
  svg.innerHTML = "";
  for (let i = 0; i < heap.length; i++) {
    const from = nodeMap.get(i);
    const leftIdx = 2 * i + 1;
    const rightIdx = 2 * i + 2;

    if (leftIdx < heap.length) {
      const to = nodeMap.get(leftIdx);
      drawLine(from, to);
    }

    if (rightIdx < heap.length) {
      const to = nodeMap.get(rightIdx);
      drawLine(from, to);
    }
  }
}
function deleteMaxHeap() {
  const val = document.getElementById("heapInput").value.trim();
  if (val === "") return;

  const index = heap.indexOf(val);
  if (index === -1) {
    logExplain(`❌ Value "${val}" not found.`);
    return;
  }

  const lastIndex = heap.length - 1;

  // Swap and remove
  [heap[index], heap[lastIndex]] = [heap[lastIndex], heap[index]];
  heap.pop();

  // Heapify down or up depending on the new value at index
  if (
    (2 * index + 1 < heap.length && heap[index] < heap[2 * index + 1]) ||
    (2 * index + 2 < heap.length && heap[index] < heap[2 * index + 2])
  ) {
    heapifyDown(index);
  } else {
    heapifyUp(index);
  }

  renderHeap();
  logExplain(`🗑️ Deleted "${val}" from Max Heap.`);
  document.getElementById("heapInput").value = "";
}
function deleteMax() {
  if (heap.length === 0) {
    logExplain("⚠️ Heap is empty.");
    return;
  }

  const maxValue = heap[0];

  // Replace root with last element and remove last
  heap[0] = heap[heap.length - 1];
  heap.pop();

  heapifyDown(0);
  renderHeap();

  logExplain(`🗑️ Max value "${maxValue}" deleted from heap.`);
}

function heapifyDown(index) {
  let largest = index;
  const left = 2 * index + 1;
  const right = 2 * index + 2;

  if (left < heap.length && heap[left] > heap[largest]) {
    largest = left;
  }
  if (right < heap.length && heap[right] > heap[largest]) {
    largest = right;
  }

  if (largest !== index) {
    [heap[index], heap[largest]] = [heap[largest], heap[index]];
    heapifyDown(largest);
  }
}

function heapifyUp(index) {
  if (index === 0) return;

  const parent = Math.floor((index - 1) / 2);
  if (heap[index] > heap[parent]) {
    [heap[index], heap[parent]] = [heap[parent], heap[index]];
    heapifyUp(parent);
  }
}


function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

// Theme Toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;

const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
