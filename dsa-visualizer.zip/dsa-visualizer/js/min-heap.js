const box = document.getElementById("heapBox");
const explanation = document.getElementById("btExplainSection");
let heap = [];

function insertHeap() {
  const val = document.getElementById("heapInput").value.trim();
  if (val === "") return;

  heap.push(parseInt(val));
  logExplain(`➕ Inserted ${val}`);
  heapifyUp(heap.length - 1);
  renderHeap();
  document.getElementById("heapInput").value = "";
}

function heapifyUp(index) {
  while (index > 0) {
    const parent = Math.floor((index - 1) / 2);
    if (heap[index] < heap[parent]) {
      logExplain(`🔁 Swapped ${heap[index]} with ${heap[parent]}`);
      [heap[index], heap[parent]] = [heap[parent], heap[index]];
      index = parent;
    } else break;
  }
}

function deleteMin() {
  if (heap.length === 0) {
    logExplain("⚠️ Heap is empty.");
    return;
  }

  const min = heap[0];
  const last = heap.pop();

  if (heap.length > 0) {
    heap[0] = last;
    heapifyDown(0);
  }

  logExplain(`🗑️ Deleted min value "${min}"`);
  renderHeap();
}

function deleteSpecific(value) {
  value = parseInt(value);
  const index = heap.indexOf(value);

  if (index === -1) {
    logExplain(`❌ Value "${value}" not found in heap.`);
    return;
  }

  logExplain(`🗑️ Deleting value "${value}" from heap.`);

  // Replace with last element and pop
  const last = heap.length - 1;
  [heap[index], heap[last]] = [heap[last], heap[index]];
  heap.pop();

  // Reheapify both directions to restore min-heap
  heapifyDown(index);
  heapifyUp(index);

  renderHeap();
}

function heapifyDown(index) {
  const n = heap.length;
  while (true) {
    let smallest = index;
    const left = 2 * index + 1;
    const right = 2 * index + 2;

    if (left < n && heap[left] < heap[smallest]) smallest = left;
    if (right < n && heap[right] < heap[smallest]) smallest = right;

    if (smallest !== index) {
      logExplain(`🔁 Swapped ${heap[index]} with ${heap[smallest]}`);
      [heap[index], heap[smallest]] = [heap[smallest], heap[index]];
      index = smallest;
    } else break;
  }
}

function resetHeap() {
  heap = [];
  box.innerHTML = "";
  document.getElementById("btExplainList").innerHTML = "";
  logExplain("🔄 Heap reset.");
}

function renderHeap() {
  box.innerHTML = "";
  if (heap.length === 0) return;

  const nodeMap = new Map();
  const containerWidth = Math.max(box.clientWidth, 1000);
  const centerX = containerWidth / 2;

  const spacingY = 100;
  const baseSpacingX = 120;

  function place(index, x, y, level) {
    if (index >= heap.length) return;

    const node = document.createElement("div");
    node.className = "bt-node";
    node.textContent = heap[index];
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
    box.appendChild(node);

    nodeMap.set(index, { x, y });

    const offset = baseSpacingX / Math.pow(2, level);
    place(2 * index + 1, x - offset, y + spacingY, level + 1);
    place(2 * index + 2, x + offset, y + spacingY, level + 1);
  }

  place(0, centerX, 50, 1);
}

function logExplain(msg) {
  const li = document.createElement("li");
  li.textContent = msg;
  document.getElementById("btExplainList").appendChild(li);
}

// Theme toggle
const themeToggle = document.getElementById("themeToggle");
const rootElement = document.documentElement;
const savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  rootElement.setAttribute("data-theme", savedTheme);
  themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
}
themeToggle.addEventListener("click", () => {
  const currentTheme = rootElement.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  rootElement.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);
  themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
});
