const stackBox = document.getElementById("stackBox");
const explainText = document.getElementById("explainText");
let stack = [];

function pushToStack() {
  const input = document.getElementById("stackInput");
  const value = input.value.trim();
  if (value === "") return;

  const stackBox = document.getElementById("stackBox");
  const newItem = document.createElement("div");
  newItem.classList.add("stack-item");
  newItem.textContent = value;

  // Animate
  newItem.style.opacity = "0";
  newItem.style.transform = "translateY(20px)";
  stackBox.appendChild(newItem);

  setTimeout(() => {
    newItem.style.transition = "all 0.4s ease";
    newItem.style.opacity = "1";
    newItem.style.transform = "translateY(0)";
  }, 10);

  logExplain(`✅ Pushed "${value}" onto the stack.`);
  input.value = "";
}

function popFromStack() {
  const stackBox = document.getElementById("stackBox");
  const items = stackBox.getElementsByClassName("stack-item");
  if (items.length === 0) {
    logExplain(`⚠️ Stack is empty. Cannot pop.`);
    return;
  }

  const topItem = items[items.length - 1];
  const value = topItem.textContent;

  // Animate
  topItem.style.transition = "all 0.4s ease";
  topItem.style.opacity = "0";
  topItem.style.transform = "translateY(20px)";

  setTimeout(() => {
    stackBox.removeChild(topItem);
  }, 400);

  logExplain(`🗑️ Popped "${value}" from the stack.`);
}

function resetStack() {
  const stackBox = document.getElementById("stackBox");
  stackBox.innerHTML = "";
  document.getElementById("explainList").innerHTML = "";
  logExplain(`🔄 Stack has been reset.`);
}

function logExplain(message) {
  const list = document.getElementById("explainList");
  const item = document.createElement("li");
  item.textContent = message;
  list.appendChild(item);
}
